## study_03 Comparison of timepoints of FGCC for predicting DI for all pots with DI under 100 

.libPaths("C:/R-packages2")
rm(list=ls())

library(tidyverse)
library(ggplot2); theme_set(theme_bw())
library(broom)
library(ggsci)
library(tidymodels)

`%nin%` <- Negate(`%in%`)

# Data prep ---------------------------------------------------------------


TPA_results <- readxl::read_xlsx("S:/Science/AgFood&Wine/Plant Accelerator/Accelerator Projects 0501 to 0550/0539_PH_UA_TannerFlorian_hyperspec/rawdata/0539 Chickpea.xlsx")

TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 6"] <- "712 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 8"] <- "732 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 6"] <- "716 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 4"] <- "720 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 3"] <- "724 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 7"] <- "728 A"

scores <- read_csv("R out/2020-11-19 Scores.csv")

nursery_FGCC <- read_csv("R out/FGCC/FGCC results.csv")

sowing_plan <- read_csv("R out/2020-10-27 Sowing plan clean.csv")

nursery_FGCC_wide <- nursery_FGCC %>% pivot_wider(id_cols = c(Pot, Treatment, Rep), names_from = Date, values_from = FGCC, names_glue = "{Date}_{.value}")

FGCC_full <- sowing_plan %>%
  left_join(scores) %>% 
  left_join(nursery_FGCC_wide) %>% 
  filter(!is.na(`2020-09-27_FGCC`), !is.na(`2020-07-27_FGCC`), DI < 100)

summary(FGCC_full)


# Modelling with cross-validation -----------------------------------------


set.seed(123)
FGCC_folds_full <- vfold_cv(data = FGCC_full, strata = DI, v = 5)

linreg_spec <- linear_reg() %>%
  set_engine("lm")

DAI55_full  <- fit_resamples(linreg_spec, DI ~ `2020-09-27_FGCC`, resamples = FGCC_folds_full ,
                       control = control_resamples(save_pred = TRUE))

DAI35_full  <- fit_resamples(linreg_spec, DI ~ `2020-09-07_FGCC`, resamples = FGCC_folds_full ,
                       control = control_resamples(save_pred = TRUE))

DAI21_full  <- fit_resamples(linreg_spec, DI ~ `2020-08-24_FGCC`, resamples = FGCC_folds_full ,
                       control = control_resamples(save_pred = TRUE))



ALLDAI_full  <- fit_resamples(linreg_spec, DI ~ `2020-07-27_FGCC` * `2020-08-03_FGCC` * `2020-08-24_FGCC` * `2020-09-07_FGCC` * `2020-09-27_FGCC`,
                        resamples = FGCC_folds_full ,
                        control = control_resamples(save_pred = TRUE))




CV_metrics_full  <- DAI55_full  %>% 
  collect_metrics() %>% 
  mutate(DAI = "55 DAI") %>% 
  bind_rows(DAI35_full  %>% 
              collect_metrics() %>% 
              mutate(DAI = "35 DAI") )%>% 
  bind_rows(DAI21_full  %>% 
              collect_metrics() %>% 
              mutate(DAI = "21 DAI")) %>% 
  bind_rows(ALLDAI_full  %>% 
              collect_metrics() %>% 
              mutate(DAI = "Full model (5 timepoints)")) 
CV_metrics_full 

CV_preds_full  <- DAI55_full  %>% 
  collect_predictions() %>% 
  mutate(DAI = "55 DAI") %>% 
  bind_rows(DAI35_full  %>% collect_predictions() %>% 
              mutate(DAI = "35 DAI")) %>% 
  bind_rows(DAI21_full  %>% collect_predictions() %>% 
              mutate(DAI = "21 DAI") )%>% 
  bind_rows(ALLDAI_full  %>% collect_predictions() %>% 
              mutate(DAI = "Full model (5 timepoints)"))



# CV plots full dataset ----------------------------------------------------------------


p_predictions_full  <- CV_preds_full  %>% 
  ggplot(aes(x = DI, y = .pred, color = DAI)) +
  geom_point(shape = 1) +
  facet_wrap(~DAI, nrow =2)+
  labs(x = "Ground truth", y = "Predicted Disease Index") +
  scale_y_continuous(limits = c(0, 100)) +
  scale_color_jco() + 
  theme(legend.position = "blank")


p_predictions_full


# ggsave(p_predictions_full, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC predictive power for DI (all pots, capped under 100, cross-validated).png",
#        limitsize =  F, units = "cm", device = "png", width = 12, height = 12)
# ggsave(p_predictions_full, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC predictive power for DI (all pots, capped under 100, cross-validated).pdf",
#        limitsize =  F, units = "cm", device = "pdf", width = 12, height = 12)


p_rsq_full <- CV_metrics_full %>% 
  filter(.metric== "rsq") %>% 
  ggplot(aes(x = DAI, y = mean, color = DAI, fill = DAI)) +
  geom_col(alpha = 0.6) +
  geom_errorbar(aes(x = DAI, ymin = mean - std_err, ymax = mean + std_err), width = 0.3, color = "black")  +
  labs(x= "Model", y = "Estimated r-squared (5-fold CV)") +
  scale_color_jco() +
  scale_fill_jco()+ 
  theme(legend.position = "blank")


p_rsq_full


# ggsave(p_rsq_full, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC predictive power for DI rsq estimate(all pots, capped under 100, cross-validated).png",
#        limitsize =  F, units = "cm", device = "png", width = 12, height = 12)
# ggsave(p_rsq_full, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC predictive power for DI rsq estimate(all pots, capped under 100, cross-validated).pdf",
#        limitsize =  F, units = "cm", device = "pdf", width = 12, height = 12)

# Fit linear model on all data to compare metrics -------------------------


summary(lm(DI ~  `2020-08-24_FGCC`, data = FGCC_full))
summary(lm(DI ~  `2020-09-07_FGCC`, data = FGCC_full))
summary(lm(DI ~  `2020-09-27_FGCC`, data = FGCC_full))
summary(lm(DI ~  `2020-08-24_FGCC` *`2020-09-27_FGCC`, data = FGCC_full))
summary(lm(DI ~ `2020-07-27_FGCC` * `2020-08-03_FGCC` * `2020-08-24_FGCC` * `2020-09-07_FGCC` * `2020-09-27_FGCC`, data = FGCC_full))





# Plot distribution of disease indices in TPA imaged pots -----------------
p_dist_di_full <- FGCC_full %>% 
  filter(!is.na(`2020-09-27_FGCC`), !is.na(`2020-07-27_FGCC`), DI<100) %>%
  ggplot(aes(DI)) +
  geom_histogram() +
  geom_vline(xintercept = 100, linetype= 2, color = "red") +
  labs(x = "Disease Index")

p_dist_di_full

# ggsave(p_dist_di_full, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Distribution of DI (all pots, capped under 100).png",
#        limitsize =  F, units = "cm", device = "png", width = 8, height = 6)
# ggsave(p_dist_di_full, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/istribution of DI (all pots, capped under 100).pdf",
#        limitsize =  F, units = "cm", device = "pdf", width = 8, height = 6)

