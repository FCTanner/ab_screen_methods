## 2020-08-27 Picking genotypes from Judith/Leo's experiment to image at TPA after scoring 

.libPaths("C:/R-packages")
rm(list=ls())

library(tidyverse)

sowing_plan <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/Original/AB phenotyping terrace.xlsx",
                                 skip = 1)
summary(sowing_plan)

sowing_plan_clean <- sowing_plan %>% select(-`Page 1`) %>% filter(Rep != "Rep")

sowing_plan_clean$type <- "Wild cicer"
sowing_plan_clean$type[grepl("UCD", sowing_plan_clean$AccessionName) == T] <- "Introgression"
sowing_plan_clean$type[grepl("FLIP", sowing_plan_clean$AccessionName) == T] <- "FLIP"
sowing_plan_clean$type[grepl("Howzat", sowing_plan_clean$NAME) == T] <- "Cultivar"
sowing_plan_clean$type[grepl("Genesis090", sowing_plan_clean$NAME) == T] <- "Cultivar"


table(sowing_plan_clean$type, sowing_plan_clean$Rep)

set.seed(123)
random_select <- sowing_plan_clean %>% 
  select(type, AccessionName) %>% 
  distinct() %>%
  filter(type != "Cultivar") %>%
  group_by(type) %>%
  sample_n(size = 20)

select_pots <- sowing_plan_clean %>% filter(AccessionName %in% random_select$AccessionName)
cultivar_pots <- sowing_plan_clean %>% filter(type == "Cultivar")

pots_to_mark <- rbind(select_pots, cultivar_pots)

# write.csv(pots_to_mark, file =  paste0("Out picking genotypes/", format(Sys.Date()), " pots to mark.csv"), 
#           row.names = F)
# write.csv(random_select, 
#           file =  paste0("Out picking genotypes/", format(Sys.Date()), " selected genotypes for imaging.csv"),
#           row.names = F)
