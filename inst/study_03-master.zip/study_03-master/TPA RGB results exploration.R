### 2020-10-02 TPA RGB results exploration 
.libPaths("C:/R-packages2")
rm(list=ls())

library(tidyverse)
library(broom)
library(ggpubr)
library(ggplot2); theme_set(theme_bw())
scores <- read_csv("R out/2020-11-19 Scores.csv")

TPA_results <- readxl::read_xlsx("S:/Science/AgFood&Wine/Plant Accelerator/Accelerator Projects 0501 to 0550/0539_PH_UA_TannerFlorian_hyperspec/rawdata/0539 Chickpea.xlsx")

TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 6"] <- "712 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 8"] <- "732 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 6"] <- "716 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 4"] <- "720 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 3"] <- "724 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 7"] <- "728 A"

FGCC_dat <- read_csv("R out/FGCC/FGCC results.csv")

# Prep data ---------------------------------------------------------------


# Prep top view data for plotting 

TPA_v_scores_top <- TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
  select(starts_with("RGB_TV"), Pot, `Projected Shoot Area [pixels]`) %>% 
  left_join(scores %>% select(Pot, DI)) %>% 
  left_join(FGCC_dat %>% filter(Source == "Lemnatech") %>% select(Pot, FGCC)) %>% 
  filter(!is.na(DI), DI < 100) %>% 
  select_if(~ is.numeric(.)) %>% 
  pivot_longer(cols = c(-DI))  # pivoting longer here for consistency with data prep for lower, far and upper cameras

# Averaging over low, upper, and far cameras

TPA_v_scores_far <- TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
  select(starts_with("RGB_Side_Far_"), Pot, `Projected Shoot Area [pixels]`,
         -`RGB_Side_Far_0 Result writer_label`,
         - `RGB_Side_Far_4 Result writer_label`) %>% 
  left_join(scores %>% select(Pot, DI)) %>% 
  left_join(FGCC_dat %>% filter(Source == "Lemnatech") %>% select(Pot, FGCC)) %>% 
  filter(!is.na(DI), DI < 100) %>% 
  pivot_longer(cols = c(-DI, - Pot)) %>% # pivoting longer here for easier summary
  mutate(name_combine = str_remove(name, pattern = "_0")) %>% # Renaming to average over two cameras
  mutate(name_combine = str_remove(name_combine, pattern = "_4")) %>% # Renaming to average over two cameras
  group_by(Pot, name_combine) %>% 
  summarize(average_value = mean(value), DI = DI) # summarizing 


TPA_v_scores_lower <- TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
  select(starts_with("RGB_Side_Lower_"), Pot, `Projected Shoot Area [pixels]`,
         -`RGB_Side_Lower_0 Result writer_label`,
         - `RGB_Side_Lower_4 Result writer_label`) %>% 
  left_join(scores %>% select(Pot, DI)) %>% 
  left_join(FGCC_dat %>% filter(Source == "Lemnatech") %>% select(Pot, FGCC)) %>% 
  filter(!is.na(DI), DI < 100) %>% 
  pivot_longer(cols = c(-DI, - Pot)) %>% # pivoting longer here for easier summary
  mutate(name_combine = str_remove(name, pattern = "_0")) %>% # Renaming to average over two cameras
  mutate(name_combine = str_remove(name_combine, pattern = "_4")) %>% # Renaming to average over two cameras
  group_by(Pot, name_combine) %>% 
  summarize(average_value = mean(value), DI = DI) # summarizing 


TPA_v_scores_upper <- TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
  select(starts_with("RGB_Side_Upper_"), Pot, `Projected Shoot Area [pixels]`,
         -`RGB_Side_Upper_0 Result writer_label`,
         - `RGB_Side_Upper_4 Result writer_label`) %>% 
  left_join(scores %>% select(Pot, DI)) %>% 
  left_join(FGCC_dat %>% filter(Source == "Lemnatech") %>% select(Pot, FGCC)) %>% 
  filter(!is.na(DI), DI < 100) %>% 
  pivot_longer(cols = c(-DI, - Pot)) %>% # pivoting longer here for easier summary
  mutate(name_combine = str_remove(name, pattern = "_0")) %>% # Renaming to average over two cameras
  mutate(name_combine = str_remove(name_combine, pattern = "_4")) %>% # Renaming to average over two cameras
  group_by(Pot, name_combine) %>% 
  summarize(average_value = mean(value), DI = DI) # summarizing 

# TPA_v_scores_far0 <- TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
#   select(starts_with("RGB_Side_Far_0"), Pot, `Projected Shoot Area [pixels]`) %>% 
#   left_join(scores %>% select(Pot, DI))
# 
# TPA_v_scores_far4 <- TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
#   select(starts_with("RGB_Side_Far_4"), Pot, `Projected Shoot Area [pixels]`) %>% 
#   left_join(scores %>% select(Pot, DI))
# 
# TPA_v_scores_lower0 <- TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
#   select(starts_with("RGB_Side_Lower_0"), Pot, `Projected Shoot Area [pixels]`) %>% 
#   left_join(scores %>% select(Pot, DI))
# 
# TPA_v_scores_lower4 <- TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
#   select(starts_with("RGB_Side_Lower_4"), Pot, `Projected Shoot Area [pixels]`) %>% 
#   left_join(scores %>% select(Pot, DI))
# 
# TPA_v_scores_upper0 <- TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
#   select(starts_with("RGB_Side_Upper_0"), Pot, `Projected Shoot Area [pixels]`) %>% 
#   left_join(scores %>% select(Pot, DI))
# 
# TPA_v_scores_upper4 <- TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
#   select(starts_with("RGB_Side_Upper_4"), Pot, `Projected Shoot Area [pixels]`) %>% 
#   left_join(scores %>% select(Pot, DI))


# Make pair plots ---------------------------------------------------------


# Top view pairs plot ----------------------------------------------------------

p_top_all <- TPA_v_scores_top %>% 
  mutate(name= str_remove(name, "RGB_TV Result ")) %>% 
  ggscatter(x = "value", y = "DI", shape =1 , size = 1)+
  facet_wrap(~name, scales = "free_x") + 
  stat_cor(aes(label = paste(..rr.label.., ..p.label.., sep = "~`,`~")), label.y = 10) +
  labs(title= "Top view")
p_top_all

p_top_select <- TPA_v_scores_top %>% 
  filter(name %in% c("FGCC", 
                     "Projected Shoot Area [pixels]", 
                     "RGB_TV Result area",
                     "RGB_TV Result bd_pnt_cnt",
                     "RGB_TV Result bd_pnt_rdns",
                     "RGB_TV Result compactness",
                     "RGB_TV Result convex_hull_area",
                     "RGB_TV Result Senescent.ColorClassAreaRelative")) %>% 
  mutate(name = str_remove(name, "RGB_TV Result ")) %>% 
  ggscatter(x = "value", y = "DI", shape =1 , size = 1)+
  facet_wrap(~name, scales = "free_x") + 
  stat_cor(aes(label = paste(..rr.label.., ..p.label.., sep = "~`,`~")), label.y = 10) +
  labs(title= "Top view")
p_top_select

ggsave(p_top_all, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Topview all.png",
       limitsize =  F, units = "cm", device = "png", width = 20, height = 12,
       scale= 2)
ggsave(p_top_all, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Topview all.pdf",
       limitsize =  F, units = "cm", device = "pdf", width = 20, height = 12,
       scale= 2)

ggsave(p_top_select, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Topview select.png",
       limitsize =  F, units = "cm", device = "png", width = 20, height = 12,
       scale= 1)
ggsave(p_top_select, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Topview select.pdf",
       limitsize =  F, units = "cm", device = "pdf", width = 20, height = 12,
       scale= 1)


# Lower view average pairs plot ------------------------------------------------

p_lower_all <- TPA_v_scores_lower %>%
  mutate(name_combine = str_remove(name_combine, "RGB_Side_Lower Result ")) %>% 
  ggscatter(x = "average_value", y = "DI", shape =1 , size = 1)+
  facet_wrap(~name_combine, scales = "free_x") + 
  stat_cor(aes(label = paste(..rr.label.., ..p.label.., sep = "~`,`~")), label.y = 10) +
  labs(title= "Lower view")
p_lower_all

p_lower_select <- TPA_v_scores_lower %>% 
  filter(name_combine %in% c("FGCC", 
                             "Projected Shoot Area [pixels]", 
                             "RGB_Side_Lower Result area",
                             "RGB_Side_Lower Result bd_pnt_cnt",
                             "RGB_Side_Lower Result bd_pnt_rdns",
                             "RGB_Side_Lower Result compactness",
                             "RGB_Side_Lower Result convex_hull_area",
                             "RGB_Side_Lower Result Senescent.ColorClassAreaRelative")) %>% 
  mutate(name_combine = str_remove(name_combine, "RGB_Side_Lower Result ")) %>% 
  ggscatter(x = "average_value", y = "DI", shape =1 , size = 1)+
  facet_wrap(~name_combine, scales = "free_x") + 
  stat_cor(aes(label = paste(..rr.label.., ..p.label.., sep = "~`,`~")), label.y = 10) +
  labs(title= "Lower view")
p_lower_select

ggsave(p_lower_all, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Lower view all.png",
       limitsize =  F, units = "cm", device = "png", width = 20, height = 12,
       scale= 2)
ggsave(p_lower_all, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Lower view all.pdf",
       limitsize =  F, units = "cm", device = "pdf", width = 20, height = 12,
       scale= 2)

ggsave(p_lower_select, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Lower view select.png",
       limitsize =  F, units = "cm", device = "png", width = 20, height = 12,
       scale= 1)
ggsave(p_lower_select, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Lower view select.pdf",
       limitsize =  F, units = "cm", device = "pdf", width = 20, height = 12,
       scale= 1)


# Upper view average pairs ------------------------------------------------

p_upper_all <- TPA_v_scores_upper %>%
  mutate(name_combine = str_remove(name_combine, "RGB_Side_Upper Result ")) %>% 
  ggscatter(x = "average_value", y = "DI", shape =1 , size = 1)+
  facet_wrap(~name_combine, scales = "free_x") + 
  stat_cor(aes(label = paste(..rr.label.., ..p.label.., sep = "~`,`~")), label.y = 10) +
  labs(title= "Upper view")
p_upper_all

p_upper_select <- TPA_v_scores_upper %>% 
  filter(name_combine %in% c("FGCC", 
                             "Projected Shoot Area [pixels]", 
                             "RGB_Side_Upper Result area",
                             "RGB_Side_Upper Result bd_pnt_cnt",
                             "RGB_Side_Upper Result bd_pnt_rdns",
                             "RGB_Side_Upper Result compactness",
                             "RGB_Side_Upper Result convex_hull_area",
                             "RGB_Side_Upper Result Senescent.ColorClassAreaRelative")) %>% 
  mutate(name_combine = str_remove(name_combine, "RGB_Side_Upper Result ")) %>% 
  ggscatter(x = "average_value", y = "DI", shape =1 , size = 1)+
  facet_wrap(~name_combine, scales = "free_x") + 
  stat_cor(aes(label = paste(..rr.label.., ..p.label.., sep = "~`,`~")), label.y = 10) +
  labs(title= "Upper view")
p_upper_select

ggsave(p_upper_all, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Upper view all.png",
       limitsize =  F, units = "cm", device = "png", width = 20, height = 12,
       scale= 2)
ggsave(p_upper_all, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Upper view all.pdf",
       limitsize =  F, units = "cm", device = "pdf", width = 20, height = 12,
       scale= 2)

ggsave(p_upper_select, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Upper view select.png",
       limitsize =  F, units = "cm", device = "png", width = 20, height = 12,
       scale= 1)
ggsave(p_upper_select, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Upper view select.pdf",
       limitsize =  F, units = "cm", device = "pdf", width = 20, height = 12,
       scale= 1)


# Far view pairs plot -----------------------------------------------------

p_far_all <- TPA_v_scores_far %>%
  mutate(name_combine = str_remove(name_combine, "RGB_Side_Far Result ")) %>% 
  ggscatter(x = "average_value", y = "DI", shape =1 , size = 1)+
  facet_wrap(~name_combine, scales = "free_x") + 
  stat_cor(aes(label = paste(..rr.label.., ..p.label.., sep = "~`,`~")), label.y = 10) +
  labs(title= "Far view")
p_far_all

p_far_select <- TPA_v_scores_far %>% 
  filter(name_combine %in% c("FGCC", 
                             "Projected Shoot Area [pixels]", 
                             "RGB_Side_Far Result area",
                             "RGB_Side_Far Result bd_pnt_cnt",
                             "RGB_Side_Far Result bd_pnt_rdns",
                             "RGB_Side_Far Result compactness",
                             "RGB_Side_Far Result convex_hull_area",
                             "RGB_Side_Far Result Senescent.ColorClassAreaRelative")) %>% 
  mutate(name_combine = str_remove(name_combine, "RGB_Side_Far Result ")) %>% 
  ggscatter(x = "average_value", y = "DI", shape =1 , size = 1)+
  facet_wrap(~name_combine, scales = "free_x") + 
  stat_cor(aes(label = paste(..rr.label.., ..p.label.., sep = "~`,`~")), label.y = 10) +
  labs(title= "Far view")
p_far_select

ggsave(p_far_all, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Far view all.png",
       limitsize =  F, units = "cm", device = "png", width = 20, height = 12,
       scale= 2)
ggsave(p_far_all, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Far view all.pdf",
       limitsize =  F, units = "cm", device = "pdf", width = 20, height = 12,
       scale= 2)

ggsave(p_far_select, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Far view select.png",
       limitsize =  F, units = "cm", device = "png", width = 20, height = 12,
       scale= 1)
ggsave(p_far_select, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Lemnatech traits to predict DI/Far view select.pdf",
       limitsize =  F, units = "cm", device = "pdf", width = 20, height = 12,
       scale= 1)

# Export Simon's results --------------------------------------------------



TPAresults <- readxl::read_xlsx("S:/Science/AgFood&Wine/Plant Accelerator/Accelerator Projects 0501 to 0550/0539_PH_UA_TannerFlorian_hyperspec/rawdata/0539 Chickpea.xlsx")

scores_NVT <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/2020-09-28 Scoring results/Original/Results Assessment NVT AB Curyo.xlsx")
scores_FLIP <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/2020-09-28 Scoring results/Original/Results Assessment Wild Cicer FLIP Curyo 2020.xlsx")
scores_secondary <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/2020-09-28 Scoring results/Original/Results Assessment Secondary infection AB Curyo Tanner.xlsx",
                                      na = "NA")
scores_FLIP <- scores_FLIP %>% rename(Entry = ENTRY, Name = NAME)
scores <- rbind(scores_NVT, scores_FLIP, scores_secondary)
summary(scores)
pots <- read_csv("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/2020-09-29 my pots to image.csv")
pots <- pots %>% select(Pot, Type, AccessionName)

Simonmapping <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/2020-09-29 Simon pot ID.xlsx")

Simon_results <- Simonmapping %>% rename(`Snapshot ID Tag` = ID) %>% left_join(TPAresults)

# write_csv(Simon_results, "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/TPA/RGB results/2020-10-02 Simon results.csv")

my_results <- TPAresults %>% rename(Pot = `Snapshot ID Tag`) %>% 
  select(c(Pot, `Projected Shoot Area [pixels]`, `RGB_TV Result area` )) %>% 
             left_join(pots) %>%
             left_join(scores)
colnames(my_results)
summary(my_results)


mod_data <- my_results %>% filter(`RGB_TV Result area` > 100 , !is.na(Type), 
                                  !(Pot %in% c("How3", "How6", "How8", "Gen4", "Gen6", "Gen7")))

mod <- lm(`RGB_TV Result area` ~ `% LAD`, data = mod_data)
mod_coefs <- tidy(mod)
summary(mod)

p1 <- my_results %>% filter(`RGB_TV Result area` > 100 , !is.na(Type), 
                      !(Pot %in% c("How3", "How6", "How8", "Gen4", "Gen6", "Gen7"))) %>% 
  ggplot(aes(y= `RGB_TV Result area`, x = `% LAD`, color = Type, shape = Type)) +
  geom_abline(slope = mod_coefs$estimate[2], intercept = mod_coefs$estimate[1] ) +
  geom_point() +
  theme_bw() + 
  geom_text(data=my_results %>% filter(AccessionName %in% c("Kayat_071")) ,
            aes(y= 100000, x = 10,label=AccessionName)) +
  labs(title = "Correlation `% Leaf area diseased` to `Top-view area`", subtitle = "Only > 100 pixels area", y = "Top-view area") +
  geom_text(aes(x = 75, y = 300000, label = "Adjusted R-squared = 0.5178\np-value: < 2.2e-16 "), color = "black", size = 4)

# ggsave(ggsave(p1, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()), 
#                                             " percent LAD vs TV area.jpg"), 
#               device = "jpg", limitsize = F, width = 14, height = 12, unit = "cm",
#               scale = 1.2))



