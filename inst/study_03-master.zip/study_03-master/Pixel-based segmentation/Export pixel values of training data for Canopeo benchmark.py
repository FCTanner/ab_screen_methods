#!/usr/bin/env python
# coding: utf-8


import pandas as pd
from sklearn.model_selection import train_test_split

background = pd.read_csv("Training data/2020-10-12 New training pixel data/2020-10-12 extra background.csv")
foreground = pd.read_csv("Training data/2020-10-12 New training pixel data/2020-10-12 Foreground.csv")

class Segmentation:
    Foreground = 1
    Background = 0

# 1.2 Label data, reduce to 3 RGB values instead of including neighbors
foreground['Segmentation'] = Segmentation.Foreground
background['Segmentation'] = Segmentation.Background
data = foreground.append(background)
data = data.drop(columns = ["Pot", "Height", "Width"])
data = data[["PB", "PR", "PG", "Segmentation"]] # this reduces data to 3 RGB values
print(data.head())
print(data.shape)

# 2. Test/train split as for regular training
train, test = train_test_split(data, test_size= 0.3, random_state=33)
print("Train shape", train.shape)

test.to_csv("Training data/2021-01-12 Pixel values for training data/Pixel values test set data.csv")
