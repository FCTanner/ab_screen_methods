#!/usr/bin/env python
# coding: utf-8


import pickle
import cv2
import os
import numpy as np
import time


jpg_base_dir = "Training data/2020-09-29 Subset training data/Original"
results_dir = "Training data/2021-01-12 Predicted masks/SVM"

def get_pixel_values(pixel):
    pixel_values = []
    pixel_values.append(jpg) # Name
    pixel_values.append(i) # Height
    pixel_values.append(j) # Width
    pixel_values.append(img[i, j, 2]) # "PR"
    pixel_values.append(img[i, j, 1]) # "PG"
    pixel_values.append(img[i, j, 0]) # "PB"
    return pixel_values


# Load model, go through them manually
with open("Training data/2021-01-11 Trained models without neighbors/2021-01-11 no_neighbor pixel_classifier_SVM.pkl", "rb") as f:
    clf = pickle.load(f)

jpgs = os.listdir(jpg_base_dir)

# 0. Just some timing print statement stuff
left_to_do = len(jpgs)
done = 0
duration_list = []

for jpg in jpgs[0:10]:
    start = time.time()
    print(jpg)
    img = cv2.imread(os.path.join(jpg_base_dir, jpg)) # 2.1
    predicted_mask = np.zeros((532,532)) # Creating empty frame to save predictions onto
    for i in range(1,531):
        for j in range(1,531):
            height = i
            width = j
            pixel_values = get_pixel_values(img[i,j])
            pred_in = pixel_values[3:6]
            pred_in = np.reshape(pred_in, (1, 3))
            pred = clf.predict(pred_in) # 2.3
            predicted_mask[i,j] = pred # 2.4
        # break
    cv2.imshow("Mask", predicted_mask)
    cv2.waitKey(1000)
    # 3. Change binary mask into red
    predicted_mask_img = (predicted_mask * 255).astype('uint8')
    color_predicted_mask = cv2.cvtColor(predicted_mask_img, cv2.COLOR_GRAY2BGR)
    color_predicted_mask[predicted_mask > 0] = (0, 0, 255)
    # 4. Overlay mask over original image
    overlay_predicted_mask = cv2.addWeighted(src1=img, alpha= 1, src2=color_predicted_mask, beta =1, gamma=0 )
    cv2.imshow("Overlay predicted mask", overlay_predicted_mask)
    cv2.waitKey(1000)
    # 5. Export image
    cv2.imwrite(filename = os.path.join(results_dir, "{to_save}".format(to_save = jpg)), img = overlay_predicted_mask)
    cv2.imwrite(filename = os.path.join(results_dir, "Mask {to_save}".format(to_save = jpg)), img = predicted_mask_img)

    # 6. Timing stuff and print statements
    left_to_do = left_to_do - 1
    done += 1
    print("#############################################################################")
    print(done, "segmentations are done, ", left_to_do, "iterations left to do ")
    stop = time.time()
    duration = stop - start
    duration_list.append(duration)
    print("Pixel classification took", round(duration), "seconds")
    average_duration = sum(duration_list) / len(duration_list)
    print("Approximate time left =", round((left_to_do * average_duration) / 60), "minutes")
    # break


print("Average time for classification [sec]:", average_duration)