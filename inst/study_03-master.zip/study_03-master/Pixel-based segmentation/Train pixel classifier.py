#!/usr/bin/env python
# coding: utf-8
# Train pixel classifier, follow sklearn tutorial

# n: Save model with pickle

import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import classification_report
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import svm
from sklearn.neural_network import MLPClassifier
import pickle

background = pd.read_csv("Training data/2020-10-12 New training pixel data/2020-10-12 extra background.csv")
foreground = pd.read_csv("Training data/2020-10-12 New training pixel data/2020-10-12 Foreground.csv")

class Segmentation:
    Foreground = 1
    Background = 0

# 1.2 Label data
foreground['Segmentation'] = Segmentation.Foreground
background['Segmentation'] = Segmentation.Background
data = foreground.append(background)
data = data.drop(columns = ["Pot", "Height", "Width"])
# data = data[["PB", "PR", "PG", "Segmentation"]]
print(data.head())
print(data.shape)

# 2. Test/train split
train, test = train_test_split(data, test_size= 0.3, random_state=33)
print("Train shape", train.shape)
print(train.head())
train_x = train.drop('Segmentation', axis = 1).to_numpy()
train_y = train['Segmentation'].to_numpy()
test_x = test.drop('Segmentation', axis = 1).to_numpy()
test_y = test['Segmentation'].to_numpy()

# 2.2 Check split
print("Training set frequency", train.groupby(['Segmentation']).count())
print("Training set frequency", test.groupby(['Segmentation']).count())
print(train_x.shape)
print(train_y.shape)
print(test_x.shape)
print(test_y.shape)

# 3. Train
# 3.1 LDA
clf_lda = LinearDiscriminantAnalysis()
clf_lda.fit(train_x, train_y)
# 3.2 SVM
clf_svm = svm.SVC(kernel='rbf')
clf_svm.fit(train_x, train_y)
# # 3.2.1 SVM parameter tuning
# parameters = {'kernel': ('linear', 'rbf'), 'C': (1,4,8,16,32)}
# svc = svm.SVC()
# clf_svm_tuned = GridSearchCV(svc, parameters, cv = 5)
# clf_svm_tuned.fit(train_x, train_y)
# 3.3 RF
clf_rf = RandomForestClassifier(max_depth=5, n_estimators=10, max_features=1)
clf_rf.fit(train_x, train_y)
# 3.4 Naive Bayes
clf_nb = GaussianNB()
clf_nb.fit(train_x, train_y)
# 3.5 K-neighbors
clf_kn = KNeighborsClassifier(2)
clf_kn.fit(train_x, train_y)
# 3.6 Neural network
clf_nn = MLPClassifier(random_state= 33)
clf_nn.fit(train_x, train_y)

# 4. Predict (do not really need this step)
# 4.1 LDA
# print("LDA")
# print(test_x[1:2,:].shape)
# print(clf_lda.predict(test_x[1:100,:]))
# 4.2 SVM
# print("SVM")
# print(test_x[1:2,:].shape)
# print(clf_svm.predict(test_x[1:100,:]))
# 4.3 RF

# 5. Evaluation
# 5.1 LDA Prediction accuracy
print("clf_lda prediction accuracy = ", clf_lda.score(test_x, test_y))
pred_y_lda = clf_lda.predict(test_x)
lda_report = classification_report(test_y, pred_y_lda, target_names=["Background", "Foreground"], output_dict= True)
lda_df = pd.DataFrame(lda_report).transpose()
lda_df.to_csv("Training data/2020-10-13 Classifier diagnostics/lda_df_test.csv")
# 5.2 SVM Prediction accuracy
print("clf_svm prediction accuracy = ", clf_svm.score(test_x, test_y))
pred_y_svm = clf_svm.predict(test_x)
svm_report = classification_report(test_y, pred_y_svm, target_names=["Background", "Foreground"], output_dict= True)
svm_df = pd.DataFrame(svm_report).transpose()
svm_df.to_csv("Training data/2020-10-13 Classifier diagnostics/svm_df_test.csv")
# # 5.2.1 SVM tuned prediction accuracy
# print("clf_svm_tuned prediction accuracy = ", clf_svm_tuned.score(test_x, test_y))
# pred_y_svm_tuned = clf_svm_tuned.predict(test_x)
# svm_tuned_report = classification_report(test_y, pred_y_svm_tuned, target_names=["Background", "Foreground"], output_dict= True)
# svm_tuned_df = pd.DataFrame(svm_tuned_report).transpose()
# svm_tuned_df.to_csv("Training data/2020-10-13 Classifier diagnostics/svm_tuned_df_test.csv")
# 5.3 RF Prediction accuracy
print("Random forest prediction accuracy = ", clf_rf.score(test_x,test_y))
pred_y_rf = clf_rf.predict(test_x)
rf_report = classification_report(test_y, pred_y_rf, target_names=["Background", "Foreground"], output_dict= True)
rf_df = pd.DataFrame(rf_report).transpose()
rf_df.to_csv("Training data/2020-10-13 Classifier diagnostics/rf_df_test.csv")
# 5.4 NB Prediction accuracy
print("Naive Bayes prediction accuracy = ", clf_nb.score(test_x,test_y))
pred_y_nb = clf_nb.predict(test_x)
nb_report = classification_report(test_y, pred_y_nb, target_names=["Background", "Foreground"], output_dict= True)
nb_df = pd.DataFrame(nb_report).transpose()
nb_df.to_csv("Training data/2020-10-13 Classifier diagnostics/nb_df_test.csv")
# 5.5 KNN Prediction accuracy
print("K-nearest neighbor prediction accuracy = ", clf_kn.score(test_x,test_y))
pred_y_kn = clf_kn.predict(test_x)
kn_report = classification_report(test_y, pred_y_kn, target_names=["Background", "Foreground"], output_dict= True)
kn_df = pd.DataFrame(kn_report).transpose()
kn_df.to_csv("Training data/2020-10-13 Classifier diagnostics/kn_df_test.csv")
# 5.6 MLP NN
print("MLP NN prediction accuracy = ", clf_nn.score(test_x,test_y))
pred_y_nn = clf_nn.predict(test_x)
nn_report = classification_report(test_y, pred_y_nn, target_names=["Background", "Foreground"], output_dict= True)
nn_df = pd.DataFrame(nn_report).transpose()
nn_df.to_csv("Training data/2020-10-13 Classifier diagnostics/nn_df_test.csv")
# 6. Save model
with open("Training data/2020-10-13 Trained models/2020-10-13 pixel_classifier_LDA.pkl", "wb") as f:
    pickle.dump(clf_lda, f)
with open("Training data/2020-10-13 Trained models/2020-10-13 pixel_classifier_SVM.pkl", "wb") as f:
    pickle.dump(clf_svm, f)
# with open("Training data/2020-10-13 Trained models/2020-10-13 pixel_classifier_SVM_tuned.pkl", "wb") as f:
#     pickle.dump(clf_svm, f)
with open("Training data/2020-10-13 Trained models/2020-10-13 pixel_classifier_SVM_tuned.pkl", "wb") as f:
    pickle.dump(clf_svm, f)
with open("Training data/2020-10-13 Trained models/2020-10-13 pixel_classifier_RF.pkl", "wb") as f:
    pickle.dump(clf_rf, f)
with open("Training data/2020-10-13 Trained models/2020-10-13 pixel_classifier_NB.pkl", "wb") as f:
    pickle.dump(clf_nb, f)
with open("Training data/2020-10-13 Trained models/2020-10-13 pixel_classifier_KN.pkl", "wb") as f:
    pickle.dump(clf_kn, f)
with open("Training data/2020-10-13 Trained models/2020-10-13 pixel_classifier_NN.pkl", "wb") as f:
    pickle.dump(clf_nn, f)