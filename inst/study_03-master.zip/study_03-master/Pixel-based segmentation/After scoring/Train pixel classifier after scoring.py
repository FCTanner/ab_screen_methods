#!/usr/bin/env python
# coding: utf-8
# Train pixel classifier, follow sklearn tutorial

# n: Save model with pickle

import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import classification_report
from sklearn.neural_network import MLPClassifier
import pickle

background_after = pd.read_csv("Training data/Extracted pixels/Background pixels after scoring.csv")
foreground_after = pd.read_csv("Training data/Extracted pixels/Foreground pixels after scoring.csv")

background_before = pd.read_csv("../Training data/2020-10-12 New training pixel data/2020-10-12 extra background.csv")
foreground_before = pd.read_csv("../Training data/2020-10-12 New training pixel data/2020-10-12 Foreground.csv")

background = pd.concat(objs= [background_after, background_before])
foreground = pd.concat(objs = [background_before, foreground_before])

class Segmentation:
    Foreground = 1
    Background = 0

nrows_foreground = foreground.shape[0]
background = background.sample(n = nrows_foreground, random_state=33)

# Label data
foreground['Segmentation'] = Segmentation.Foreground
background['Segmentation'] = Segmentation.Background
data = foreground.append(background)
data = data.drop(columns = ["Pot", "Height", "Width"])

print(data.head())
print(data.shape)

# 1. With neighbors
# Test/train split
train, test = train_test_split(data, test_size= 0.3, random_state=33)
print("Train shape", train.shape)
print(train.head())
train_x = train.drop('Segmentation', axis = 1).to_numpy()
train_y = train['Segmentation'].to_numpy()
test_x = test.drop('Segmentation', axis = 1).to_numpy()
test_y = test['Segmentation'].to_numpy()

# Check split
print("Training set frequency", train.groupby(['Segmentation']).count())
print("Test set frequency", test.groupby(['Segmentation']).count())
print(train_x.shape)
print(train_y.shape)
print(test_x.shape)
print(test_y.shape)

# Neural network
clf_nn = MLPClassifier(random_state= 33)
clf_nn.fit(train_x, train_y)

# Evaluation
print("MLP NN prediction accuracy = ", clf_nn.score(test_x,test_y))
pred_y_nn = clf_nn.predict(test_x)
nn_report = classification_report(test_y, pred_y_nn, target_names=["Background", "Foreground"], output_dict= True)
nn_df = pd.DataFrame(nn_report).transpose()
print(nn_df)
nn_df.to_csv("Training data/Classifier diagnostics/nn_df_test.csv")


# 2. Without neighbors
data_no_neighbors = data[["PR", "PG", "PB", "Segmentation"]]
print("############################")
print("No neighbors head")
print(data_no_neighbors.head())
print("#############################")
# Test/train split
train, test = train_test_split(data_no_neighbors, test_size= 0.3, random_state=33)
print("Train shape", train.shape)
print(train.head())
train_x = train.drop('Segmentation', axis = 1).to_numpy()
train_y = train['Segmentation'].to_numpy()
test_x = test.drop('Segmentation', axis = 1).to_numpy()
test_y = test['Segmentation'].to_numpy()

# Check split
print("Training set frequency", train.groupby(['Segmentation']).count())
print("Test set frequency", test.groupby(['Segmentation']).count())
print(train_x.shape)
print(train_y.shape)
print(test_x.shape)
print(test_y.shape)

# Neural network
clf_nn_no_neighbors = MLPClassifier(random_state= 33)
clf_nn_no_neighbors.fit(train_x, train_y)

# Evaluation
print("MLP NN prediction accuracy without neighbors= ", clf_nn_no_neighbors.score(test_x,test_y))
pred_y_nn_no_neighbors = clf_nn_no_neighbors.predict(test_x)
nn_no_neighbors_report = classification_report(test_y, pred_y_nn_no_neighbors, target_names=["Background", "Foreground"], output_dict= True)
nn_no_neighbors_df = pd.DataFrame(nn_no_neighbors_report).transpose()
print(nn_no_neighbors_df)
nn_no_neighbors_df.to_csv("Training data/Classifier diagnostics/nn_df_no_neighbors_test.csv")


# Save classifiers
with open("Training data/Trained models/2021-03-01 pixel_classifier_NN_with_before_pixels.pkl", "wb") as f:
    pickle.dump(clf_nn, f)
with open("Training data/Trained models/2021-03-01 pixel_classifier_NN_no_neighbors_with_before_pixels.pkl", "wb") as f:
    pickle.dump(clf_nn_no_neighbors, f)
