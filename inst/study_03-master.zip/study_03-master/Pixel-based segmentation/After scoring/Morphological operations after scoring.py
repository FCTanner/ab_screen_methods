#!/usr/bin/env python
# coding: utf-8
# Morphological operations after pixel classification to get rid of noise

# 1. Load in masks from different classifiers
# 2. Try Erosion - dilation
# 3. Visually inspect new masks
# 4. Continue with pixel counting

import os
import cv2
import numpy as np
import pandas as pd

date = "2020-11-02"
mask_dir = os.path.join("E:/Florian/study_03/Terrace images/{}/Predicted masks/NN").format(date)
print(mask_dir)
masks = os.listdir(mask_dir)
pixel_count_out_dir = ("Pixel_counts/NN_masks")

print(masks)
binary_masks = [i for i in masks if i.startswith('Mask')]
# binary_masks = masks

def show_quickly(string, img):
    cv2.imshow(string, img)
    cv2.waitKey(500)
    cv2.destroyAllWindows()
    pass

def erode_mask(mask_in):
    mask = cv2.imread(mask_in, cv2.IMREAD_GRAYSCALE)
    smooth_kernel = np.ones((4, 4), np.uint8)
    eroded_mask = cv2.erode(mask, smooth_kernel, iterations=2)
    return eroded_mask

def dilate_mask(mask_in):
    try:
        mask = cv2.imread(mask_in, cv2.IMREAD_GRAYSCALE)
    except:
        mask = mask_in
    smooth_kernel = np.ones((3, 3), np.uint8)
    dilated_mask = cv2.dilate(mask, smooth_kernel, iterations=2)
    return dilated_mask

def count_pixels(mask_in):
    try:
        mask = cv2.imread(mask_in, cv2.IMREAD_GRAYSCALE)
        # show_quickly("Original", mask)
    except:
        mask = mask_in
        # show_quickly("Eroded/dilated", mask)
    mask_1d = np.reshape(mask, (mask.shape[0] * mask.shape[1]))
    n_pixels = len(mask_1d[mask_1d>0])
    return(n_pixels)

out_list = []

for i in binary_masks:
    path = os.path.join(mask_dir, i)
    mask = cv2.imread(path)
    # show_quickly("Original", mask)
    out = {}
    out['Filename'] = i
    out['n_mask'] = count_pixels(path)
    eroded = erode_mask(path)
    # show_quickly("Eroded", eroded)
    out['n_eroded'] = count_pixels(eroded)
    dilated = dilate_mask(eroded)
    # show_quickly("Dilated", dilated)
    out['n_dilated'] = count_pixels(dilated)
    out_list.append(out)


out_df = pd.DataFrame(out_list)
print(out_df)
out_df.to_csv(path_or_buf = os.path.join("{}/{}_erode_4by4_dilate_3by3.csv").format(pixel_count_out_dir, date), index = False)