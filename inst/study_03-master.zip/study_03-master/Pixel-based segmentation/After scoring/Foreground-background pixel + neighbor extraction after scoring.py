#!/usr/bin/env python
# coding: utf-8
# Extracting training data
# Copied from ../FGCC validation TPA/Pixel-based segmentation/Extract training pixels

import cv2
import os
import numpy as np
import pandas as pd
import time
from stackImages import stackImages

png_base_dir = "Training data/Original"
foreground_masks_base_dir = "Training data/Foreground masks"
background_masks_base_dir = "Training data/Background masks"
out_dir = "Training data/Extracted pixels"

sample_size = 5000

pngs = os.listdir(png_base_dir)
foreground_masks = os.listdir(foreground_masks_base_dir)
background_masks = os.listdir(background_masks_base_dir)

print(pngs, foreground_masks, background_masks)

def extract_pixel_positions(mask, image):
    height = []
    width = []
    ground = []
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            height.append(i)
            width.append(j)
            if mask[i, j,] == 255:
                ground.append("Extract")
            elif img_inverted[i, j,] == 0:
                ground.append("Noise")
            else:
                ground.append("None")
    pixel_ids = pd.DataFrame(data=list(zip(height, width, ground)), columns=["Height", "Width", "Ground"])
    return pixel_ids

def sample_pixels(pixel_ids):
    # Includes conditions so that no border pixels are selected
    extraction_pixel_ids = pixel_ids.loc[(pixel_ids['Ground'] == "Extract") &
                                         (pixel_ids['Height'] > 0) &
                                         (pixel_ids['Height'] < 405) &
                                         (pixel_ids['Width'] > 0) &
                                         (pixel_ids['Width'] < 405)]
    n_extraction_pixels = len(extraction_pixel_ids)
    print("n_extraction_pixels", n_extraction_pixels)
    if n_extraction_pixels >= sample_size: # check how many extraction pixels there are
        extraction_sample = extraction_pixel_ids.sample(n=sample_size, random_state = 1)
    else:
        extraction_sample = extraction_pixel_ids
    return extraction_sample

def get_neighbors(pixel):
    neighbors = []
    neighbors.append(png) # Name
    neighbors.append(i) # Height
    neighbors.append(j) # Width
    neighbors.append(img[i, j, 2]) # "PR"
    neighbors.append(img[i, j, 1]) # "PG"
    neighbors.append(img[i, j, 0]) # "PB"
    neighbors.append(img[i-1, j-1, 2])  # "UpleftR"
    neighbors.append(img[i-1, j-1, 1])  # "UpleftG"
    neighbors.append(img[i-1, j-1, 0])  # "UpleftB"
    neighbors.append(img[i-1, j, 2]) # "UpmidR"
    neighbors.append(img[i-1, j, 1]) # "UpmidG"
    neighbors.append(img[i-1, j, 0]) # "UpmidB"
    neighbors.append(img[i-1, j+1, 2]) # "UprightR"
    neighbors.append(img[i-1, j+1, 1]) # "UprightG"
    neighbors.append(img[i-1, j+1, 0]) # "UprightB"
    neighbors.append(img[i, j-1, 2]) # "MidleftR"
    neighbors.append(img[i, j-1, 1]) # "MidleftG"
    neighbors.append(img[i, j-1, 0]) # "MidleftB"
    neighbors.append(img[i, j+1, 2]) # "MidrightR"
    neighbors.append(img[i, j+1, 1]) # "MidrightG"
    neighbors.append(img[i, j+1, 0]) # "MidrightB"
    neighbors.append(img[i+1, j-1, 2]) # "DownleftR"
    neighbors.append(img[i+1, j-1, 1]) # "DownleftG"
    neighbors.append(img[i+1, j-1, 0]) # "DownleftB"
    neighbors.append(img[i+1, j, 2]) # "DownmidR"
    neighbors.append(img[i+1, j, 1]) # "DownmidG"
    neighbors.append(img[i+1, j, 0]) # "DownmidB"
    neighbors.append(img[i+1, j+1, 2]) # "DownrightR"
    neighbors.append(img[i+1, j+1, 1]) # "DownrightG"
    neighbors.append(img[i+1, j+1, 0]) # "DownrightB"
    return neighbors

foreground_out = np.array(["Pot", "Height", "Width", "PR", "PG", "PB", "UpleftR", "UpleftG", "UpleftB",
                  "UpmidR","UpmidG","UpmidB", "UprightR", "UprightG", "UprightB",
                  "MidleftR","MidleftG", "MidleftB", "MidrightR", "MidrightG", "MidrightB",
                  "DownleftR", "DownleftG", "DownleftB", "DownmidR", "DownmidG", "DownmidB",
                  "DownrightR", "DownrightG", "DownrightB"])
foreground_out = np.reshape(foreground_out, (1,30))

background_out = foreground_out.copy()

left_to_do = 2*len(pngs) # times 2 to account for foreground and background...
done = 0
duration_list = []

# Foreground pixels
for png, mask in zip(pngs, foreground_masks):
    start = time.time()
    print("###################################################################")
    print("Foreground pixel extraction")
    print(png)
    # 1. + 2. Load mask and original
    img = cv2.imread(os.path.join(png_base_dir, png))
    img_mask = cv2.imread(os.path.join(foreground_masks_base_dir, mask))
    img_binary = cv2.inRange(img_mask, (0, 0, 0), (1, 1, 1)) # binarizing mask
    img_inverted = 255 - img_binary  # inverting image so that foreground == 1
    # 4. Show masks
    img_stack = stackImages(1, ([img, img_mask], [img_binary, img_inverted]))
    cv2.imshow("Input", img_stack)
    cv2.waitKey(1000)
    foreground = cv2.bitwise_and(img, img, mask=img_inverted)
    cv2.imshow("Foreground", foreground)
    cv2.waitKey(1000)
    # Count foreground and background pixels, store position
    pixel_ids = extract_pixel_positions(mask = img_inverted, image = img)
    print(pixel_ids.Ground.value_counts())
    # Random selection of n pixel foreground and background (store indices (i,j) in extra array)
    foreground_positions = sample_pixels(pixel_ids)
    # Extract pixels with neighbors
    for index, row in foreground_positions.iterrows():
        i = row['Height']
        j = row['Width']
        neighbors = get_neighbors(img[i,j])
        neighbors = np.reshape(neighbors, (1, 30))
        foreground_out = np.append(foreground_out, neighbors, axis=0)
    cv2.destroyAllWindows()
    # 6. Timing stuff and print statements
    left_to_do = left_to_do - 1
    done += 1
    print(done, "pixel extractions are done, ", left_to_do, "iterations left to do ")
    stop = time.time()
    duration = stop - start
    duration_list.append(duration)
    print("Neighbor extraction took", round(duration), "seconds")
    average_duration = sum(duration_list) / len(duration_list)
    print("Approximate time left =", round((left_to_do * average_duration) / 60), "minutes")


# Background pixels
for png, mask in zip(pngs, background_masks):
    start = time.time()
    print("###################################################################")
    print("Background pixel extraction")
    print(png)
    # 1. + 2. Load mask and original
    img = cv2.imread(os.path.join(png_base_dir, png))
    img_mask = cv2.imread(os.path.join(background_masks_base_dir, mask))
    img_binary = cv2.inRange(img_mask, (0, 0, 0), (1, 1, 1))  # binarizing mask
    img_inverted = 255 - img_binary  # inverting image so that foreground == 1
    # 4. Show masks
    img_stack = stackImages(1, ([img, img_mask], [img_binary, img_inverted]))
    cv2.imshow("Input", img_stack)
    cv2.waitKey(1000)
    background = cv2.bitwise_and(img, img, mask=img_inverted)
    cv2.imshow("Background", background)
    cv2.waitKey(1000)
    # Count foreground and background pixels, store position
    pixel_ids = extract_pixel_positions(mask=img_inverted, image=img)
    print(pixel_ids.Ground.value_counts())
    # Random selection of n pixel foreground and background (store indices (i,j) in extra array)
    background_positions = sample_pixels(pixel_ids)
    # Extract pixels with neighbors
    for index, row in background_positions.iterrows():
        i = row['Height']
        j = row['Width']
        neighbors = get_neighbors(img[i, j])
        neighbors = np.reshape(neighbors, (1, 30))
        background_out = np.append(background_out, neighbors, axis=0)
    cv2.destroyAllWindows()
    # 6. Timing stuff and print statements
    left_to_do = left_to_do - 1
    done += 1
    print(done, "pixel extractions are done, ", left_to_do, "iterations left to do ")
    stop = time.time()
    duration = stop - start
    duration_list.append(duration)
    print("Neighbor extraction took", round(duration), "seconds")
    average_duration = sum(duration_list) / len(duration_list)
    print("Approximate time left =", round((left_to_do * average_duration) / 60), "minutes")

np.savetxt(fname = os.path.join(out_dir, "Foreground pixels after scoring.csv"),
           X = foreground_out, fmt='%s', delimiter=",")
np.savetxt(fname = os.path.join(out_dir, "Background pixels after scoring.csv"),
           X = background_out, fmt='%s', delimiter=",")