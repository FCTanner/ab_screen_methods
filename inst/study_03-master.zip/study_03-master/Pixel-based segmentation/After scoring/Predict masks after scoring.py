#!/usr/bin/env python
# coding: utf-8

import itertools
import pickle
import cv2
import os
import numpy as np
import time
from joblib import Parallel, delayed
import random


date = "2020-11-02"
classifier= "Training data/Trained models/2021-03-01 pixel_classifier_NN_with_before_pixels.pkl"
jpg_base_dir = "E:/Florian/study_03/Terrace images/{}/Segmented pots".format(date)
method = "NN"

RED = 2
GRN = 1
BLU = 0

H = 532
W = 532

def predict_pixel(clf, img, i, j):
    if i == 0 or j == 0 or i == H-1 or j == W-1:
        return 0
    else:
        pred_in = [[
            (img[i, j, RED]),  # "PR"
            (img[i, j, GRN]),  # "PG"
            (img[i, j, BLU]),  # "PB"
            (img[i - 1, j - 1, RED]),  # "UpleftR"
            (img[i - 1, j - 1, GRN]),  # "UpleftG"
            (img[i - 1, j - 1, BLU]),  # "UpleftB"
            (img[i - 1, j, RED]),  # "UpmidR"
            (img[i - 1, j, GRN]),  # "UpmidG"
            (img[i - 1, j, BLU]),  # "UpmidB"
            (img[i - 1, j + 1, RED]),  # "UprightR"
            (img[i - 1, j + 1, GRN]),  # "UprightG"
            (img[i - 1, j + 1, BLU]),  # "UprightB"
            (img[i, j - 1, RED]),  # "MidleftR"
            (img[i, j - 1, GRN]),  # "MidleftG"
            (img[i, j - 1, BLU]),  # "MidleftB"
            (img[i, j + 1, RED]),  # "MidrightR"
            (img[i, j + 1, GRN]),  # "MidrightG"
            (img[i, j + 1, BLU]),  # "MidrightB"
            (img[i + 1, j - 1, RED]),  # "DownleftR"
            (img[i + 1, j - 1, GRN]),  # "DownleftG"
            (img[i + 1, j - 1, BLU]),  # "DownleftB"
            (img[i + 1, j, RED]),  # "DownmidR"
            (img[i + 1, j, GRN]),  # "DownmidG"
            (img[i + 1, j, BLU]),  # "DownmidB"
            (img[i + 1, j + 1, RED]),  # "DownrightR"
            (img[i + 1, j + 1, GRN]),  # "DownrightG"
            (img[i + 1, j + 1, BLU]),  # "DownrightB"
    ]]

    return clf.predict(pred_in)[0]  # 2.3
def main():
    results_dir = "E:/Florian/study_03/Terrace images/{}/Predicted masks/{}".format(date, method)
    if os.path.exists(results_dir):
        pass
    else:
        raise Warning("Result directory does not exist")
    jpgs = os.listdir(jpg_base_dir)
    # random.seed(33)
    # jpgs = random.sample(jpgs, 3)  # Subsetting to random 3 for shorter runtime:
    # jpgs = jpgs[715:1650]
    # 1. Load model
    with open(classifier, "rb") as f:  # choose classifier here
        clf = pickle.load(f)

    # Just some timing print statement stuff
    left_to_do = len(jpgs)
    done = 0
    duration_list = []

    for jpg in jpgs:
        start = time.time()
        print(jpg)
        img = cv2.imread(os.path.join(jpg_base_dir, jpg))

        # pr = cProfile.Profile()
        # pr.enable()

        # 2.2 Get neighbors for every pixel but the border pixels
        # 2.3 For each pixel, Predict background/foreground based on pixel and neighbor RGB values
        # 2.4 Save pixel prediction onto mask
        predicted_mask = Parallel(n_jobs=2)(delayed(predict_pixel)(clf, img, i, j) for i, j in itertools.product(range(0, H), range(0, W)))
        predicted_mask = np.reshape(predicted_mask, (H, W))

        # pr.disable()
        # pr.print_stats(sort="tottime")

        predicted_mask_img = (predicted_mask * 255).astype('uint8')

        # cv2.imshow("Mask", predicted_mask_img)
        # cv2.waitKey(0)

        # 3. Change binary mask into red
        color_predicted_mask = cv2.cvtColor(predicted_mask_img, cv2.COLOR_GRAY2BGR)
        color_predicted_mask[predicted_mask > 0] = (0, 0, 255)

        # 4. Overlay mask over original image
        overlay_predicted_mask = cv2.addWeighted(src1=img, alpha=1, src2=color_predicted_mask, beta=1, gamma=0)
        # cv2.imshow("Overlay predicted mask", overlay_predicted_mask)
        # cv2.waitKey(1000)
        # cv2.destroyAllWindows()

        # 5. Export images
        cv2.imwrite(filename=os.path.join(results_dir, "{to_save}".format(to_save=jpg)), img=overlay_predicted_mask)
        cv2.imwrite(filename=os.path.join(results_dir, "Mask {to_save}".format(to_save=jpg)), img=predicted_mask_img)

        # 6. Timing stuff and print statements
        left_to_do = left_to_do - 1
        done += 1
        print(done, "segmentations are done, ", left_to_do, "iterations left to do ")
        stop = time.time()
        duration = stop - start
        duration_list.append(duration)
        print("Pixel classification took", round(duration), "seconds")
        average_duration = sum(duration_list) / len(duration_list)
        print("Approximate time left =", round((left_to_do * average_duration) / 60), "minutes")
        print("Average time for classification [sec]:", round(average_duration))
        print("#############################################################################")


main()