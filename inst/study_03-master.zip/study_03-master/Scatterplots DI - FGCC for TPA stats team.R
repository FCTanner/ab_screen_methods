## study_03 Scatterplots DI - FGCC for TPA stats team

.libPaths("C:/R-packages2")
rm(list=ls())

library(tidyverse)
library(ggplot2); theme_set(theme_bw())
library(broom)
library(ggsci)

`%nin%` <- Negate(`%in%`)

# Data prep ---------------------------------------------------------------


TPA_results <- readxl::read_xlsx("S:/Science/AgFood&Wine/Plant Accelerator/Accelerator Projects 0501 to 0550/0539_PH_UA_TannerFlorian_hyperspec/rawdata/0539 Chickpea.xlsx")

TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 6"] <- "712 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 8"] <- "732 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 6"] <- "716 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 4"] <- "720 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 3"] <- "724 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 7"] <- "728 A"

scores <- read_csv("R out/2020-11-19 Scores.csv")

nursery_FGCC <- read_csv("R out/FGCC/2020-11-12 FGCC results.csv")

sowing_plan <- read_csv("R out/2020-10-27 Sowing plan clean.csv")

nursery_FGCC_wide <- nursery_FGCC %>% pivot_wider(id_cols = c(Pot, Treatment, Rep), names_from = Date, values_from = FGCC, names_glue = "{Date}_{.value}")

dat_all <- nursery_FGCC %>% 
  left_join(scores)

dat_all$DAI <- NA
dat_all$DAI[dat_all$Date == "2020-07-27"] <- "-7 DAI"
dat_all$DAI[dat_all$Date == "2020-08-03"] <- "0 DAI"
dat_all$DAI[dat_all$Date == "2020-08-24"] <- "21 DAI"
dat_all$DAI[dat_all$Date == "2020-09-07"] <- "35 DAI"
dat_all$DAI[dat_all$Date == "2020-09-27"] <- "55 DAI"

# Predictive power of FGCC for DI
# Prep
treatments <- unique(dat_all$Treatment)
dates <- unique(dat_all$Date)

# 2. All scored pots ------------------------------------------------------

# With dead pots ----------------------------------------------------------

# Hack to fix col_types in dataframe to allow for rbind in for loop further down
mod_to_create_outDFs <- lm(c(1,2,3,4) ~ c(2,3,5,5))

mod_coefs_out <- data.frame(matrix(ncol = 7, nrow = 0))
names(mod_coefs_out) <- c("Date", "Treatment", names(tidy(mod_to_create_outDFs)))
write_csv(file = "temp.csv", x = mod_coefs_out)
mod_coefs_out <- read_csv("temp.csv", col_types = "Dccdddd" )

mod_summary_out <- data.frame(matrix(ncol = 14, nrow = 0))
names(mod_summary_out) <- c("Date", "Treatment", names(glance(mod_to_create_outDFs)))
write_csv(file = "temp.csv", x = mod_summary_out)
mod_summary_out <- read_csv("temp.csv", col_types = "Dcdddddddddddd")

# Mods with dead pots
for(d in dates){
  for(t in treatments){
    print(str_c(t, as.Date(d, origin = "1970-01-01"), sep = " "))
    dat_d_t <- dat_all %>% filter(Date == d, Treatment == t)
    length_non_na <- nrow(dat_d_t %>% filter(!is.na(FGCC), !is.na(DI)))
    if(length_non_na > 2){
      mod_d_t <- lm(DI ~ FGCC, data = dat_d_t)
      mod_d_t_summary <- data.frame(Date = as.Date(d, origin = "1970-01-01"), Treatment = t,
                                    glance(mod_d_t))
      mod_d_t_coefs <- data.frame(Date = as.Date(d, origin = "1970-01-01"), Treatment = t,
                                  tidy(mod_d_t))
      
      mod_coefs_out <- bind_rows(mod_coefs_out, mod_d_t_coefs)
      mod_summary_out <- bind_rows(mod_summary_out, mod_d_t_summary)
    }
    else {
      print("There are no data for this date/treatment")
    }
    
  }
  dat_all_t <- dat_all %>% filter(Date == d,  Treatment %nin% 
                                    c("Mutation - Curyo", 
                                      "Cultivar - Curyo", 
                                      "Cultivar - Curyo secondary infection"))
  mod_d <- lm(DI ~ FGCC, data = dat_all_t)
  mod_d_summary <- data.frame(Date = as.Date(d, origin = "1970-01-01"), Treatment = "All treatments",
                              glance(mod_d))
  mod_d_coefs <- data.frame(Date = as.Date(d, origin = "1970-01-01"), Treatment = "All treatments",
                            tidy(mod_d))
  
  mod_coefs_out <- bind_rows(mod_coefs_out, mod_d_coefs) %>% distinct()
  mod_summary_out <- bind_rows(mod_summary_out, mod_d_summary) %>% distinct()
}

p_with_dead_7DBI <- dat_all %>% 
  left_join(mod_coefs_out %>% filter(term == "FGCC")) %>% 
  left_join(mod_summary_out, by = c("Date", "Treatment")) %>% 
  filter(Date == "2020-07-27",
         Treatment %nin% c("Mutation - Curyo", 
                           "Cultivar - Curyo", 
                           "Cultivar - Curyo secondary infection")) %>% 
  ggplot(aes(x= FGCC, y = DI)) +
  geom_point(shape = 1) +
  facet_wrap(~ Treatment) +
  geom_text(aes(x = 0.15, y = 17, label = paste0("Rsq = ",  round(r.squared, 2)))) +
  theme(panel.grid.minor  = element_blank()) +
  labs(title= "2020-07-27 - 7 Days before inoculation ") +
  scale_x_continuous(limits = c(0,1), breaks = c(0,0.25,0.5,0.75, 1))+
  scale_y_continuous(limits = c(0,100), breaks = c(0,25,50,75, 100))



p_with_dead_7DBI


p_with_dead_0DAI <- dat_all %>% 
  left_join(mod_coefs_out %>% filter(term == "FGCC")) %>% 
  left_join(mod_summary_out, by = c("Date", "Treatment")) %>% 
  filter(Date == "2020-08-03",
         Treatment %nin% c("Mutation - Curyo", 
                           "Cultivar - Curyo", 
                           "Cultivar - Curyo secondary infection")) %>% 
  ggplot(aes(x= FGCC, y = DI)) +
  geom_point(shape = 1) +
  facet_wrap(~ Treatment) +
  geom_text(aes(x = 0.15, y = 17, label = paste0("Rsq = ",  round(r.squared, 2)))) +
  theme(panel.grid.minor  = element_blank()) +
  labs(title= "2020-08-03 - Day of inoculation")+
  scale_x_continuous(limits = c(0,1), breaks = c(0,0.25,0.5,0.75, 1))+
  scale_y_continuous(limits = c(0,100), breaks = c(0,25,50,75, 100))

p_with_dead_0DAI

p_with_dead_21DAI <- dat_all %>% 
  left_join(mod_coefs_out %>% filter(term == "FGCC")) %>% 
  left_join(mod_summary_out, by = c("Date", "Treatment")) %>% 
  filter(Date == "2020-08-24",
         Treatment %nin% c("Mutation - Curyo", 
                           "Cultivar - Curyo", 
                           "Cultivar - Curyo secondary infection")) %>% 
  ggplot(aes(x= FGCC, y = DI)) +
  geom_point(shape = 1) +
  facet_wrap(~ Treatment) +
  geom_text(aes(x = 0.15, y = 17, label = paste0("Rsq = ",  round(r.squared, 2)))) +
  theme(panel.grid.minor  = element_blank()) +
  labs(title= "2020-08-24 - 21 days after inoculation")+
  scale_x_continuous(limits = c(0,1), breaks = c(0,0.25,0.5,0.75, 1))+
  scale_y_continuous(limits = c(0,100), breaks = c(0,25,50,75, 100))

p_with_dead_21DAI

p_with_dead_35DAI <- dat_all %>% 
  left_join(mod_coefs_out %>% filter(term == "FGCC")) %>% 
  left_join(mod_summary_out, by = c("Date", "Treatment")) %>% 
  filter(Date == "2020-09-07",
         Treatment %nin% c("Mutation - Curyo", 
                           "Cultivar - Curyo", 
                           "Cultivar - Curyo secondary infection")) %>% 
  ggplot(aes(x= FGCC, y = DI)) +
  geom_point(shape = 1) +
  facet_wrap(~ Treatment) +
  geom_text(aes(x = 0.15, y = 17, label = paste0("Rsq = ",  round(r.squared, 2)))) +
  theme(panel.grid.minor  = element_blank()) +
  labs(title= "2020-09-07 - 35 days after inoculation")+
  scale_x_continuous(limits = c(0,1), breaks = c(0,0.25,0.5,0.75, 1))+
  scale_y_continuous(limits = c(0,100), breaks = c(0,25,50,75, 100))

p_with_dead_35DAI


p_with_dead_55DAI <- dat_all %>% 
  left_join(mod_coefs_out %>% filter(term == "FGCC")) %>% 
  left_join(mod_summary_out, by = c("Date", "Treatment")) %>% 
  filter(Date == "2020-09-27",
         Treatment %nin% c("Mutation - Curyo", 
                           "Cultivar - Curyo", 
                           "Cultivar - Curyo secondary infection")) %>% 
  ggplot(aes(x= FGCC, y = DI)) +
  geom_point(shape = 1) +
  facet_wrap(~ Treatment) +
  geom_text(aes(x = 0.15, y = 17, label = paste0("Rsq = ",  round(r.squared, 2)))) +
  theme(panel.grid.minor  = element_blank()) +
  labs(title= "2020-09-27 - 55 days after inoculation")+
  scale_x_continuous(limits = c(0,1), breaks = c(0,0.25,0.5,0.75, 1))+
  scale_y_continuous(limits = c(0,100), breaks = c(0,25,50,75, 100))

p_with_dead_55DAI



ggsave(p_with_dead_7DBI, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Scatterplots FGCC - DI for TPA stats/7DBI.png", 
       device = "png", width = 18, height = 12, units = "cm", limitsize = F)
ggsave(p_with_dead_7DBI, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Scatterplots FGCC - DI for TPA stats/7DBI.pdf", 
       device = "pdf", width = 18, height = 12, units = "cm", limitsize = F)

ggsave(p_with_dead_0DAI, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Scatterplots FGCC - DI for TPA stats/0DAI.png", 
       device = "png", width = 18, height = 12, units = "cm", limitsize = F)
ggsave(p_with_dead_0DAI, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Scatterplots FGCC - DI for TPA stats/0DAI.pdf", 
       device = "pdf", width = 18, height = 12, units = "cm", limitsize = F)

ggsave(p_with_dead_21DAI, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Scatterplots FGCC - DI for TPA stats/21DAI.png", 
       device = "png", width = 18, height = 12, units = "cm", limitsize = F)
ggsave(p_with_dead_21DAI, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Scatterplots FGCC - DI for TPA stats/21DAI.pdf", 
       device = "pdf", width = 18, height = 12, units = "cm", limitsize = F)

ggsave(p_with_dead_35DAI, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Scatterplots FGCC - DI for TPA stats/35DAI.png", 
       device = "png", width = 18, height = 12, units = "cm", limitsize = F)
ggsave(p_with_dead_35DAI, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Scatterplots FGCC - DI for TPA stats/35DAI.pdf", 
       device = "pdf", width = 18, height = 12, units = "cm", limitsize = F)

ggsave(p_with_dead_55DAI, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Scatterplots FGCC - DI for TPA stats/55DAI.png", 
       device = "png", width = 18, height = 12, units = "cm", limitsize = F)
ggsave(p_with_dead_55DAI, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Scatterplots FGCC - DI for TPA stats/55DAI.pdf", 
       device = "pdf", width = 18, height = 12, units = "cm", limitsize = F)

