### Global exploratory analysis 
.libPaths("C:/R-packages")
rm(list=ls())

library(tidyverse)
library(ggplot2); theme_set(theme_bw())
library(broom)
library(plotly)
library(patchwork)
library(scales)

# 1. Read

TPA_results <- readxl::read_xlsx("S:/Science/AgFood&Wine/Plant Accelerator/Accelerator Projects 0501 to 0550/0539_PH_UA_TannerFlorian_hyperspec/rawdata/0539 Chickpea.xlsx")
 
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 6"] <- "712 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 8"] <- "732 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 6"] <- "716 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 4"] <- "720 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 3"] <- "724 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 7"] <- "728 A"

scores <- read_csv("R out/2020-10-30 Scores.csv")

nursery_FGCC <- read_csv("R out/FGCC/2020-11-12 FGCC results.csv")

sowing_plan <- read_csv("R out/2020-10-27 Sowing plan clean.csv")

nursery_FGCC_wide <- nursery_FGCC %>% pivot_wider(id_cols = c(Pot, Treatment, Rep), names_from = Date, values_from = FGCC, names_glue = "{Date}_{.value}")


dat <- TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
  select(c(Pot, `Projected Shoot Area [pixels]`, `RGB_TV Result area` )) %>% 
  left_join(sowing_plan) %>%
  left_join(scores) %>% 
  left_join(nursery_FGCC_wide)

summary(dat)
dat$FGCCchange3to8wai <- (dat$`2020-09-27_FGCC` /  dat$`2020-08-24_FGCC`) *100
colnames(dat)

pairs_cols <- c("Projected Shoot Area [pixels]", 
                "RGB_TV Result area", 
                "% main stem broken" , 
                "% main stem lesions",
                "% side branches diseased",
                "% LAD",
                "2020-07-27_FGCC",
                "2020-08-03_FGCC",
                "2020-08-24_FGCC",
                "2020-09-27_FGCC",
                "FGCCchange3to8wai",
                "disease_severity_score")

pairs(dat[, pairs_cols], col = as.factor(dat$Treatment))


#  2. Correlation FGCC - TV area
## Outlier removal (TPA RGB TV area < 100)
dat_ol_removed <- dat %>% filter(`RGB_TV Result area` > 100, !is.na(type))

p1 <- ggplot(dat_ol_removed %>% filter(Isolate == "Curyo")) + 
  geom_point(aes(`2020-09-27_FGCC`,`RGB_TV Result area`, color = type, pch = type)) +
  geom_point(data=dat_ol_removed %>% filter(AccessionName %in% c("Kayat_071")) ,
             aes(`2020-09-27_FGCC`,`RGB_TV Result area`, color = type, pch = type), size  = 5) +
  scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
                labels = trans_format("log10", math_format(10^.x)))+
  labs(title = "Fractional Green Canopy Cover vs Top View Area", subtitle =  "8 weeks after inoculation", x = "FGCC", y = "Top view area [pixels]")

p1
# ggsave(p1, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
#                                             " FGCC vs topview area 8 WAI.jpg"),
#               device = "jpg", limitsize = F, width = 14, height = 12, unit = "cm",
#               scale = 1)

# 3. Distribution of 


# 4. Predictors for % Leaf Area diseased

# 4.1 TV area 
mod_TV <- lm(`% LAD` ~ `RGB_TV Result area`, data = dat_ol_removed)
mod_TV_coefs <- tidy(mod_TV)

p2 <- ggplot(dat_ol_removed %>% filter(Isolate == "Curyo"), 
             aes(x = `RGB_TV Result area`, y = `% LAD`, color = type, shape = type)) +
  geom_abline(slope = mod_TV_coefs$estimate[2], intercept = mod_TV_coefs$estimate[1] ) +
  geom_point() +
  geom_point(data=dat_ol_removed %>% filter(AccessionName %in% c("Kayat_071")) ,
             aes(`RGB_TV Result area`,`% LAD`, color = type, pch = type), size  = 5) +
  geom_rug(color = "black", sides="b", alpha = 0.5) +
  labs(title= "Top View Area ", y= "% Leaf area diseased", x = "Topview area [pixels]") +
  geom_text(aes(x = 205000, y = 75, label = paste0("Adj. R-squared = ", round(summary(mod_TV)$adj.r.squared, digits = 4))), 
                color = "black", size = 4) +
  scale_x_continuous(labels = comma)
p2
# ggsave(p2, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
#                                             " Topview area 8 WAI as predictor for percent LAD.jpg"),
#               device = "jpg", limitsize = F, width = 14, height = 12, unit = "cm",
#               scale = 1)


# 4.2 FGCC (on subset)
mod_FGCC <- lm(`% LAD` ~ `2020-09-27_FGCC`, data = dat_ol_removed)
mod_FGCC_coefs <- tidy(mod_FGCC)

p3 <- ggplot(dat_ol_removed %>% filter(Isolate == "Curyo"), 
             aes(x = `2020-09-27_FGCC`, y = `% LAD`, color = type, shape = type)) +
  geom_abline(slope = mod_FGCC_coefs$estimate[2], intercept = mod_FGCC_coefs$estimate[1] ) +
  geom_point() +
  geom_point(data=dat_ol_removed %>% filter(AccessionName %in% c("Kayat_071")) ,
             aes(`2020-09-27_FGCC`,`% LAD`, color = type, pch = type), size  = 5) +
  geom_rug(color = "black", sides="b", alpha = 0.5) +
  labs(title= "Fractional Green Canopy Cover", y= "% Leaf area diseased", x = "FGCC") +
  geom_text(aes(x = 0.65, y = 70, label = paste0("Adj. R-squared = ", round(summary(mod_FGCC)$adj.r.squared, digits = 4))), 
            color = "black", size = 4)
  
p3
# ggsave(p3, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
#                              " FGCC 8 WAI as predictor for percent LAD (imaged genotypes).jpg"),
#        device = "jpg", limitsize = F, width = 14, height = 12, unit = "cm",
#        scale = 1)

# 4.3 FGCC on all scored pots 

dat2 <- scores %>% left_join(nursery_FGCC_wide) %>% left_join(sowing_plan)

mod_FGCC_full <- lm(`% LAD` ~ `2020-09-27_FGCC`, data = dat2)
mod_FGCC_full_coefs <- tidy(mod_FGCC_full)
summary(mod_FGCC_full)
plot(mod_FGCC_full)

p4 <- ggplot(dat2 %>% filter(Isolate == "Curyo"), 
                       aes(x = `2020-09-27_FGCC`, y = `% LAD`, color = type, shape = type)) +
  geom_abline(slope = mod_FGCC_coefs$estimate[2], intercept = mod_FGCC_coefs$estimate[1] ) +
  geom_point() +
  geom_point(data=dat_ol_removed %>% filter(AccessionName %in% c("Kayat_071")) ,
             aes(`2020-09-27_FGCC`,`% LAD`, color = type, pch = type), size  = 5) +
  geom_rug(color = "black", sides="b", alpha = 0.5) +
  labs(title= "Fractional Green Canopy Cover as predictor for\n% Leaf Area Diseased", y= "% Leaf area diseased", x = "FGCC") +
  geom_text(aes(x = 0.65, y = 70, label = paste0("Adj. R-squared = ", round(summary(mod_FGCC_full)$adj.r.squared, digits = 4))), 
            color = "black", size = 4)

p4
# ggsave(p4, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
#                              " FGCC 8 WAI as predictor for percent LAD (all scored genotypes).jpg"),
#        device = "jpg", limitsize = F, width = 14, height = 12, unit = "cm",
#        scale = 1)


p5 <- p2 + p3 + plot_layout(guides = "collect") + plot_annotation(title = "Predictors for % Leaf Area Diseased")

p5
# ggsave(p5, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
#                              " FGCC 8 WAI vs TV as predictors for percent LAD (subset).jpg"),
#        device = "jpg", limitsize = F, width = 26, height = 12, unit = "cm",
#        scale = 1.1)


# 5. Predictors for Disease severity score

# 5.1 Top view area 
mod2_TV <- cor.test(dat_ol_removed$`RGB_TV Result area`, dat_ol_removed$disease_severity_score,
         method = "spearman", exact = F)


p6 <- ggplot(dat_ol_removed %>% filter(Isolate == "Curyo"), 
             aes(x = `RGB_TV Result area`, y = disease_severity_score, color = type, shape = type)) +
  geom_point() +
  geom_point(data=dat_ol_removed %>% filter(AccessionName %in% c("Kayat_071")) ,
             aes(`RGB_TV Result area`, disease_severity_score, color = type, pch = type), size  = 5) +
  geom_rug(color = "black", sides="b", alpha = 0.5) +
  labs(title= "Top View Area ", y= "Disease severity score", x = "Topview area [pixels]") +
  geom_text(aes(x = 205000, y = 8, label = paste0("Spearman's rho = ", 
                                                  round(mod2_TV$estimate, digits = 4),
                                                  "\np-value = < 2.2e-16")), 
            color = "black", size = 4) +
  scale_y_continuous(limits = c(0.8,9.2), breaks = seq(1,9))  +
  scale_x_continuous(labels = comma)
p6

# 5.2 FGCC
mod2_FGCC <- cor.test(dat_ol_removed$`2020-09-27_FGCC`, dat_ol_removed$disease_severity_score,
                    method = "spearman", exact = F)
mod2_FGCC

p7 <- ggplot(dat_ol_removed %>% filter(Isolate == "Curyo"), 
             aes(x = `2020-09-27_FGCC`, y = disease_severity_score, color = type, shape = type)) +
  geom_point() +
  geom_point(data=dat_ol_removed %>% filter(AccessionName %in% c("Kayat_071")) ,
             aes(`2020-09-27_FGCC`, disease_severity_score, color = type, pch = type), size  = 5) +
  geom_rug(color = "black", sides="b", alpha = 0.5) +
  labs(title= "Fractional Green Canopy Cover", y= "Disease severity score", x = "FGCC") +
  geom_text(aes(x = 0.2, y = 2.2, label = paste0("Spearman's rho = ", 
                                                  round(mod2_FGCC$estimate, digits = 4),
                                                  "\np-value = < 2.2e-16")), 
            color = "black", size = 4) +
  scale_y_continuous(limits = c(0.8,9.2), breaks = seq(1,9))  +
  scale_x_continuous(labels = comma)
p7

p8 <- p6 + p7 + plot_layout(guides = "collect") + plot_annotation(title = "Predictors for Disease severity score")

p8

# 
# ggsave(p8, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
#                              " FGCC 8 WAI vs TV as predictors for disease severity scores (subset).jpg"),
#        device = "jpg", limitsize = F, width = 26, height = 12, unit = "cm",
#        scale = 1.1)




