## study_03 Predictive power of FGCC for disease index

.libPaths("C:/R-packages2")
rm(list=ls())

library(tidyverse)
library(ggplot2); theme_set(theme_bw())
library(broom)
library(ggsci)

`%nin%` <- Negate(`%in%`)


# Data prep ---------------------------------------------------------------


TPA_results <- readxl::read_xlsx("S:/Science/AgFood&Wine/Plant Accelerator/Accelerator Projects 0501 to 0550/0539_PH_UA_TannerFlorian_hyperspec/rawdata/0539 Chickpea.xlsx")

TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 6"] <- "712 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 8"] <- "732 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 6"] <- "716 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 4"] <- "720 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 3"] <- "724 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 7"] <- "728 A"

scores <- read_csv("R out/2020-11-19 Scores.csv")

nursery_FGCC <- read_csv("R out/FGCC/2020-11-12 FGCC results.csv")

sowing_plan <- read_csv("R out/2020-10-27 Sowing plan clean.csv")

nursery_FGCC_wide <- nursery_FGCC %>% pivot_wider(id_cols = c(Pot, Treatment, Rep), names_from = Date, values_from = FGCC, names_glue = "{Date}_{.value}")


# 1. TPA pots only -----------------------------------------------------------


dat <- TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
  select(c(Pot, `Projected Shoot Area [pixels]`, `RGB_TV Result area` )) %>% 
  left_join(sowing_plan) %>%
  left_join(scores) %>% 
  left_join(nursery_FGCC_wide)

summary(dat)
dat$FGCCchange3to8wai <- (dat$`2020-09-27_FGCC` /  dat$`2020-08-24_FGCC`) *100
colnames(dat)

pairs_cols <- c("Projected Shoot Area [pixels]", 
                "RGB_TV Result area", 
                "% main stem broken" , 
                "% main stem lesions",
                "% side branches diseased",
                "% LAD",
                "2020-07-27_FGCC",
                "2020-08-03_FGCC",
                "2020-08-24_FGCC",
                "2020-09-27_FGCC",
                "FGCCchange3to8wai",
                "disease_severity_score")

## Outlier removal (TPA RGB TV area < 100)
dat_ol_removed <- dat %>% filter(`RGB_TV Result area` > 100, !is.na(type))



# Predictive power of FGCC for disease index ------------------------------

# Calculate disease index
dat_ol_removed$DI <- (dat_ol_removed$`% main stem broken` +
                        dat_ol_removed$`% main stem lesions` +
                        dat_ol_removed$`% side branches diseased` +
                        dat_ol_removed$`% LAD`)/4

# Predictive power of FGCC for DI(on TPA imaged subset)
# Mods 
mod_FGCC_09_27 <- lm(DI ~ `2020-09-27_FGCC`, data = dat_ol_removed)
mod_FGCC_09_27_coefs <- tidy(mod_FGCC_09_27)

mod_FGCC_09_07 <- lm(DI ~ `2020-09-07_FGCC`, data = dat_ol_removed)
mod_FGCC_09_07_coefs <- tidy(mod_FGCC_09_07)

mod_FGCC_08_24 <- lm(DI ~ `2020-08-24_FGCC`, data = dat_ol_removed)
mod_FGCC_08_24_coefs <- tidy(mod_FGCC_08_24)

mod_FGCC_08_03 <- lm(DI ~ `2020-08-03_FGCC`, data = dat_ol_removed)
mod_FGCC_08_03_coefs <- tidy(mod_FGCC_08_03)

mod_FGCC_07_27 <- lm(DI ~ `2020-07-27_FGCC`, data = dat_ol_removed)
mod_FGCC_07_27_coefs <- tidy(mod_FGCC_07_27)


# Individual graphs -------------------------------------------------------


p_DI_09_27 <- ggplot(dat_ol_removed %>% filter(Isolate == "Curyo"), 
                     aes(x = `2020-09-27_FGCC`, y = DI)) +
  geom_abline(slope = mod_FGCC_09_27_coefs$estimate[2], 
              intercept = mod_FGCC_09_27_coefs$estimate[1],
              color = "gray80",
              linetype = 2,
              size = 1.2) +
  geom_point(alpha= 0.5) +
  # geom_point(data=dat_ol_removed %>% filter(AccessionName %in% c("Kayat_071")) ,
  #            aes(`2020-09-27_FGCC`, DI, color = type, pch = type), size  = 5) +
  geom_rug(color = "black", sides="b", alpha = 0.5) +
  labs(title= "Fractional Green Canopy Cover 55 DAI", y= "Disease index", x = "FGCC") +
  geom_text(aes(x = 0.15, y = 10, label = paste0("R-squared = ", 
                                                 round(summary(mod_FGCC_09_27)$r.squared, 
                                                       digits = 4))), 
            color = "black", size = 4)
p_DI_09_27


p_DI_09_07 <- ggplot(dat_ol_removed %>% filter(Isolate == "Curyo"), 
                     aes(x = `2020-09-07_FGCC`, y = DI)) +
  geom_abline(slope = mod_FGCC_09_07_coefs$estimate[2], 
              intercept = mod_FGCC_09_07_coefs$estimate[1],
              color = "gray80",
              linetype = 2,
              size = 1.2) +
  geom_point(alpha= 0.5) +
  # geom_point(data=dat_ol_removed %>% filter(AccessionName %in% c("Kayat_071")) ,
  #            aes(`2020-09-27_FGCC`, DI, color = type, pch = type), size  = 5) +
  geom_rug(color = "black", sides="b", alpha = 0.5) +
  labs(title= "Fractional Green Canopy Cover 35 DAI", y= "Disease index", x = "FGCC") +
  geom_text(aes(x = 0.15, y = 10, label = paste0("R-squared = ", 
                                                 round(summary(mod_FGCC_09_07)$r.squared, 
                                                       digits = 4))), 
            color = "black", size = 4)
p_DI_09_07


p_DI_08_24 <- ggplot(dat_ol_removed %>% filter(Isolate == "Curyo"), 
                     aes(x = `2020-08-24_FGCC`, y = DI)) +
  geom_abline(slope = mod_FGCC_08_24_coefs$estimate[2], 
              intercept = mod_FGCC_08_24_coefs$estimate[1],
              color = "gray80",
              linetype = 2,
              size = 1.2) +
  geom_point(alpha= 0.5) +
  # geom_point(data=dat_ol_removed %>% filter(AccessionName %in% c("Kayat_071")) ,
  #            aes(`2020-09-27_FGCC`, DI, color = type, pch = type), size  = 5) +
  geom_rug(color = "black", sides="b", alpha = 0.5) +
  labs(title= "Fractional Green Canopy Cover 21 DAI", y= "Disease index", x = "FGCC") +
  geom_text(aes(x = 0.15, y = 10, label = paste0("R-squared = ", 
                                                 round(summary(mod_FGCC_08_24)$r.squared, 
                                                       digits = 4))), 
            color = "black", size = 4)
p_DI_08_24

p_DI_08_03 <- ggplot(dat_ol_removed %>% filter(Isolate == "Curyo"), 
                     aes(x = `2020-08-03_FGCC`, y = DI)) +
  geom_abline(slope = mod_FGCC_08_03_coefs$estimate[2], 
              intercept = mod_FGCC_08_03_coefs$estimate[1],
              color = "gray80",
              linetype = 2,
              size = 1.2) +
  geom_point(alpha= 0.5) +
  # geom_point(data=dat_ol_removed %>% filter(AccessionName %in% c("Kayat_071")) ,
  #            aes(`2020-09-27_FGCC`, DI, color = type, pch = type), size  = 5) +
  geom_rug(color = "black", sides="b", alpha = 0.5) +
  labs(title= "Fractional Green Canopy Cover 0 DAI", y= "Disease index", x = "FGCC") +
  geom_text(aes(x = 0.15, y = 10, label = paste0("R-squared = ", 
                                                 round(summary(mod_FGCC_08_03)$r.squared, 
                                                       digits = 4))), 
            color = "black", size = 4)
p_DI_08_03


# Combined graph for NAPPN ------------------------------------------------


df_21_to_55 <- dat_ol_removed %>%
  pivot_longer(cols = c(`2020-09-27_FGCC`, `2020-09-07_FGCC`,`2020-08-24_FGCC`), values_to= "FGCC", names_to = "DAI")


df_21_to_55$slp <- NA

df_21_to_55$slp[df_21_to_55$DAI == "2020-09-27_FGCC"] <- mod_FGCC_09_27_coefs$estimate[2]
df_21_to_55$slp[df_21_to_55$DAI == "2020-09-07_FGCC"] <- mod_FGCC_09_07_coefs$estimate[2]
df_21_to_55$slp[df_21_to_55$DAI == "2020-08-24_FGCC"] <- mod_FGCC_08_24_coefs$estimate[2]

df_21_to_55$interc <- NA
df_21_to_55$interc[df_21_to_55$DAI == "2020-09-27_FGCC"] <- mod_FGCC_09_27_coefs$estimate[1]
df_21_to_55$interc[df_21_to_55$DAI == "2020-09-07_FGCC"] <- mod_FGCC_09_07_coefs$estimate[1]
df_21_to_55$interc[df_21_to_55$DAI == "2020-08-24_FGCC"] <- mod_FGCC_08_24_coefs$estimate[1]

df_21_to_55$rsq <- 1
df_21_to_55$rsq[df_21_to_55$DAI == "2020-09-27_FGCC"] <- round(summary(mod_FGCC_09_27)$r.squared, digits = 4)
df_21_to_55$rsq[df_21_to_55$DAI == "2020-09-07_FGCC"] <- round(summary(mod_FGCC_09_07)$r.squared, digits = 4)
df_21_to_55$rsq[df_21_to_55$DAI == "2020-08-24_FGCC"] <- round(summary(mod_FGCC_08_24)$r.squared, digits = 4)

df_21_to_55$DAI[df_21_to_55$DAI == "2020-09-27_FGCC"] <- "55 DAI"
df_21_to_55$DAI[df_21_to_55$DAI == "2020-09-07_FGCC"] <- "35 DAI"
df_21_to_55$DAI[df_21_to_55$DAI == "2020-08-24_FGCC"] <- "21 DAI"



p_FGCC_DI <- ggplot(df_21_to_55, aes(x = FGCC, DI, color = DAI, shape = DAI)) +
  geom_abline(aes(slope = slp, intercept = interc, color = DAI)) +
  geom_point(alpha = 0.6) +
  scale_color_jco() +
  facet_wrap(~DAI, nrow = 3) +
  labs(y =" Disease index",
       color = "Days after \ninoculation",
       shape = "Days after \ninoculation") +
  geom_rug(color = "black", sides="b", alpha = 0.5) +
  geom_text(aes(x = 0.15, y = 17, label = paste0("R-squared = ", 
                                                 rsq)), 
            color = "black", size = 3.7)

p_FGCC_DI  

# ggsave(p_FGCC_DI,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index (NAPPN) with R-sq.jpg",
#       limitsize = F,
#       device = "jpg",
#       width = 16,
#       height= 14,
#       dpi = 600,
#       units = "cm")


# Export model summaries --------------------------------------------------

summarystat_09_27 <- cbind(data.frame(Date = "2020-09-27"), glance(mod_FGCC_09_27))
summarystat_09_07 <- cbind(data.frame(Date = "2020-09-07"), glance(mod_FGCC_09_07))
summarystat_08_24 <- cbind(data.frame(Date = "2020-08-24"), glance(mod_FGCC_08_24))

summary_stats <- rbind(summarystat_09_27, summarystat_09_07, summarystat_08_24)

# write_csv(summary_stats, file = "R out/FGCC/Predictive power DI ~ FGCC per date summary stats.csv")



# 2. All scored pots ------------------------------------------------------

dat_all <- nursery_FGCC %>% 
  left_join(scores)

dat_all$DAI <- NA
dat_all$DAI[dat_all$Date == "2020-08-24"] <- "21 DAI"
dat_all$DAI[dat_all$Date == "2020-09-07"] <- "35 DAI"
dat_all$DAI[dat_all$Date == "2020-09-27"] <- "55 DAI"

# Predictive power of FGCC for DI
# Prep
treatments <- unique(dat_all$Treatment)
dates <- unique(dat_all$Date)



# With dead pots ----------------------------------------------------------

# Hack to fix col_types in dataframe to allow for rbind in for loop further down
mod_to_create_outDFs <- lm(c(1,2,3,4) ~ c(2,3,5,5))

mod_coefs_out <- data.frame(matrix(ncol = 7, nrow = 0))
names(mod_coefs_out) <- c("Date", "Treatment", names(tidy(mod_to_create_outDFs)))
write_csv(file = "temp.csv", x = mod_coefs_out)
mod_coefs_out <- read_csv("temp.csv", col_types = "Dccdddd" )

mod_summary_out <- data.frame(matrix(ncol = 14, nrow = 0))
names(mod_summary_out) <- c("Date", "Treatment", names(glance(mod_to_create_outDFs)))
write_csv(file = "temp.csv", x = mod_summary_out)
mod_summary_out <- read_csv("temp.csv", col_types = "Dcdddddddddddd")

# Mods with 
for(d in dates){
  for(t in treatments){
    print(str_c(t, as.Date(d, origin = "1970-01-01"), sep = " "))
    dat_d_t <- dat_all %>% filter(Date == d, Treatment == t)
    length_non_na <- nrow(dat_d_t %>% filter(!is.na(FGCC), !is.na(DI)))
    if(length_non_na > 2){
      mod_d_t <- lm(DI ~ FGCC, data = dat_d_t)
      mod_d_t_summary <- data.frame(Date = as.Date(d, origin = "1970-01-01"), Treatment = t,
                                    glance(mod_d_t))
      mod_d_t_coefs <- data.frame(Date = as.Date(d, origin = "1970-01-01"), Treatment = t,
                                  tidy(mod_d_t))
      
      mod_coefs_out <- bind_rows(mod_coefs_out, mod_d_t_coefs)
      mod_summary_out <- bind_rows(mod_summary_out, mod_d_t_summary)
    }
    else {
      print("There are no data for this date/treatment")
    }

  }
  dat_all_t <- dat_all %>% filter(Date == d,  Treatment %nin% 
                                    c("Mutation - Curyo", 
                                      "Cultivar - Curyo", 
                                      "Cultivar - Curyo secondary infection"))
  mod_d <- lm(DI ~ FGCC, data = dat_all_t)
  mod_d_summary <- data.frame(Date = as.Date(d, origin = "1970-01-01"), Treatment = "All treatments",
                              glance(mod_d))
  mod_d_coefs <- data.frame(Date = as.Date(d, origin = "1970-01-01"), Treatment = "All treatments",
                            tidy(mod_d))
  
  mod_coefs_out <- bind_rows(mod_coefs_out, mod_d_coefs) %>% distinct()
  mod_summary_out <- bind_rows(mod_summary_out, mod_d_summary) %>% distinct()
}

p_with_dead <- dat_all %>% 
  left_join(mod_coefs_out %>% filter(term == "FGCC")) %>% 
  left_join(mod_summary_out, by = c("Date", "Treatment")) %>% 
  filter(Date > "2020-08-23", Treatment %nin% c("Mutation - Curyo", 
                                                "Cultivar - Curyo", 
                                                "Cultivar - Curyo secondary infection")) %>% 
  ggplot(aes(x= FGCC, y = DI)) +
  geom_point(alpha = 0.3) +
  geom_point(shape = 1) +
  facet_grid(DAI ~ Treatment) +
  geom_text(aes(x = 0.15, y = 17, label = paste0("Rsq = ",  round(r.squared, 2))), size = 3) +
  theme(panel.grid.minor  = element_blank())

p_with_dead

# ggsave(p_with_dead,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index with R-sq.png",
#       limitsize = F,
#       device = "png",
#       width = 24,
#       height= 14,
#       dpi = 600,
#       units = "cm",
#       scale = 1.1)
# ggsave(p_with_dead,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index with R-sq.pdf",
#        limitsize = F,
#        device = "pdf",
#        width = 24,
#        height= 14,
#        dpi = 600,
#        units = "cm",
#        scale = 1.1)

p_with_dead_ungrouped <- dat_all %>% 
  filter(Date > "2020-08-23", Treatment %nin% c("Mutation - Curyo", 
                                                "Cultivar - Curyo", 
                                                "Cultivar - Curyo secondary infection")) %>% 
  select(-Treatment) %>% 
  left_join(mod_summary_out %>% 
              filter(Treatment == "All treatments") %>% 
              select(-Treatment),
            by = c("Date")) %>% 

  ggplot(aes(x= FGCC, y = DI)) +
  geom_point(alpha = 0.1) +
  geom_point(shape = 1) +
  facet_wrap(~DAI, nrow =3 ) +
  geom_text(aes(x = 0.15, y = 17, label = paste0("Rsq = ",  round(r.squared, 3))), size = 3) +
  theme(panel.grid.minor  = element_blank())

p_with_dead_ungrouped

# ggsave(p_with_dead_ungrouped,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index with dead pots with R-sq ungrouped.png",
#        limitsize = F,
#        device = "png",
#        width = 14,
#        height= 14,
#        dpi = 600,
#        units = "cm",
#        scale = 1)
# ggsave(p_with_dead_ungrouped,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index with dead pots with R-sq ungrouped.pdf",
#        limitsize = F,
#        device = "pdf",
#        width = 14,
#        height= 14,
#        dpi = 600,
#        units = "cm",
#        scale = 1)

# Without dead pots -------------------------------------------------------

mod_coefs_alive_out <- data.frame(matrix(ncol = 7, nrow = 0))
names(mod_coefs_alive_out) <- c("Date", "Treatment", names(tidy(mod_to_create_outDFs)))
write_csv(file = "temp.csv", x = mod_coefs_alive_out)
mod_coefs_alive_out <- read_csv("temp.csv", col_types = "Dccdddd" )

mod_summary_alive_out <- data.frame(matrix(ncol = 14, nrow = 0))
names(mod_summary_outalive_) <- c("Date", "Treatment", names(glance(mod_to_create_outDFs)))
write_csv(file = "temp.csv", x = mod_summary_alive_out)
mod_summary_alive_out <- read_csv("temp.csv", col_types = "Dcdddddddddddd")


for(d in dates){
  for(t in treatments){
    print(str_c(t, as.Date(d, origin = "1970-01-01"), sep = " "))
    dat_d_t <- dat_all %>% filter(Date == d, Treatment == t, DI < 100)
    length_non_na <- nrow(dat_d_t %>% filter(!is.na(FGCC), !is.na(DI)))
    if(length_non_na > 2){
      mod_d_t <- lm(DI ~ FGCC, data = dat_d_t)
      mod_d_t_summary <- data.frame(Date = as.Date(d, origin = "1970-01-01"), Treatment = t,
                                    glance(mod_d_t))
      mod_d_t_coefs <- data.frame(Date = as.Date(d, origin = "1970-01-01"), Treatment = t,
                                  tidy(mod_d_t))
      
      mod_coefs_alive_out <- bind_rows(mod_coefs_alive_out, mod_d_t_coefs)
      mod_summary_alive_out <- bind_rows(mod_summary_alive_out, mod_d_t_summary)
    }
    else {
      print("There are no data for this date/treatment")
    }
  }
  dat_all_t <- dat_all %>% filter(Date == d,  Treatment %nin% 
                                    c("Mutation - Curyo", 
                                      "Cultivar - Curyo", 
                                      "Cultivar - Curyo secondary infection"),
                                  DI < 100)
  mod_d <- lm(DI ~ FGCC, data = dat_all_t)
  mod_d_summary <- data.frame(Date = as.Date(d, origin = "1970-01-01"), Treatment = "All treatments",
                              glance(mod_d))
  mod_d_coefs <- data.frame(Date = as.Date(d, origin = "1970-01-01"), Treatment = "All treatments",
                            tidy(mod_d))
  
  mod_coefs_alive_out <- bind_rows(mod_coefs_alive_out, mod_d_coefs) %>% distinct()
  mod_summary_alive_out <- bind_rows(mod_summary_alive_out, mod_d_summary) %>% distinct()
}

p_without_dead <-dat_all %>% 
  left_join(mod_coefs_alive_out %>% filter(term == "FGCC")) %>% 
  left_join(mod_summary_alive_out, by = c("Date", "Treatment")) %>% 
  filter(Date > "2020-08-23", 
         Treatment %nin% c("Mutation - Curyo", 
                           "Cultivar - Curyo", 
                           "Cultivar - Curyo secondary infection"),
         DI < 100) %>% 
  ggplot(aes(x= FGCC, y = DI)) +
  geom_point(alpha = 0.3) +
  geom_point(shape = 1) +
  facet_grid(DAI ~ Treatment) +
  geom_text(aes(x = 0.15, y = 17, label = paste0("Rsq = ",  round(r.squared, 2))), size = 3) +
  theme(panel.grid.minor  = element_blank())


p_without_dead


# ggsave(p_without_dead,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index without dead pots with R-sq.png",
#        limitsize = F,
#        device = "png",
#        width = 24,
#        height= 14,
#        dpi = 600,
#        units = "cm",
#        scale = 1.1)
# ggsave(p_without_dead,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index without dead pots with R-sq.pdf",
#        limitsize = F,
#        device = "pdf",
#        width = 24,
#        height= 14,
#        dpi = 600,
#        units = "cm",
#        scale = 1.1)


p_without_dead_ungrouped <- dat_all %>% 
  filter(Date > "2020-08-23", Treatment %nin% c("Mutation - Curyo", 
                                                "Cultivar - Curyo", 
                                                "Cultivar - Curyo secondary infection"),
         DI < 100) %>% 
  select(-Treatment) %>% 
  left_join(mod_summary_alive_out %>% 
              filter(Treatment == "All treatments") %>% 
              select(-Treatment),
            by = c("Date")) %>% 
  
  ggplot(aes(x= FGCC, y = DI)) +
  geom_point(alpha = 0.1) +
  geom_point(shape = 1) +
  facet_wrap(~DAI, nrow =3 ) +
  geom_text(aes(x = 0.15, y = 17, label = paste0("Rsq = ",  round(r.squared, 3))), size = 3) +
  theme(panel.grid.minor  = element_blank())

p_without_dead_ungrouped

# ggsave(p_without_dead_ungrouped,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index without dead pots with R-sq ungrouped.png",
#        limitsize = F,
#        device = "png",
#        width = 14,
#        height= 14,
#        dpi = 600,
#        units = "cm",
#        scale = 1)
# ggsave(p_without_dead_ungrouped,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index without dead pots with R-sq ungrouped.pdf",
#        limitsize = F,
#        device = "pdf",
#        width = 14,
#        height= 14,
#        dpi = 600,
#        units = "cm",
#        scale = 1)


# Making plots witout r-sq ------------------------------------------------

no_rsq_p_dat <- dat_all %>% 
  left_join(mod_coefs_out %>% filter(term == "FGCC")) %>% 
  left_join(mod_summary_out, by = c("Date", "Treatment")) %>% 
  filter(Date > "2020-08-23", Treatment %nin% c("Mutation - Curyo", 
                                                "Cultivar - Curyo", 
                                                "Cultivar - Curyo secondary infection"))

p_with_dead_no_rsq <- ggplot(aes(x= FGCC, y = DI), data = no_rsq_p_dat) +
  geom_point(alpha = 0.3) +
  geom_point(shape = 1) +
  facet_grid(DAI ~ Treatment) +
  theme(panel.grid.minor  = element_blank())

p_with_dead_no_rsq

# ggsave(p_with_dead_no_rsq,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index without R-sq.png",
#       limitsize = F,
#       device = "png",
#       width = 24,
#       height= 14,
#       dpi = 600,
#       units = "cm",
#       scale = 1.1)
# ggsave(p_with_dead,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index without R-sq.pdf",
#        limitsize = F,
#        device = "pdf",
#        width = 24,
#        height= 14,
#        dpi = 600,
#        units = "cm",
#        scale = 1.1)


p_with_dead_ungrouped_no_rsq <- dat_all %>% 
  filter(Date > "2020-08-23", Treatment %nin% c("Mutation - Curyo", 
                                                "Cultivar - Curyo", 
                                                "Cultivar - Curyo secondary infection")) %>% 
  select(-Treatment) %>% 
  left_join(mod_summary_out %>% 
              filter(Treatment == "All treatments") %>% 
              select(-Treatment),
            by = c("Date")) %>% 
  
  ggplot(aes(x= FGCC, y = DI)) +
  geom_point(alpha = 0.1) +
  geom_point(shape = 1) +
  facet_wrap(~DAI, nrow =3 ) +
  theme(panel.grid.minor  = element_blank())

p_with_dead_ungrouped_no_rsq

# ggsave(p_with_dead_ungrouped_no_rsq,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index with dead pots without R-sq ungrouped.png",
#        limitsize = F,
#        device = "png",
#        width = 14,
#        height= 14,
#        dpi = 600,
#        units = "cm",
#        scale = 1)
# ggsave(p_with_dead_ungrouped_no_rsq,
#        file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Predictive power of FGCC for Disease Index with dead pots without R-sq ungrouped.pdf",
#        limitsize = F,
#        device = "pdf",
#        width = 14,
#        height= 14,
#        dpi = 600,
#        units = "cm",
#        scale = 1)



# Comparing model stats ---------------------------------------------------

mod_coefs_alive_out$dead_removed <- T
mod_coefs_out$dead_removed <- F
mod_coefs <- rbind(mod_coefs_alive_out,mod_coefs_out)

mod_summary_alive_out$dead_removed <- T
mod_summary_out$dead_removed <- F
mod_summary <- mod_summary_alive_out %>% 
  select(-(X1:X14)) %>% 
  bind_rows(mod_summary_out)

mod_summary %>% 
  filter(Treatment == "All treatments") %>% 
  ggplot(aes(y = as.factor(Date), x = r.squared, color = dead_removed, fill = dead_removed)) +
  geom_col(position = position_dodge())
