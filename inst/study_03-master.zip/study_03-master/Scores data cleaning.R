### 2020-10-28 Scores data cleaning
.libPaths("C:/R-packages2")
rm(list=ls())

library(tidyverse)
library(patchwork)
scores_NVT <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/2020-09-28 Scoring results/Original/Results Assessment NVT AB Curyo.xlsx")
scores_FLIP <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/2020-09-28 Scoring results/Original/Results Assessment Wild Cicer FLIP Curyo 2020.xlsx")
scores_secondary <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/2020-09-28 Scoring results/Original/Results Assessment Secondary infection AB Curyo Tanner.xlsx",
                                      na = "NA")
scores_PBA <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/2020-09-28 Scoring results/Original/2020 PBA Curyo isolate screen Method and Results.xlsx",
                                sheet = "PBA Curyo isolate")[,0:11] %>% select(-DI) %>% rename(score_JD = `1to9`, Entry = ENTRY, Name = NAME)
scores_FLIP <- scores_FLIP %>% rename(Entry = ENTRY, Name = NAME)

scores <- rbind(scores_NVT, scores_FLIP, scores_secondary) 
scores$score_JD <- NA
scores <- rbind(scores, scores_PBA)
summary(scores)

scores$Pot[scores$Pot == "Gen 6"] <- "712 A"
scores$Pot[scores$Pot == "How 8"] <- "732 A"
scores$Pot[scores$Pot == "How 6"] <- "716 A"
scores$Pot[scores$Pot == "Gen 4"] <- "720 A"
scores$Pot[scores$Pot == "How 3"] <- "724 A"
scores$Pot[scores$Pot == "Gen 7"] <- "728 A"

component_scores_2020 <- scores %>% 
  janitor::clean_names() %>% 
  select(-isolate, -entry, -name, -score_jd) %>% 
  mutate(di = (percent_main_stem_broken +
                 percent_main_stem_lesions +
                 percent_side_branches_diseased + 
                 percent_lad) / 4)

skimr::skim(component_scores_2020)
write_csv(component_scores_2020, "R out/component_scores_2020.csv")


pmsb <- ggplot(scores, aes(as.factor(`% main stem broken`))) + 
  geom_bar(stat = "count")
pmsl <- ggplot(scores, aes(as.factor(`% main stem lesions`))) + 
  geom_bar(stat = "count")
psbd <- ggplot(scores, aes(as.factor(`% side branches diseased`))) + 
  geom_bar(stat = "count")
plad <- ggplot(scores, aes(as.factor(`% LAD`))) + 
  geom_bar(stat = "count")
pmsb + pmsl + psbd + plad


colnames(scores)
pairs(scores[6:9])
hist(scores$`% main stem broken`)
hist(scores$`% main stem lesions`)
hist(scores$`% side branches diseased`)
hist(scores$`% LAD`)

# Calculate disease severity scores


#  Calculating score per category
# % main stems with lesions
scores$mslscore <- NA

for(i in seq_along(1:nrow(scores))){
  if(scores$`% main stem lesions`[i] == 0 &
     scores$`% LAD`[i] == 0){
    scores$mslscore <- 1
  }
  else if(scores$`% LAD`[i] > 0 &
     scores$`% main stem lesions`[i] == 0){
    scores$mslscore[i] <- 2
  }
  else if(scores$`% main stem lesions`[i] > 0 &
          scores$`% main stem lesions`[i] <= 30){
    scores$mslscore[i] <- 3
  }
  else if(scores$`% main stem lesions`[i] > 30 &
          scores$`% main stem lesions`[i] <= 60){
    scores$mslscore[i] <- 4
  }
  else if(scores$`% main stem lesions`[i] > 60 &
          scores$`% main stem lesions`[i] <= 80){
    scores$mslscore[i] <- 5
  }
  else if(scores$`% main stem lesions`[i] > 80 &
          scores$`% main stem lesions`[i] <= 100 &
          scores$`% main stem broken`[i] <= 50){
    scores$mslscore[i] <- 6
  }
  else if(scores$`% main stem lesions`[i] > 80 &
          scores$`% main stem lesions`[i] <= 100 &
          scores$`% main stem broken`[i] <= 75){
    scores$mslscore[i] <- 7
  }
  else if(scores$`% main stem lesions`[i] > 80 &
          scores$`% main stem lesions`[i] <= 100 &
          scores$`% main stem broken`[i] <= 100 &
          scores$`% LAD`[i] <=90){
    scores$mslscore[i] <- 8
  }
  else{
    scores$mslscore[i] <- 9
  }
}

hist(scores$mslscore)
table(scores$mslscore)

# % main stems broken
scores$msbscore <- NA

for(i in seq_along(1:nrow(scores))){
  if(scores$`% main stem broken`[i] == 0 &
     scores$`% LAD`[i] == 0){
    scores$msbscore <- 1
  }
  else if(scores$`% LAD`[i] > 0 &
          scores$`% main stem broken`[i] == 0){
    scores$msbscore[i] <- 2
  }
  else if(scores$`% main stem broken`[i] < 0 &
          scores$`% main stem broken`[i] < 5){
            scores$msbscore[i] <- 3
  }
  else if(scores$`% main stem broken`[i] >= 5 &
          scores$`% main stem broken`[i] < 40){
    scores$msbscore[i] <- 4
  }
  else if(scores$`% main stem broken`[i] >= 40 &
          scores$`% main stem broken`[i] < 50){
    scores$msbscore[i] <- 5
  }
  else if(scores$`% main stem broken`[i] >= 50 &
          scores$`% main stem broken`[i] < 75){
    scores$msbscore[i] <- 6
  }
  else if(scores$`% main stem broken`[i] >= 75 &
          scores$`% main stem broken`[i] < 100){
    scores$msbscore[i] <- 7
  }
  else if(scores$`% main stem broken`[i] == 100 &
          scores$`% LAD`[i] < 100){
    scores$msbscore[i] <- 8
  }
  else{
    scores$msbscore[i] <- 9
  }
}

hist(scores$msbscore)
table(scores$msbscore)

# % side branches diseased
scores$sbdscore <- NA

for(i in seq_along(1:nrow(scores))){
  if(scores$`% side branches diseased`[i] == 0 &
     scores$`% LAD`[i] == 0){
    scores$sbdscore <- 1
  }
  else if(scores$`% LAD`[i] > 0 &
          scores$`% side branches diseased`[i] == 0){
    scores$sbdscore[i] <- 2
  }
  else if(scores$`% side branches diseased`[i] > 0 &
          scores$`% side branches diseased`[i] <= 10){
    scores$sbdscore[i] <- 3
  }
  else if(scores$`% side branches diseased`[i] > 10 &
          scores$`% side branches diseased`[i] <= 25){
    scores$sbdscore[i] <- 4
  }
  else if(scores$`% side branches diseased`[i] > 25 &
          scores$`% side branches diseased`[i] <= 65){
    scores$sbdscore[i] <- 5
  }
  else if(scores$`% side branches diseased`[i] > 65 &
          scores$`% side branches diseased`[i] <= 85){
    scores$sbdscore[i] <- 6
  }
  else if(scores$`% side branches diseased`[i] > 85 &
          scores$`% side branches diseased`[i] <= 95){
    scores$sbdscore[i] <- 7
  }
  else if(scores$`% side branches diseased`[i] > 95 &
          scores$`% side branches diseased`[i] <= 100 &
          scores$`% LAD`[i] < 100)
    {
    scores$sbdscore[i] <- 8
  }
  else{
    scores$sbdscore[i] <- 9
  }
}


hist(scores$sbdscore)
table(scores$sbdscore)

# % leaf area diseased 
scores$ladscore <- NA

for(i in seq_along(1:nrow(scores))){
  if(scores$`% LAD`[i] == 0){
    scores$ladscore <- 1
  }
  else if(scores$`% LAD`[i] > 0 &
          scores$`% LAD`[i] <= 2){
    scores$ladscore[i] <- 2
  }
  else if(scores$`% LAD`[i] > 0 &
          scores$`% LAD`[i] <= 2){
    scores$ladscore[i] <- 2
  }
  else if(scores$`% LAD`[i] > 2 &
          scores$`% LAD`[i] <= 10){
    scores$ladscore[i] <- 3
  }
  else if(scores$`% LAD`[i] > 10 &
          scores$`% LAD`[i] <= 20){
    scores$ladscore[i] <- 4
  }
  else if(scores$`% LAD`[i] > 20 &
          scores$`% LAD`[i] <= 50){
    scores$ladscore[i] <- 5
  }
  else if(scores$`% LAD`[i] > 50 &
          scores$`% LAD`[i] <= 60){
    scores$ladscore[i] <- 6
  }
  else if(scores$`% LAD`[i] > 60 &
          scores$`% LAD`[i] <= 75){
    scores$ladscore[i] <- 7
  }
  else if(scores$`% LAD`[i] > 75 &
          scores$`% LAD`[i] <= 90){
    scores$ladscore[i] <- 8
  }
  else{
    scores$ladscore[i] <- 9
  }
}


hist(scores$ladscore)
table(scores$ladscore)



# Calculating weighted final score
scores$disease_severity_score <- round((3*scores$mslscore + 2*scores$msbscore + scores$sbdscore + scores$ladscore)/7)


hist(scores$disease_severity_score)
table(scores$disease_severity_score)


scores_out <- scores %>% select(Pot, `% main stem broken`, `% main stem lesions`, `% side branches diseased`, `% LAD`, disease_severity_score, score_JD)
scores_out$DI <- (scores_out$`% main stem broken` + scores_out$`% main stem lesions` + scores_out$`% side branches diseased` + scores_out$`% LAD`)/4
# write_csv(scores_out, path = paste0("R out/", format(Sys.Date()), " Scores.csv"))



# Export outfile for clean repo (predict_DI) ------------------------------


scores_out_clean_repo <- scores_out %>% janitor::clean_names() %>% select(-disease_severity_score, -score_jd) %>% mutate(date = "2020-09-27")

scores_out_clean_repo$pot[scores_out_clean_repo$pot == "Gen 6"] <- "712 A"
scores_out_clean_repo$pot[scores_out_clean_repo$pot == "How 8"] <- "732 A"
scores_out_clean_repo$pot[scores_out_clean_repo$pot == "How 6"] <- "716 A"
scores_out_clean_repo$pot[scores_out_clean_repo$pot == "Gen 4"] <- "720 A"
scores_out_clean_repo$pot[scores_out_clean_repo$pot == "How 3"] <- "724 A"
scores_out_clean_repo$pot[scores_out_clean_repo$pot == "Gen 7"] <- "728 A"
# write_csv(scores_out_clean_repo, "../../predict_DI/Data/scores.csv")


scores_out_classify_repo <- scores_out %>% janitor::clean_names() %>% mutate(date = "2020-09-27")
scores_out_classify_repo$pot[scores_out_classify_repo$pot == "Gen 6"] <- "712 A"
scores_out_classify_repo$pot[scores_out_classify_repo$pot == "How 8"] <- "732 A"
scores_out_classify_repo$pot[scores_out_classify_repo$pot == "How 6"] <- "716 A"
scores_out_classify_repo$pot[scores_out_classify_repo$pot == "Gen 4"] <- "720 A"
scores_out_classify_repo$pot[scores_out_classify_repo$pot == "How 3"] <- "724 A"
scores_out_classify_repo$pot[scores_out_classify_repo$pot == "Gen 7"] <- "728 A"

# write_csv(scores_out_classify_repo, "../../classify_DI/Data/scores.csv")