#!/usr/bin/env python
# coding: utf-8

import cv2
import os
import numpy as np

base_dir = "../Cropping approach/Data/2020-09-09 Segmented pots/Out"
out_dir = ""
pictures = os.listdir(base_dir)

def stackImages(scale, imgArray):
    rows = len(imgArray)
    cols = len(imgArray[0])
    rowsAvailable = isinstance(imgArray[0], list)
    width = imgArray[0][0].shape[1]
    height = imgArray[0][0].shape[0]
    if rowsAvailable:
        for x in range(0, rows):
            for y in range(0, cols):
                if imgArray[x][y].shape[:2] == imgArray[0][0].shape[:2]:
                    imgArray[x][y] = cv2.resize(imgArray[x][y], (0, 0), None, scale, scale)
                else:
                    imgArray[x][y] = cv2.resize(imgArray[x][y], (imgArray[0][0].shape[1], imgArray[0][0].shape[0]),
                                                None, scale, scale)
                if len(imgArray[x][y].shape) == 2: imgArray[x][y] = cv2.cvtColor(imgArray[x][y], cv2.COLOR_GRAY2BGR)
        imageBlank = np.zeros((height, width, 3), np.uint8)
        hor = [imageBlank] * rows
        hor_con = [imageBlank] * rows
        for x in range(0, rows):
            hor[x] = np.hstack(imgArray[x])
        ver = np.vstack(hor)
    else:
        for x in range(0, rows):
            if imgArray[x].shape[:2] == imgArray[0].shape[:2]:
                imgArray[x] = cv2.resize(imgArray[x], (0, 0), None, scale, scale)
            else:
                imgArray[x] = cv2.resize(imgArray[x], (imgArray[0].shape[1], imgArray[0].shape[0]), None, scale, scale)
            if len(imgArray[x].shape) == 2: imgArray[x] = cv2.cvtColor(imgArray[x], cv2.COLOR_GRAY2BGR)
        hor = np.hstack(imgArray)
        ver = hor
    return ver


lower_green = np.array([30,20,30])
upper_green = np.array([100,255,255])
kernel_opening = np.ones((5,5),np.uint8)
kernel_closing = np.ones((3,3), np.uint8)

for filename in pictures[50:100]:
    path = os.path.join(base_dir, filename)
    img = cv2.imread(path)


    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, lower_green, upper_green)
    # Opening (morphological)
    eroded = cv2.erode(mask, kernel_opening, iterations=2)
    dilated = cv2.dilate(eroded, kernel_opening, iterations = 1)
    hsv_thr = cv2.bitwise_and(img, img, mask = dilated)
    print((dilated.shape))
    # Reshape into 1d array,
    # count white pixels,
    # output to csv
    # done!
    img_stack = stackImages(0.6, ([dilated, hsv_thr], [dilated, hsv_thr]))
    cv2.imshow("Stack", img_stack)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

