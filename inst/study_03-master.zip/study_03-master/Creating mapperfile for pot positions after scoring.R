## study_03 Creating mapperfile for pot positions after scoring

.libPaths("C:/R-packages2")
rm(list=ls())

library(tidyverse)

pot_positions <- readxl::read_excel("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/2021-02-24 New plan after scoring.xlsx")
pot_positions$Pot <- str_replace(pot_positions$Pot, "Hozart", 'Howzat')


pots <- pot_positions$Pot
first_pots <- pots[seq(1, length(pots),16)]


placed_codes <- data.frame(code = seq(from = 1, to = 273, by= 16), Pot = first_pots)

mapper <- data.frame("Pot number",	1,	2,	3,	4,	5,	6,	7,	8,	9,	10,	11,	12,	13,	14,	15,	16)
names(mapper) <- mapper

# mapper$`Pot number` <- placed_codes$code


for(pot in first_pots){
  index <- which(pots == pot)
  sixteen <- c(pot, pots[index:(index+15)])
  print(sixteen)
  mapper <- rbind(mapper, sixteen)
}

mapper <- mapper %>% 
  filter(`Pot number` != "Pot number") %>% 
  rename(Pot = `Pot number`) %>% 
  left_join(placed_codes) %>% 
  select(-Pot) %>% 
  rename(`Pot number` = code) %>% 
  relocate(`Pot number`)

# write_csv(mapper, "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/2021-02-24 Experimental design position matching after scoring.csv")
