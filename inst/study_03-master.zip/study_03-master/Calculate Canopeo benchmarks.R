### Calculate Canopeo benchmarks
.libPaths("C:/R-packages")
rm(list=ls())

# Load pixel values of test subset of training data 
pixval <- read.csv("C:/Users/a1789609/r-projects/adelaide/study_03/study_03/Pixel-based segmentation/Training data/2021-01-12 Pixel values for training data/Pixel values test set data.csv")
summary(pixval)

# Set possible Canopeo values
grid <- expand.grid(p1 = seq(0.9,1.5,0.025), p2 = seq(0.9,1.3,0.025), p3 = seq(5,30, 5), recall = NA , precision = NA, F1_score = NA)

# Function wrap for grid search
calculateF1 <- function(df, params){
  # Calculate ratios
  df$ratioRG <- df$PR/df$PG
  df$ratioBG <- df$PB/df$PG
  df$excessGI <- 2*df$PG - df$PR - df$PB
  
  for(i in 1:nrow(params)){
    # Predict with Canopeo algorithm
    df$canopeo_pred <- 0
    df$canopeo_pred[df$ratioRG < params$p1[i] & df$ratioBG < params$p2[i] & df$excessGI > params$p3[i]] <- 1
    # Calculate recall and precision
    true_pos <- length(df$canopeo_pred[df$canopeo_pred == 1 & df$Segmentation == 1])
    false_pos <- length(df$canopeo_pred[df$canopeo_pred == 1 & df$Segmentation == 0])
    false_neg <- length(df$canopeo_pred[df$canopeo_pred == 0 & df$Segmentation == 1])
    params$precision[i] <- true_pos/(true_pos + false_pos)
    params$recall[i] <- true_pos/(true_pos + false_neg)
  }
  params$F1_score <- (2*params$recall*params$precision)/(params$recall + params$precision)
  return(params)
}


results <- calculateF1(pixval, grid)

# Find out which values are best 
head(results[order(-results$F1_score),])

