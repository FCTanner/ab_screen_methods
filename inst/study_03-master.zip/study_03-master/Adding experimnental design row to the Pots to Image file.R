### 2020-09-17 Adding experimnental design row to the "pots to image" file 
.libPaths("C:/R-packages")
rm(list=ls())

library(tidyverse)

imagethis <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/2020-09-17 Pots to image.xlsx")
rows <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/2020-09-17 which pot is which row.xlsx")

out <- left_join(imagethis, rows)
write.csv(out, "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/2020-09-17 Pots to image with rows.csv")
