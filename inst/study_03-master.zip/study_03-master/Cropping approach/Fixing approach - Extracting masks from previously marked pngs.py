#!/usr/bin/env python
# coding: utf-8

import cv2
import os
import numpy as np

base_dir = "C:/Users/a1789609/r-projects/adelaide/study_03/study_03/Cropping approach/Data/2020-09-01 manual masking/Marked"
out_dir = "C:/Users/a1789609/r-projects/adelaide/study_03/study_03/Cropping approach/Data/2020-09-01 manual masking/Masks"
previous_masks = os.listdir(base_dir)

def detect_circles(input_img):
    # Threshold for red
    hsv = cv2.cvtColor(input_img, cv2.COLOR_BGR2HSV)

    lower_red = np.array([0, 255, 255])
    upper_red = np.array([0, 255, 255])
    red = cv2.inRange(hsv, lower_red, upper_red)
    # Detect manual circles
    gaussian = cv2.GaussianBlur(red, ksize=(15,15), sigmaX=cv2.BORDER_DEFAULT)
    circles = cv2.HoughCircles(gaussian, cv2.HOUGH_GRADIENT, 1.2, minDist=500, minRadius=363, maxRadius=363)
    circles_rounded = np.uint16(np.around(circles))
    # print(circles_rounded.shape[1], "Circles found")
    return(circles_rounded)

def make_mask(circles):
    # make png file with rounded circles
    mask_blank = np.zeros((4608, 6912, 3))
    mask_blank[:,:] = (255,255,255)
    print(mask_blank.shape)
    for circle in circles[0, :]:
        mask_circles = cv2.circle(img = mask_blank, center = (circle[0], circle[1]),
                                  radius = 364, color = (0,0,255),
                                  thickness= 18)
    return(mask_circles)



for filename in previous_masks:
    path = os.path.join(base_dir, filename)
    previous = cv2.imread(path)
    circles = detect_circles(previous)
    # print(previous.shape)
    # print(circles)
    mask = make_mask(circles)
    # print(mask.shape)
    # cv2.imshow("Mask", cv2.resize(mask, (600,400)))
    # cv2.waitKey(900)
    cv2.imwrite(filename=os.path.join(out_dir, "{mask}".format(mask = filename)),
                    img = mask)
    # break