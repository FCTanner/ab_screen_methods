### study_03 Exploring pixel counts and FGCC 
.libPaths("C:/R-packages2")
rm(list=ls())

library(tidyverse)
library(broom)
library(ggplot2); theme_set(theme_bw())
library(plotly)

`%nin%` <- Negate(`%in%`)

# Load pixel counts  ------------------------------------------------------


NN_pixels_07_27 <- read_csv("D:/repos/adelaide/study_03/study_03/Post-segmentation operations/Pixel count results/2020-07-27/NN/Pixel counts 2020-07-27 NN.csv")
NN_pixels_07_27$Date <- "2020-07-27"
NN_pixels_07_27$Pot <- str_remove(NN_pixels_07_27$Filename, pattern = ("Mask 2020-07-27 "))
NN_pixels_07_27$Pot <- str_remove(NN_pixels_07_27$Pot, pattern = (" .jpg"))

NN_pixels_08_03 <- read_csv("D:/repos/adelaide/study_03/study_03/Post-segmentation operations/Pixel count results/2020-08-03/NN/Pixel counts 2020-08-03 NN.csv")
NN_pixels_08_03$Date <- "2020-08-03"
NN_pixels_08_03$Pot <- str_remove(NN_pixels_08_03$Filename, pattern = ("Mask 2020-08-03 "))
NN_pixels_08_03$Pot <- str_remove(NN_pixels_08_03$Pot, pattern = (" .jpg"))

NN_pixels_08_07 <- read_csv("D:/repos/adelaide/study_03/study_03/Post-segmentation operations/Pixel count results/2020-08-07/NN/Pixel counts 2020-08-07 NN.csv")
NN_pixels_08_07$Date <- "2020-08-07"
NN_pixels_08_07$Pot <- str_remove(NN_pixels_08_07$Filename, pattern = ("Mask 2020-08-07 "))
NN_pixels_08_07$Pot <- str_remove(NN_pixels_08_07$Pot, pattern = (" .jpg"))

NN_pixels_08_17 <- read_csv("D:/repos/adelaide/study_03/study_03/Post-segmentation operations/Pixel count results/2020-08-17/NN/Pixel counts 2020-08-17 NN.csv")
NN_pixels_08_17$Date <- "2020-08-17"
NN_pixels_08_17$Pot <- str_remove(NN_pixels_08_17$Filename, pattern = ("Mask 2020-08-17 "))
NN_pixels_08_17$Pot <- str_remove(NN_pixels_08_17$Pot, pattern = (" .jpg"))

NN_pixels_08_24 <- read_csv("D:/repos/adelaide/study_03/study_03/Post-segmentation operations/Pixel count results/2020-08-24/NN/Pixel counts 2020-08-24 NN.csv")
NN_pixels_08_24$Date <- "2020-08-24"
NN_pixels_08_24$Pot <- str_remove(NN_pixels_08_24$Filename, pattern = ("Mask 2020-08-24 "))
NN_pixels_08_24$Pot <- str_remove(NN_pixels_08_24$Pot, pattern = (" .jpg"))

NN_pixels_08_31 <- read_csv("D:/repos/adelaide/study_03/study_03/Post-segmentation operations/Pixel count results/2020-08-31/NN/Pixel counts 2020-08-31 NN.csv")
NN_pixels_08_31$Date <- "2020-08-31"
NN_pixels_08_31$Pot <- str_remove(NN_pixels_08_31$Filename, pattern = ("Mask 2020-08-31 "))
NN_pixels_08_31$Pot <- str_remove(NN_pixels_08_31$Pot, pattern = (" .jpg"))

NN_pixels_09_07 <- read_csv("D:/repos/adelaide/study_03/study_03/Post-segmentation operations/Pixel count results/2020-09-07/NN/Pixel counts 2020-09-07 NN.csv")
NN_pixels_09_07$Date <- "2020-09-07"
NN_pixels_09_07$Pot <- str_remove(NN_pixels_09_07$Filename, pattern = ("Mask 2020-09-07 "))
NN_pixels_09_07$Pot <- str_remove(NN_pixels_09_07$Pot, pattern = (" .jpg"))

NN_pixels_09_14 <- read_csv("D:/repos/adelaide/study_03/study_03/Post-segmentation operations/Pixel count results/2020-09-14/NN/Pixel counts 2020-09-14 NN.csv")
NN_pixels_09_14$Date <- "2020-09-14"
NN_pixels_09_14$Pot <- str_remove(NN_pixels_09_14$Filename, pattern = ("Mask 2020-09-14 "))
NN_pixels_09_14$Pot <- str_remove(NN_pixels_09_14$Pot, pattern = (" .jpg"))

NN_pixels_09_27 <- read_csv("D:/repos/adelaide/study_03/study_03/Post-segmentation operations/Pixel count results/2020-09-27/NN/Pixel counts 2020-09-27 NN.csv")
NN_pixels_09_27$Date <- "2020-09-27"
NN_pixels_09_27$Pot <- str_remove(NN_pixels_09_27$Filename, pattern = ("Mask 2020-09-27 "))
NN_pixels_09_27$Pot <- str_remove(NN_pixels_09_27$Pot, pattern = (" .jpg"))

# After scoring
NN_pixels_10_06 <- read_csv("D:/repos/adelaide/study_03/study_03/Pixel-based segmentation/After scoring/Pixel_counts/NN_masks/2020-10-06_erode_4by4_dilate_3by3.csv")
NN_pixels_10_06$Date <- "2020-10-06"
NN_pixels_10_06$Pot <- str_remove(NN_pixels_10_06$Filename, pattern = ("Mask 2020-10-06 "))
NN_pixels_10_06$Pot <- str_remove(NN_pixels_10_06$Pot, pattern = (" .jpg"))

NN_pixels_10_12 <- read_csv("D:/repos/adelaide/study_03/study_03/Pixel-based segmentation/After scoring/Pixel_counts/NN_masks/2020-10-12_erode_4by4_dilate_3by3.csv")
NN_pixels_10_12$Date <- "2020-10-12"
NN_pixels_10_12$Pot <- str_remove(NN_pixels_10_12$Filename, pattern = ("Mask 2020-10-12 "))
NN_pixels_10_12$Pot <- str_remove(NN_pixels_10_12$Pot, pattern = (" .jpg"))

NN_pixels_10_19 <- read_csv("D:/repos/adelaide/study_03/study_03/Pixel-based segmentation/After scoring/Pixel_counts/NN_masks/2020-10-19_erode_4by4_dilate_3by3.csv")
NN_pixels_10_19$Date <- "2020-10-19"
NN_pixels_10_19$Pot <- str_remove(NN_pixels_10_19$Filename, pattern = ("Mask 2020-10-19 "))
NN_pixels_10_19$Pot <- str_remove(NN_pixels_10_19$Pot, pattern = (" .jpg"))

NN_pixels_10_26 <- read_csv("D:/repos/adelaide/study_03/study_03/Pixel-based segmentation/After scoring/Pixel_counts/NN_masks/2020-10-26_erode_4by4_dilate_3by3.csv")
NN_pixels_10_26$Date <- "2020-10-26"
NN_pixels_10_26$Pot <- str_remove(NN_pixels_10_26$Filename, pattern = ("Mask 2020-10-26 "))
NN_pixels_10_26$Pot <- str_remove(NN_pixels_10_26$Pot, pattern = (" .jpg"))

NN_pixels_11_02 <- read_csv("D:/repos/adelaide/study_03/study_03/Pixel-based segmentation/After scoring/Pixel_counts/NN_masks/2020-11-02_erode_4by4_dilate_3by3.csv")
NN_pixels_11_02$Date <- "2020-11-02"
NN_pixels_11_02$Pot <- str_remove(NN_pixels_11_02$Filename, pattern = ("Mask 2020-11-02 "))
NN_pixels_11_02$Pot <- str_remove(NN_pixels_11_02$Pot, pattern = (" .jpg"))


# Combine dates -----------------------------------------------------------


NN_pixels <- rbind(NN_pixels_07_27, NN_pixels_08_03, NN_pixels_08_07, NN_pixels_08_17, NN_pixels_08_24, NN_pixels_08_31, NN_pixels_09_07, NN_pixels_09_14, NN_pixels_09_27)
NN_pixels$Source <- "Nursery"

NN_pixels_after_scoring <- rbind(NN_pixels_10_06, NN_pixels_10_12, NN_pixels_10_19, NN_pixels_10_26, NN_pixels_11_02)
NN_pixels_after_scoring$Source <- "Nursery"


# Calculate FGCC ----------------------------------------------------------

 
Pot_size_nursery = pi * (532/2)^2
NN_pixels$FGCC <- NN_pixels$n_mask/Pot_size_nursery


# Add TPA pixel counts  ---------------------------------------------------


NN_pixels_TPA <- read_csv("D:/repos/adelaide/study_03/study_03/FGCC validation TPA/Pixel counting/Pixel count results/NN no neighbors/Pixel counts  NN no neighbors.csv")
NN_pixels_TPA$Date <- "2020-09-29"
NN_pixels_TPA$Pot <- str_remove(NN_pixels_TPA$Filename, pattern = ("Mask 2020-09-29 "))
NN_pixels_TPA$Pot <- str_remove(NN_pixels_TPA$Pot, pattern = (".png"))
NN_pixels_TPA$Source <- "Lemnatech"

NN_pixels_TPA$Pot[NN_pixels_TPA$Pot == "Gen 6"] <- "712 A"
NN_pixels_TPA$Pot[NN_pixels_TPA$Pot == "How 8"] <- "732 A"
NN_pixels_TPA$Pot[NN_pixels_TPA$Pot == "How 6"] <- "716 A"
NN_pixels_TPA$Pot[NN_pixels_TPA$Pot == "Gen 4"] <- "720 A"
NN_pixels_TPA$Pot[NN_pixels_TPA$Pot == "How 3"] <- "724 A"
NN_pixels_TPA$Pot[NN_pixels_TPA$Pot == "Gen 7"] <- "728 A"

# Calculate FGCC for TPA
pot_size_tpa = pi * (406/2)^2
NN_pixels_TPA$FGCC <- NN_pixels_TPA$n_mask/pot_size_tpa


# Exploration until scoring -----------------------------------------------


# Combine Nursery and TPA 
NN_pixels_combined <- rbind(NN_pixels_TPA, NN_pixels)

# Combine with sowing plan
sowing_plans <- read_csv("R out/2020-10-27 Sowing plan clean.csv")

FGCC <- left_join(sowing_plans, NN_pixels_combined) %>% rename(Type = type)
FGCC$Treatment <- str_c(FGCC$Type, FGCC$Isolate, sep = " - " )

# removing secondary inoculation from dates before inoculation
FGCC_before_inoc <- FGCC %>% filter(Date %in% c("2020-07-27", "2020-08-03"), Isolate != "Curyo secondary infection")
FGCC_after_inoc <- FGCC %>% filter(!Date %in% c("2020-07-27", "2020-08-03"))
FGCC <- rbind(FGCC_before_inoc, FGCC_after_inoc)

write_csv(FGCC, "R out/FGCC/FGCC results.csv")


# Export FGCC results for publication -------------------------------------

FGCC_for_publication <- FGCC %>% 
  select(-ENTRY, - NAME, -AccessionName, -n_mask, - Filename) %>% 
  janitor::clean_names() %>% 
  select(-rep, -type, -id, -id_with_controls, -isolate, -treatment)
write_csv(FGCC_for_publication, "../../predict_DI/Data/FGCC.csv")


FGCC$Date <- as.Date(FGCC$Date)

# Plot FGCC over time
p_FGCC_over_time <- ggplot(FGCC %>% filter(Source == "Nursery"), aes(x = Date, y = FGCC, group = Pot)) + 
  geom_vline(aes(xintercept = Date), color = "blue") +
  geom_line(alpha = 0.2) + 
  facet_wrap(~Treatment, nrow = 2) +
  geom_line(data = FGCC %>% filter(ID_with_controls == "WLD085", Source == "Nursery"), aes(x = Date, y = FGCC), color = "red", alpha = 1) + # highlight edge case Kayat_071 
  geom_line(data = FGCC %>% filter(ID_with_controls == "WLD076",Source == "Nursery"), aes(x = Date, y = FGCC), color = "#FDE725FF", alpha = 1) +
  labs(title = "FGCC per pot over time") 
p_FGCC_over_time

ggsave(ggsave(p_FGCC_over_time, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
                                            " FGCC over time per genotype group.jpg"),
              device = "jpg", limitsize = F, width = 20, height = 12, unit = "cm",
              scale = 1.2))

# Plot FGCC over time without secondary infection and mutation 
p_FGCC_over_time_without_secAndMutation <- FGCC %>% 
  filter(Source == "Nursery", Treatment %nin% c("Cultivar - Curyo secondary infection",
                                           "Mutation - Curyo")) %>% 
  ggplot(aes(x = Date, y = FGCC, group = Pot)) + 
  geom_vline(aes(xintercept = Date), color = "blue") +
  geom_line(alpha = 0.2) + 
  facet_wrap(~Type, nrow = 2) +
  geom_line(data = FGCC %>% filter(ID_with_controls == "WLD085", Source == "Nursery"), aes(x = Date, y = FGCC), color = "red", alpha = 1) + # highlight edge case Kayat_071 
  geom_line(data = FGCC %>% filter(ID_with_controls == "WLD076",Source == "Nursery"), aes(x = Date, y = FGCC), color = "#FDE725FF", alpha = 1) +
  annotate("text", x= as.Date("2020-08-12"), y = 0.95, label = "Inoc") +
  annotate("segment", x = as.Date("2020-08-03"), xend = as.Date("2020-08-06"), y = 0.95, yend = 0.95) +
  annotate("text", x= as.Date("2020-09-17"), y = 0.95, label = "Score") +
  annotate("segment", x = as.Date("2020-09-24"), xend = as.Date("2020-09-27"), y = 0.95, yend = 0.95) 
p_FGCC_over_time_without_secAndMutation

ggsave(p_FGCC_over_time_without_secAndMutation, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC over time without secondary infection and mutation.png",
              device = "png", limitsize = F, width = 14, height = 14, unit = "cm",
              scale = 1.2)
ggsave(p_FGCC_over_time_without_secAndMutation, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC over time without secondary infection and mutation.pdf",
       device = "pdf", limitsize = F, width = 14, height = 14, unit = "cm",
       scale = 1.2)

p_FGCC_illustration <- FGCC %>% 
  filter(Source == "Nursery", Treatment == "FLIP - Curyo") %>% 
  ggplot(aes(x = Date, y = FGCC, group = Pot)) + 
  geom_vline(aes(xintercept = Date), color = "blue") +
  geom_line(alpha = 0.2) + 
  # facet_wrap(~Type, nrow = 2) +
  # geom_line(data = FGCC %>% filter(ID_with_controls == "WLD085", Source == "Nursery"), aes(x = Date, y = FGCC), color = "red", alpha = 1) + # highlight edge case Kayat_071 
  # geom_line(data = FGCC %>% filter(ID_with_controls == "WLD076",Source == "Nursery"), aes(x = Date, y = FGCC), color = "#FDE725FF", alpha = 1) +
  annotate("text", x= as.Date("2020-08-12"), y = 0.95, label = "Inoc") +
  annotate("segment", x = as.Date("2020-08-03"), xend = as.Date("2020-08-06"), y = 0.95, yend = 0.95) +
  annotate("text", x= as.Date("2020-09-17"), y = 0.95, label = "Score") +
  annotate("segment", x = as.Date("2020-09-24"), xend = as.Date("2020-09-27"), y = 0.95, yend = 0.95) 

p_FGCC_illustration

p_FGCC_illustration_transparent <- FGCC %>% 
  filter(Source == "Nursery", Treatment == "Mutation - Curyo") %>% 
  ggplot(aes(x = Date, y = FGCC, group = Pot)) + 
  geom_vline(aes(xintercept = Date), color = "blue", linetype = 2) +
  geom_line(alpha = 0.5) + 
  annotate("text", x= as.Date("2020-07-30"), y = 0.95, label = "Inoc") +
  annotate("segment", x = as.Date("2020-08-03"), xend = as.Date("2020-08-02"), y = 0.95, yend = 0.95) +
  annotate("text", x= as.Date("2020-09-20"), y = 0.95, label = "Score") +
  annotate("segment", x = as.Date("2020-09-25"), xend = as.Date("2020-09-27"), y = 0.95, yend = 0.95)  +
  theme(panel.background = element_rect(fill = "transparent"), # bg of the panel
        plot.background = element_rect(fill = "transparent", color = NA), # bg of the plot
        legend.background = element_rect(fill = "transparent"), # get rid of legend bg
        legend.box.background = element_rect(fill = "transparent"),# get rid of legend panel bg))
        axis.title.x = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank()) 
  

p_FGCC_illustration_transparent

ggsave(p_FGCC_illustration_transparent, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC illustration transparent.png",
       device = "png", limitsize = F, width = 14, height = 10, unit = "cm", bg = "transparent", dpi = 600, 
       scale = 1)

ggsave(p_FGCC_illustration, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC illustration.png",
              device = "png", limitsize = F, width = 14, height = 10, unit = "cm",
              scale = 1)
ggsave(p_FGCC_illustration, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC illustration.pdf",
       device = "pdf", limitsize = F, width = 14, height = 10, unit = "cm",
       scale = 1)


FGCC %>% filter(ID_with_controls == "WLD076")

FGCC %>% filter(ID_with_controls == "WLD085") 


p_FGCC_WLD_over_time <- ggplot(FGCC %>% filter(Source == "Nursery", Type == "Wild cicer"), aes(x = Date, y = FGCC, group = Pot)) + 
  geom_vline(aes(xintercept = Date), color = "blue") +
  geom_line(alpha = 0.2) + 
  geom_line(data = FGCC %>% filter(ID_with_controls == "WLD085", Source == "Nursery"), aes(x = Date, y = FGCC), color = "red", alpha = 1) + # highlight edge case Kayat_071 
  geom_line(data = FGCC %>% filter(ID_with_controls == "WLD076", Source == "Nursery"), aes(x = Date, y = FGCC), color = "#FDE725FF", alpha = 1) +
  labs(title = "Wild cicer FGCC per pot over time")


p_FGCC_WLD_over_time

ggsave(ggsave(p_FGCC_WLD_over_time, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
                                                 " FGCC Wild cicer over time per genotype group.jpg"),
              device = "jpg", limitsize = F, width = 14, height = 12, unit = "cm",
              scale = 1))


FGCC_per_genotype <- FGCC %>% 
  group_by(AccessionName, Date, ID, ID_with_controls, Type, Treatment, Source) %>% 
  summarise(reps = n(), meanFGCC = mean(FGCC), sdFGCC = sd(FGCC)) %>%
  mutate(CEmax = meanFGCC + 1.96 * sdFGCC/sqrt(reps),
         CEmin = meanFGCC - 1.96 * sdFGCC/sqrt(reps))

# Plotting FGCC with 95% confidence intervals
p_FGCC_per_genotype <- ggplot(FGCC_per_genotype %>% filter(Source == "Nursery"), aes(x = Date, y = meanFGCC, group = ID)) + 
  geom_vline(aes(xintercept = Date), color = "blue") +
  geom_ribbon(aes(ymin = CEmin, ymax = CEmax), alpha = 0.2, fill = "pink") + 
  geom_line(alpha = 0.3) + 
  facet_wrap(~Treatment, nrow = 2) +
  geom_line(data = FGCC_per_genotype %>% filter(ID_with_controls == "WLD085"), aes(x = Date, y = meanFGCC), color = "red", alpha = 1) + # highlight edge case Kayat_071 
  geom_line(data = FGCC_per_genotype %>% filter(ID_with_controls == "WLD076"), aes(x = Date, y = meanFGCC), color = "#FDE725FF", alpha = 1) +
  labs(title = "FGCC per pot over time")
p_FGCC_per_genotype
 
# ggplotly(p_FGCC_per_genotype)


# Comparing FGCC Nursery and FGCC TPA
pots_imaged_at_TPA <- FGCC %>% filter(Source == "Lemnatech") %>% select(Pot) 
pots_imaged_at_TPA <- unique(pots_imaged_at_TPA$Pot)

boxplot_FGCC_over_time_to_TPA <- ggplot(FGCC %>% filter(Pot %in% c(pots_imaged_at_TPA)), aes(as.factor(Date), FGCC, color = Source)) + 
  geom_boxplot() +
  labs(title = "FGCC of pots measured at TPA", x = "Date", y = "FGCC") +
  theme(legend.position = "bottom") + 
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# ggsave(ggsave(boxplot_FGCC_over_time_to_TPA, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
#                                                  " FGCC of pots measured at TPA over time.jpg"),
#               device = "jpg", limitsize = F, width = 12, height = 12, unit = "cm",
#               scale = 1))

Nursery_V_TPA <- FGCC %>% 
  pivot_wider(id_cols = c(-Filename, -n_mask), names_from = c(Source, Date), values_from = FGCC) %>% 
  filter(!is.na(`Nursery_2020-07-27`)) %>% 
  filter(!is.na(`Nursery_2020-08-03`)) %>% 
  filter(!is.na(`Nursery_2020-08-24`)) %>% 
  filter(!is.na(`Nursery_2020-09-07`)) %>% 
  filter(!is.na(`Nursery_2020-09-27`)) %>% 
  filter(!is.na(`Lemnatech_2020-09-29`))

dot_plot_FGCCnursery_V_TPA <- function(dat = Nursery_V_TPA, 
                                       xaxis = dat$`Nursery_2020-09-27`, 
                                       xlab = "FGCC Nursery 2020-09-27",
                                       date = "2020-09-27"){
  mod <- lm(`Lemnatech_2020-09-29`~ xaxis, data = dat)
  slope_mod <- tidy(mod)$estimate[2]
  intercept_mod <- tidy(mod)$estimate[1]
  adjrsq <- summary(mod)$adj.r.squared
  adjrsq_rounded <- round(adjrsq, 3)
  p <- ggplot(dat, aes(y = `Lemnatech_2020-09-29`, x = xaxis)) +
    geom_abline(slope =1, intercept = 0, linetype = 2) +
    geom_abline(slope = slope_mod, intercept = intercept_mod, color = "red") +
    geom_point(shape =1) +
    scale_x_continuous(limits = c(0,1)) +
    scale_y_continuous(limits = c(0,1)) +
    geom_text(aes(x = 0.15, y = 0.9, 
                  label  = paste0("Adj. R-squared = ", adjrsq_rounded)), size = 3) +
    geom_rug(alpha = 0.5) +
    labs(title = "FGCC from Lemnatech vs FGCC from Nursery", x = xlab, y = "FGCC Lemnatech 2020-09-29")
  ggsave(ggsave(p, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
                                                              " FGCC from Lemnatech (09-29) vs FGCC from Nursery ", date,".jpg"),
                device = "jpg", limitsize = F, width = 14, height = 14, unit = "cm",
                scale = 1))
  ggsave(ggsave(p, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
                                     " FGCC from Lemnatech (09-29) vs FGCC from Nursery ", date,".pdf"),
                device = "pdf", limitsize = F, width = 14, height = 14, unit = "cm",
                scale = 1))
  
}


dot_plot_FGCCnursery_V_TPA(dat = Nursery_V_TPA,
                           xaxis = Nursery_V_TPA$`Nursery_2020-07-27`,
                           xlab = "FGCC Nursery 2020-07-27",
                           date = "2020-07-27")

dot_plot_FGCCnursery_V_TPA(dat = Nursery_V_TPA,
                           xaxis = Nursery_V_TPA$`Nursery_2020-08-03`,
                           xlab = "FGCC Nursery 2020-08-03",
                           date = "2020-08-03")

dot_plot_FGCCnursery_V_TPA(dat = Nursery_V_TPA,
                           xaxis = Nursery_V_TPA$`Nursery_2020-08-07`,
                           xlab = "FGCC Nursery 2020-08-07",
                           date = "2020-08-07")

dot_plot_FGCCnursery_V_TPA(dat = Nursery_V_TPA,
                           xaxis = Nursery_V_TPA$`Nursery_2020-08-17`,
                           xlab = "FGCC Nursery 2020-08-17",
                           date = "2020-08-17")

dot_plot_FGCCnursery_V_TPA(dat = Nursery_V_TPA,
                           xaxis = Nursery_V_TPA$`Nursery_2020-08-24`,
                           xlab = "FGCC Nursery 2020-08-24",
                           date = "2020-08-24")

dot_plot_FGCCnursery_V_TPA(dat = Nursery_V_TPA,
                           xaxis = Nursery_V_TPA$`Nursery_2020-08-31`,
                           xlab = "FGCC Nursery 2020-08-31",
                           date = "2020-08-31")

dot_plot_FGCCnursery_V_TPA(dat = Nursery_V_TPA,
                           xaxis = Nursery_V_TPA$`Nursery_2020-09-07`,
                           xlab = "FGCC Nursery 2020-09-07",
                           date = "2020-09-07")

dot_plot_FGCCnursery_V_TPA(dat = Nursery_V_TPA,
                           xaxis = Nursery_V_TPA$`Nursery_2020-09-14`,
                           xlab = "FGCC Nursery 2020-09-14",
                           date = "2020-09-14")

dot_plot_FGCCnursery_V_TPA(dat = Nursery_V_TPA,
                           xaxis = Nursery_V_TPA$`Nursery_2020-09-27`,
                           xlab = "FGCC Nursery 2020-09-27",
                           date = "2020-09-27")


# FGCC validation plot for thesis -----------------------------------------

mod <- lm(`Lemnatech_2020-09-29`~ `Nursery_2020-09-27`, data = Nursery_V_TPA)
slope_mod <- tidy(mod)$estimate[2]
intercept_mod <- tidy(mod)$estimate[1]
p <- ggplot(Nursery_V_TPA, aes(y = `Lemnatech_2020-09-29`, x = `Nursery_2020-09-27`)) +
  geom_abline(slope =1, intercept = 0, linetype = 2) +
  # geom_abline(slope = slope_mod, intercept = intercept_mod, color = "red") +
  geom_point(shape =1) +
  scale_x_continuous(limits = c(0,1)) +
  scale_y_continuous(limits = c(0,1)) +
  geom_rug(alpha = 0.5) +
  labs(x = "FGCC from Nursery", y = "FGCC from Lemnatech")
p
# ggsave(p, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC from Lemnatech vs FGCC from Nursery (09-27).png",
#               device = "png", limitsize = F, width = 12, height = 12, units = "cm",
#               scale = 1)
# ggsave(p, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC from Lemnatech vs FGCC from Nursery (09-27).pdf",
#        device = "pdf", limitsize = F, width = 12, height = 12, units = "cm",
#        scale = 1)

cor(Nursery_V_TPA$`Lemnatech_2020-09-29`, Nursery_V_TPA$`Nursery_2020-09-27`, method = "pearson")

# Exploration of survival after scoring -----------------------------------

# Data prep

NN_pixels_after_scoring_dilated <- NN_pixels_after_scoring %>% select(-n_mask, -n_eroded) %>% rename(n_mask = n_dilated)
NN_pixels_after_scoring_dilated$FGCC <- NN_pixels_after_scoring_dilated$n_mask/Pot_size_nursery

NN_pixels_after_scoring_dilated$Pot[NN_pixels_after_scoring_dilated$Pot == "Genesis6"] <- "712A"
NN_pixels_after_scoring_dilated$Pot[NN_pixels_after_scoring_dilated$Pot == "Howzat8"] <- "732A"
NN_pixels_after_scoring_dilated$Pot[NN_pixels_after_scoring_dilated$Pot == "Howzat6"] <- "716A"
NN_pixels_after_scoring_dilated$Pot[NN_pixels_after_scoring_dilated$Pot == "Genesis4"] <- "720A"
NN_pixels_after_scoring_dilated$Pot[NN_pixels_after_scoring_dilated$Pot == "Howzat3"] <- "724A"
NN_pixels_after_scoring_dilated$Pot[NN_pixels_after_scoring_dilated$Pot == "Genesis7"] <- "728A"

pots_after_scoring <- unique(NN_pixels_after_scoring_dilated$Pot)
pots_after_scoring

survival <- NN_pixels %>% 
  mutate(Pot = str_remove(Pot, " ")) %>% 
  filter(Source == "Nursery", Pot %in% c(pots_after_scoring)) %>% 
  bind_rows(NN_pixels_after_scoring_dilated) %>% 
  left_join(sowing_plans %>% mutate(Pot = str_remove(Pot, " "))) %>% 
  rename(Type = type) %>% 
  filter(!str_detect(Pot, "Sand"))

# removing secondary inoculation from dates before inoculation
survival_before_inoc <- survival %>% filter(Date %in% c("2020-07-27", "2020-08-03"), Isolate != "Curyo secondary infection")
survival_after_inoc <- survival %>% filter(!Date %in% c("2020-07-27", "2020-08-03"))
survival <- rbind(survival_before_inoc, survival_after_inoc)


survival$Treatment <- str_c(survival$Type, survival$Isolate, sep = " - " )
unique(survival$Treatment)
survival$Date <- as.Date(survival$Date)
  
p_survival_over_time <- 
  survival %>% 
    filter(Source == "Nursery") %>% 
  ggplot(aes(x = Date, y = FGCC, group = Pot)) + 
  geom_vline(aes(xintercept = Date), color = "blue") +
  geom_line(alpha = 0.3) + 
  facet_wrap(~Treatment, nrow = 2) +
  geom_line(data = survival %>% filter(ID_with_controls == "WLD085", Source == "Nursery"), aes(x = Date, y = FGCC), color = "red", alpha = 1) + # highlight edge case Kayat_071 
  annotate("text", x= as.Date("2020-08-12"), y = 0.95, label = "Inoc") +
  annotate("segment", x = as.Date("2020-08-03"), xend = as.Date("2020-08-06"), y = 0.95, yend = 0.95) +
  annotate("text", x= as.Date("2020-09-17"), y = 0.95, label = "Score") +
  annotate("segment", x = as.Date("2020-09-24"), xend = as.Date("2020-09-27"), y = 0.95, yend = 0.95) 
p_survival_over_time


# ggsave(p_survival_over_time, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC after scoring.png",
#        device = "png", limitsize = F, width = 24, height = 14, unit = "cm", scale = 1.2)
# ggsave(p_survival_over_time, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/FGCC after scoring.pdf",
#        device = "pdf", limitsize = F, width = 24, height = 14, unit = "cm",  scale = 1.2)

# Comments ----------------------------------------------------------------

# Where is the third Kayat 071 pot?
# 235 A is missing from the Excel file too ("New plan after scoring")

NN_pixels %>% 
  left_join(sowing_plans) %>%
  filter(ID_with_controls == "WLD085")

NN_pixels %>% 
  mutate(Pot = str_remove(Pot, " ")) %>% 
  filter(Source == "Nursery", Pot %in% c(pots_after_scoring)) %>% 
  # bind_rows(NN_pixels_after_scoring_dilated) %>% 
  left_join(sowing_plans %>% mutate(Pot = str_remove(Pot, " "))) %>% 
  rename(Type = type) %>% 
  filter(!str_detect(Pot, "Sand")) %>% 
  filter(ID_with_controls == "WLD085")

sum(pots_after_scoring == "235A") # 235A is not in pots after scoring! Sure? 

NN_pixels_after_scoring_dilated %>% 
  filter(Pot == "235 A" )

# FGCC should not drop as much from scoring to the next date - this is an issue with the segmentation

# Difference between scores, distribution ---------------------------------


# Nursery_V_TPA$diff_FGCC <- Nursery_V_TPA$`Nursery_2020-09-27` - Nursery_V_TPA$`Lemnatech_2020-09-29`
# mean_diff <- mean(Nursery_V_TPA$diff_FGCC, na.rm = T)
# sd_diff <- sd(Nursery_V_TPA$diff_FGCC, na.rm = T)
# n_diff <- length(Nursery_V_TPA$diff_FGCC)
# error_diff <- qnorm(0.975)*sd_diff/sqrt(n_diff)
# 
#   
# dist_FGCC_diff <- ggplot(Nursery_V_TPA, aes(diff_FGCC)) +
#   geom_vline(xintercept = 0, linetype = 2) +
#   geom_vline(xintercept = mean_diff, linetype = 2, color= "red") +
#   geom_density(fill = "grey", alpha =0.2) +
#   scale_x_continuous(limits = c(-0.3, 0.7)) +
#   labs(title = "Distribution of difference between FGCC", subtitle = "Nursery - Lemnatech")


# ggsave(ggsave(dist_FGCC_diff, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
#                                                                " Distribution of difference between FGCC Nursery - Lemnatech.jpg"),
#               device = "jpg", limitsize = F, width = 12, height = 12, unit = "cm",
#               scale = 1))
# 






