#!/usr/bin/env python
# coding: utf-8

import cv2
import os
import numpy as np
import re
import pandas as pd
import time

base_dir = os.path.join("E:/Florian/study_03/TPA imaging/RGB marked/Renamed pngs")
mask_dir = os.path.join("E:/Florian/study_03/TPA imaging/RGB marked/Masks")
out_dir = os.path.join("E:/Florian/study_03/TPA imaging/RGB marked/Segmented pots")

scale_factor = 5

pictures = sorted(os.listdir(base_dir))
ink_masks = sorted(os.listdir(mask_dir))

print(pictures)
print(ink_masks)

def detect_circles(input_img):
    # Threshold for red
    hsv = cv2.cvtColor(input_img, cv2.COLOR_BGR2HSV)
    lower_red = np.array([0, 255, 255])
    upper_red = np.array([0, 255, 255])
    red = cv2.inRange(hsv, lower_red, upper_red)
    # Detect manual circles
    gaussian = cv2.GaussianBlur(red, ksize=(15,15), sigmaX=cv2.BORDER_DEFAULT)
    circles = cv2.HoughCircles(gaussian, cv2.HOUGH_GRADIENT, 2, minDist=300, minRadius=203, maxRadius=203)
    circles_rounded = np.uint16(np.around(circles))
    print(circles_rounded.shape[1], "Circles found")
    return(circles_rounded)

def crop_circular(detected_circles, input_img):
    cropped_pots = []
    for i in detected_circles[0, :]:
        width = i[0]
        height = i[1]
        radius = 203
        crop = input_img[height-radius:height+radius, width-radius:width+radius] # find dimensions for square crop around pot
        mask = np.zeros(crop.shape, dtype=np.uint8) # create empty mask
        middle = round(mask.shape[0]/2)
        cv2.circle(mask, (middle,middle), radius = radius, color = (255,255,255), thickness = -1) # put white circle on mask
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY) # convert to binary
        ROI = cv2.bitwise_and(crop,crop, mask =mask) # Apply mask to crop
        storage = dict(Width = width, Height = height, Pot = ROI) # use dictionary as storage
        cropped_pots.append(storage) # list of dictionaries
    return(cropped_pots)

for pic, mk in zip(pictures, ink_masks):
    # Load image
    path_img = os.path.join(base_dir, pic)
    path_mask = os.path.join(mask_dir, mk)
    print("Image",path_img)
    print("Mask",path_mask)
    img = cv2.imread(path_img)
    ink_mask = cv2.imread(path_mask)
    print("Mask shape:",ink_mask.shape)
    print("Image shape:", img.shape)
    img_orig = img.copy()
    img_scale = cv2.resize(img, (int(img.shape[1] / scale_factor), int(img.shape[0] / scale_factor)))
    cv2.imshow("Input image", img_scale)
    cv2.waitKey(500)
    circles_rounded = detect_circles(ink_mask)
    # print(circles_rounded)
    cropped_circle = crop_circular(circles_rounded, img_orig)
    print(type(cropped_circle))
    for i in cropped_circle:
        print(type(i))
        cv2.imwrite(filename=os.path.join(out_dir,pic), img=i['Pot'])
    
