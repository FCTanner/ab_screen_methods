#!/usr/bin/env python
# coding: utf-8
# Pixel counting

import os
import numpy as np
import pandas as pd
import cv2

date = "2020-09-07"
method = "NN no neighbors"
mask_dir = "E:/Florian/study_03/TPA imaging/RGB marked/Predicted masks/NN no neighbors".format(method)
out_dir = "Pixel count results/{}".format(method)

def count_pixels(mask_in):
    mask_1d = np.reshape(mask_in, (mask_in.shape[0] * mask_in.shape[1]))
    n_pixels = len(mask_1d[mask_1d>0])
    return(n_pixels)

def main():
    masks = os.listdir(mask_dir)
    binary_masks = [i for i in masks if i.startswith('Mask')]
    out_list = []

    for i in binary_masks:
        path = os.path.join(mask_dir, i)
        mask_in = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        out = {}
        out['Filename'] = i
        out['n_mask'] = count_pixels(mask_in)
        out_list.append(out)

    out_df = pd.DataFrame(out_list)
    print(out_df)
    out_df.to_csv(path_or_buf="{}/Pixel counts  {}.csv".format(out_dir, method),
                  index=False)

main()