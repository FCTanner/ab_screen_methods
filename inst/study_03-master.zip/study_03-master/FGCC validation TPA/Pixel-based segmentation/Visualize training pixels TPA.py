#!/usr/bin/env python
# coding: utf-8
# Visualize training pixels, this is only for fun / aesthetics

# 1. Load all training pixels (foreground and background)
# 2. Somehow sort by color/intensity
# 3. Visualize on a gradient

import numpy as np
import pandas as pd
import cv2
from stackImages import stackImages


background = pd.read_csv("Training data/Extracted pixels/2020-11-20 TPA background pixels.csv")
foreground = pd.read_csv("Training data/Extracted pixels/2020-11-20 TPA foreground pixels.csv")

background['Total'] = background['PB'] + background['PG'] + background['PR']
background = background[['PB', 'PG','PR', 'Total']]
background = background.sort_values(['Total'], ascending= [1])

foreground['Total'] = foreground['PB'] + foreground['PG'] + foreground['PR']
foreground = foreground[['PB', 'PG','PR', 'Total']]
foreground = foreground.sample(n = 16000, random_state=33)
foreground = foreground.sort_values(['Total'], ascending= [1])

print(background.head)
print(foreground.head)

background_array = background[["PB", "PG", "PR"]].to_numpy(dtype=np.uint8)
background_3d_array = np.reshape(background_array, (250,100,3))


foreground_array = foreground[["PB", "PG", "PR"]].to_numpy(dtype=np.uint8)
foreground_3d_array = np.reshape(foreground_array, (160,100,3))

cv2.imwrite(filename = "Training data/Extracted pixels/2020-11-21 background.jpg",
            img = background_3d_array)
cv2.imwrite(filename = "Training data/Extracted pixels/2020-11-21 foreground.jpg",
            img = foreground_3d_array)


stack = stackImages(1, ([background_3d_array, foreground_3d_array]))
cv2.imshow("Background, foreground", stack)
cv2.waitKey(0)