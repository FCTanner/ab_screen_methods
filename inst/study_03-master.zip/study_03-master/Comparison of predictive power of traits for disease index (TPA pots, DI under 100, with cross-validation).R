## study_03 Comparison of predictive power of traits for disease index (TPA pots, DI under 100, with cross-validation)

.libPaths("C:/R-packages2")
rm(list=ls())

library(tidyverse)
library(ggplot2); theme_set(theme_bw())
library(broom)
library(ggsci)
library(tidymodels)

`%nin%` <- Negate(`%in%`)

# Data prep ---------------------------------------------------------------

FGCC_dat <- read_csv("R out/FGCC/FGCC results.csv")

scores <- read_csv("R out/2020-11-19 Scores.csv")

TPA_results <- readxl::read_xlsx("S:/Science/AgFood&Wine/Plant Accelerator/Accelerator Projects 0501 to 0550/0539_PH_UA_TannerFlorian_hyperspec/rawdata/0539 Chickpea.xlsx")

TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 6"] <- "712 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 8"] <- "732 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 6"] <- "716 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 4"] <- "720 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "How 3"] <- "724 A"
TPA_results$`Snapshot ID Tag`[TPA_results$`Snapshot ID Tag` == "Gen 7"] <- "728 A"


FGCC_full <-  TPA_results %>% rename(Pot = `Snapshot ID Tag`) %>% 
  select(c(Pot, `Projected Shoot Area [pixels]`, `RGB_TV Result area` )) %>% 
  left_join(FGCC_dat) %>% 
  left_join(scores)

FGCC_filter <- FGCC_full %>% 
  filter(DI < 100, !is.na(Rep)) %>% 
  pivot_wider(id_cols = c(Pot, Treatment, DI,
                          Source, Rep,`Projected Shoot Area [pixels]`, `RGB_TV Result area`), 
              names_from = c(Date,Source), 
              values_from = FGCC, 
              names_glue = "{Source}_{Date}_{.value}",
              values_fn = mean) %>% 
  filter(!is.na(`Nursery_2020-09-27_FGCC`), !is.na(`Nursery_2020-07-27_FGCC`))


TPA_results_for_predict_DI <- FGCC_filter[,1:6]
write_csv(TPA_results_for_predict_DI, "C:/Users/a1789609/r-projects/adelaide/predict_DI/Data/lemnatec_traits.csv")

# Modelling ---------------------------------------------------------------

# Cross-validation --------------------------------------------------------
set.seed(123)
FGCC_folds <- vfold_cv(data = FGCC_filter, strata = DI, v = 4)

linreg_spec <- linear_reg() %>%
  set_engine("lm")



# Fit models --------------------------------------------------------------


nursery_DAI55 <- fit_resamples(linreg_spec, DI ~ `Nursery_2020-09-27_FGCC`, resamples = FGCC_folds,
                      control = control_resamples(save_pred = TRUE))

nursery_DAI35 <- fit_resamples(linreg_spec, DI ~ `Nursery_2020-09-07_FGCC`, resamples = FGCC_folds,
                       control = control_resamples(save_pred = TRUE))

nursery_DAI21 <- fit_resamples(linreg_spec, DI ~ `Nursery_2020-08-24_FGCC`, resamples = FGCC_folds,
                       control = control_resamples(save_pred = TRUE))



nursery_ALLDAI <- fit_resamples(linreg_spec, DI ~ `Nursery_2020-07-27_FGCC` * 
                                  `Nursery_2020-08-03_FGCC` * 
                                  `Nursery_2020-08-24_FGCC` * 
                                  `Nursery_2020-09-07_FGCC` * 
                                  `Nursery_2020-09-27_FGCC`,
                        resamples = FGCC_folds,
                        control = control_resamples(save_pred = TRUE))

TPA_FGCC <- fit_resamples(linreg_spec, DI ~ `Lemnatech_2020-09-29_FGCC`, resamples = FGCC_folds,
                          control = control_resamples(save_pred = TRUE))

TPA_PSA <- fit_resamples(linreg_spec, DI ~ `Projected Shoot Area [pixels]`, resamples = FGCC_folds,
                         control = control_resamples(save_pred = TRUE))

TPA_TV <- fit_resamples(linreg_spec, DI ~ `RGB_TV Result area`, resamples = FGCC_folds,
                        control = control_resamples(save_pred = TRUE))
# Evaluate  ---------------------------------------------------------------
CV_metrics <- nursery_DAI55 %>% 
  collect_metrics() %>% 
  mutate(DAI = "55 DAI Nursery FGCC") %>% 
  bind_rows(nursery_DAI35 %>% 
              collect_metrics() %>% 
              mutate(DAI = "35 DAI Nursery FGCC") )%>% 
  bind_rows(nursery_DAI21 %>% 
              collect_metrics() %>% 
              mutate(DAI = "21 DAI Nursery FGCC")) %>% 
  bind_rows(nursery_ALLDAI %>% 
              collect_metrics() %>% 
              mutate(DAI = "5 timepoints FGCC Nursery")) %>% 
  bind_rows(TPA_FGCC %>% 
              collect_metrics() %>% 
              mutate(DAI = "57 DAI TPA FGCC")) %>% 
  bind_rows(TPA_PSA %>% 
              collect_metrics() %>% 
              mutate(DAI = "57 DAI TPA PSA")) %>% 
  bind_rows(TPA_TV %>% 
              collect_metrics() %>% 
              mutate(DAI = "57 DAI TPA TV")) 



CV_metrics

CV_preds <- nursery_DAI55 %>% 
  collect_predictions() %>% 
  mutate(DAI = "55 DAI Nursery FGCC") %>% 
  bind_rows(nursery_DAI35 %>% collect_predictions() %>% 
              mutate(DAI = "35 DAI Nursery FGCC")) %>% 
  bind_rows(nursery_DAI21 %>% collect_predictions() %>% 
              mutate(DAI = "21 DAI Nursery FGCC") )%>% 
  bind_rows(nursery_ALLDAI %>% collect_predictions() %>% 
              mutate(DAI = "5 timepoints FGCC Nursery"))%>% 
  bind_rows(TPA_FGCC %>% collect_predictions() %>% 
              mutate(DAI = "57 DAI TPA FGCC"))%>% 
  bind_rows(TPA_PSA %>% collect_predictions() %>% 
              mutate(DAI = "57 DAI TPA PSA"))%>% 
  bind_rows(TPA_TV %>% collect_predictions() %>% 
              mutate(DAI = "57 DAI TPA TV"))







# CV plots ----------------------------------------------------------------


p_predictions <- CV_preds %>% 
  ggplot(aes(x = DI, y = .pred, color = DAI)) +
  geom_point(shape = 1) +
  facet_wrap(~DAI, nrow =3)+
  labs(x = "Ground truth", y = "Predicted Disease Index") +
  scale_y_continuous(limits = c(0, 100)) +
  scale_color_jco() + 
  theme(legend.position = "blank")


p_predictions

# ggsave(p_predictions, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Comparison of all predictors for DI of TPA pots (DI under 100)/Predictions vs ground-truth.png",
#        limitsize =  F, units = "cm", device = "png", width = 14, height = 12)
# ggsave(p_predictions, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Comparison of all predictors for DI of TPA pots (DI under 100)/Predictions vs ground-truth.pdf",
#        limitsize =  F, units = "cm", device = "pdf", width = 14, height = 12)

p_rsq <- CV_metrics %>% 
  filter(.metric== "rsq") %>% 
  ggplot(aes(x = DAI, y = mean, color = DAI, fill = DAI)) +
  geom_col(alpha = 0.6) +
  geom_errorbar(aes(x = DAI, ymin = mean - std_err, ymax = mean + std_err), width = 0.3, color = "black")  +
  labs(x= "Model", y = "Estimated r-squared (4-fold CV)", caption = "Errorbars = standard error") +
  scale_color_jco() +
  scale_fill_jco()+ 
  theme(legend.position = "blank") +
  coord_flip()


p_rsq

# ggsave(p_rsq, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Comparison of all predictors for DI of TPA pots (DI under 100)/Estimated r-squared (4fold CV).png",
#        limitsize =  F, units = "cm", device = "png", width = 12, height = 12)
# ggsave(p_rsq, file = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/Comparison of all predictors for DI of TPA pots (DI under 100)/Estimated r-squared (4fold CV).pdf",
#        limitsize =  F, units = "cm", device = "pdf", width = 12, height = 12)

