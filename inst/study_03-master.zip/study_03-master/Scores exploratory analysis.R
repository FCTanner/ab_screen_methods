### 2020-10-26 Scores explorative analysis 
.libPaths("C:/R-packages")
rm(list=ls())

library(tidyverse)
library(ggplot2); theme_set(theme_bw())


# Data prep ---------------------------------------------------------------


scores <- read_csv("R out/2020-11-19 Scores.csv")

scores$Pot[scores$Pot == "Gen 6"] <- "712 A"
scores$Pot[scores$Pot == "How 8"] <- "732 A"
scores$Pot[scores$Pot == "How 6"] <- "716 A"
scores$Pot[scores$Pot == "Gen 4"] <- "720 A"
scores$Pot[scores$Pot == "How 3"] <- "724 A"
scores$Pot[scores$Pot == "Gen 7"] <- "728 A"

sowing_plan <- read_csv("R out/2020-10-27 Sowing plan clean.csv")



# Scores distribution -----------------------------------------------------


scores_with_type <- left_join(scores, sowing_plan) %>% rename(Type =type)
cols_to_pivot <- c("% main stem broken","% main stem lesions","% side branches diseased", "% LAD", "disease_severity_score", "score_JD", "DI" )
scores_with_type %>% 
  pivot_longer(cols = cols_to_pivot, names_to = "Metric") %>%
  filter(!is.na(Type)) %>%
  ggplot(aes(value, color = Type, fill = Type)) +
  # geom_bar(alpha= 0.2, position = position_dodge2()) +
  geom_density(alpha = 0.2) + 
  facet_wrap(~Metric, scales = "free")

colnames(scores_with_type)

# Calculate and export FT scores per genotype group
scores_per_group <- scores_with_type %>% 
  filter(!is.na(Type)) %>%
  count(Type, disease_severity_score) %>%
  group_by(Type) %>%
  arrange(disease_severity_score) %>%
  pivot_wider(id_cols = Type, names_from = disease_severity_score, values_from= n, values_fill = 0) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(`2`:`9`), na.rm =T), `1` = 0) %>%
  relocate(Type, Total, `1`) %>%
  arrange(Type) 
  
total_scores <- scores_with_type %>% 
  filter(!is.na(Type)) %>%
  count(disease_severity_score) %>%
  pivot_wider(names_from = disease_severity_score, values_from= n, values_fill = 0) %>%
  rowwise() %>%
  mutate(Total = sum(c_across(`2`:`9`), na.rm =T), `1` = 0, Type = "Total") %>%
  relocate(Type, Total, `1`) %>%
  arrange(Type) 

total_scores

scores_per_group <- rbind(scores_per_group, total_scores)
# write_csv(scores_per_group, path = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Scores analysis/",
#                                           format(Sys.Date()), " Count of disease severity scores (FT) per genotype group.csv"))



p1 <- scores_with_type %>% 
  pivot_longer(cols = cols_to_pivot, names_to = "Metric") %>%
  filter(Metric != "disease_severity_score") %>%
  group_by(Type, Metric) %>%
  summarize(Average = mean(value), std_dv = sd(value), std_err = sd(value)/sqrt(length(value))) %>%
  group_by(Type) %>%
  mutate(score_sum = sum(Average)) %>%
  ungroup() %>%
  ggplot(aes(x = reorder(Type, -score_sum), y = Average)) +
  geom_col(aes(fill = Metric),  position = position_dodge2(), alpha = 0.5, width = 0.7) +
  geom_errorbar(aes(ymin= Average -std_err, ymax= Average + std_err), width = 0.3)+
  scale_fill_viridis_d() +
  scale_color_viridis_d() +
  labs(x = "Genotype group", y = "Mean score", title = "Mean disease severity scores per group") +
  facet_wrap(~Metric) +
  theme(legend.position = "none") + 
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

p1
# ggsave(ggsave(p1, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", format(Sys.Date()),
#                                             " Mean disease severity scores per genotype group.jpg"),
#               device = "jpg", limitsize = F, width = 14, height = 12, unit = "cm",
#               scale = 1))


# Calculate number of dead plants per group

sumcolumns = colnames(scores_with_type)[6:9]
overall_count <- scores_with_type %>% 
  group_by(Type) %>% 
  count(name = "Overall")

overall_count
dead_count <- scores_with_type %>% 
  mutate(Overall = rowSums(.[sumcolumns])) %>% 
  group_by(Type) %>% 
  filter(Overall == 400) %>%
  count(name = "Dead")
dead_count

dead_frequency <- left_join(overall_count, dead_count) %>% mutate(dead_freq = round((Dead/Overall)*100, digits = 1))
dead_frequency  
# write_csv(dead_frequency, "R out/2020-10-27 Frequency of dead plants per group.csv")  


# Plots for compound disease severity

p2 <- scores_with_type %>%
  filter(!is.na(Type), Isolate == "Curyo") %>%
  ggplot(aes(x= disease_severity_score)) +
  geom_histogram(stat="count") +
  facet_wrap(~Type, scales = "free_y")+
  scale_x_continuous(limits = c(1,9.5), breaks = seq(1,9))+
  labs(title = "Distribution of disease severity scores", x = "Score", y = "Count")
p2

p3 <- scores_with_type %>%
  filter(!is.na(Type), Isolate == "Curyo") %>%
  ggplot(aes(disease_severity_score), color= Type, group = Type) +
  geom_histogram(aes(y = ..density..)) +
  facet_wrap(~Type) +
  scale_x_continuous(limits = c(1,9), breaks = seq(1,9))
p3

p4 <- scores_with_type %>%
  filter(!is.na(Type), Isolate == "Curyo") %>%
  ggplot(aes(disease_severity_score, color = Type, fill = Type)) +
  geom_histogram(stat ="count") +
  scale_x_continuous(limits = c(1,9.5), breaks = seq(1,9)) +
  scale_fill_brewer(type = "qual") +
  scale_color_brewer(type = "qual") +
  labs(title = "Distribution of disease severity scores", x = "Score", y = "Count")
p4


p5 <- scores_with_type %>%
  filter(!is.na(Type), Isolate == "Curyo") %>%
  ggplot(aes(x= disease_severity_score)) +
  geom_histogram(stat="count") +
  facet_wrap(~Type, scales = "free_y", nrow = 1)+
  scale_x_continuous(limits = c(1,9.5), breaks = seq(1,9))+
  labs(title = "Distribution of disease severity scores", x = "Score", y = "Count")
p5
table(scores_with_type$Type)
table(scores_with_type$disease_severity_score)

# ggsave(p4, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", 
#                              format(Sys.Date()), 
#                              " Distribution of disease severity scores.jpg"),
#        device = "jpg", limitsize = F, units = "cm", width = 14, height= 12)
# 
# ggsave(p2, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/", 
#                              format(Sys.Date()), 
#                              " Distribution of disease severity scores Facetted.jpg"),
#        device = "jpg", limitsize = F, units = "cm", width = 16, height= 12)

# ggsave(p5, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/",
#                              format(Sys.Date()),
#                              " Distribution of disease severity scores 1 row.jpg"),
#        device = "jpg", limitsize = F, units = "cm", width = 26, height= 7)


p6 <- scores_with_type %>% 
  filter(Type == "ABL") %>%
  ggplot(aes(x = score_JD, y = disease_severity_score)) +
  geom_jitter(alpha = 0.5) +
  scale_x_continuous(limits= c(0.8, 9.2), breaks = c(1,2,3,4,5,6,7,8,9)) +
  scale_y_continuous(limits= c(0.8, 9.2), breaks = c(1,2,3,4,5,6,7,8,9)) +
  labs(x = "JD's score", y = "FT's score", title = "Disease severity scores for advanced breeding lines") +
  geom_abline(slope = 1, intercept = 0)
p6  

scores_with_type %>% 
  filter(Type == "ABL") %>%
  summary()


# ggsave(p6, filename = paste0("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/",
#                              format(Sys.Date()),
#                              " JD's scores vs FT's scores (PBA).jpg"),
#        device = "jpg", limitsize = F, units = "cm", width = 14, height= 14)


# Disease index exploratory -----------------------------------------------




