### 2020-10-09 Exploring foreground and background segmentation training pixels
.libPaths("C:/R-packages")
rm(list=ls())

library(tidyverse)
library(broom)
library(viridis)
set.seed(123)

foreground <- read_csv("Pixel-based segmentation/Training data/2020-10-08 Training pixel data/Foreground.csv")
background <- read_csv("Pixel-based segmentation/Training data/2020-10-08 Training pixel data/Background.csv")
foreground <- foreground %>% select(c('PR', 'PG', 'PB', 'Pot', 'Height', 'Width'))
background <- background %>% select(c('PR', 'PG', 'PB', 'Pot', 'Height', 'Width'))

foreground$Ground <- "Foreground"
background$Ground <- "Background"

foreground %>% group_by(Pot) %>% summarize(mean(PR), mean(PG), mean(PB))
background %>% group_by(Pot) %>% summarize(mean(PR), mean(PG), mean(PB))

dat <- rbind(foreground, background)
dat$Ground <- as.factor(dat$Ground)

dat_for_pairs <- dat %>% group_by(Pot) %>% sample_n(200) %>% 
  ungroup() %>% select(-Pot)
# pairs(dat_for_pairs, col = dat_for_pairs$Ground)

dat2 <- dat %>% pivot_longer(cols = c(PR, PB, PG), names_to = "Channel", values_to= "Intensity")

p <- ggplot(dat2, aes(x=Channel, y = Intensity, color = Ground)) +
  geom_boxplot() + 
  facet_wrap(~Pot) + 
  theme_bw() +
  theme(legend.position = "bottom") 

# ggsave(plot = p, filename = "Pixel-based segmentation/Training data/2020-10-09 Visualized training pixels/Boxplots of Foreground - Background intensities per pot.jpg",
#        device = "jpg", width = 14, height = 14, unit = "cm", scale = 1.3, limitsize = F )
