### study_03 Disease index exploratory and visualization
.libPaths("C:/R-packages2")
rm(list=ls())

library(tidyverse)
library(ggplot2); theme_set(theme_bw())


# Data prep ---------------------------------------------------------------


scores <- read_csv("R out/2020-11-19 Scores.csv")

scores$Pot[scores$Pot == "Gen 6"] <- "712 A"
scores$Pot[scores$Pot == "How 8"] <- "732 A"
scores$Pot[scores$Pot == "How 6"] <- "716 A"
scores$Pot[scores$Pot == "Gen 4"] <- "720 A"
scores$Pot[scores$Pot == "How 3"] <- "724 A"
scores$Pot[scores$Pot == "Gen 7"] <- "728 A"

sowing_plan <- read_csv("R out/2020-10-27 Sowing plan clean.csv")


scores_with_type <- left_join(scores, sowing_plan) %>% rename(Type =type)



# Disease index density ---------------------------------------------------

scores_with_type %>% 
  filter(!is.na(Type)) %>% 
  ggplot(aes(DI))+
  geom_histogram() + 
  facet_wrap(~Type, scales = "free_y")

p_all_indices <- scores_with_type %>% 
  filter(!is.na(Type)) %>% 
  mutate(AccessionName = as.factor(AccessionName),
         Type = as.factor(Type),
         AccessionName = tidytext::reorder_within(AccessionName, -DI, Type, .fun = mean)) %>% 
  ggplot(aes(x = DI, y = AccessionName)) + 
  geom_point(shape = 1) +
  stat_summary(geom= "point", fun = "mean", color = "red", shape = 3)  +
  facet_wrap(~Type, scales = "free_y") +
  tidytext::scale_y_reordered() +
  labs(y = "Accession", caption ="Red cross = mean disease index", x = "Disease Index")


p_all_indices

# ggsave(p_all_indices, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/All disease indices per genotype.png",
#        device = "png", limitsize = F, width = 24, height = 14, unit = "cm", scale = 1.2)

# Preparing plot data (summarising dead genotypes) ------------------------

survivors <- scores_with_type %>%
  group_by(AccessionName) %>% 
  mutate(mean_DI = mean(DI),
         all_dead = case_when(mean_DI == 100 ~ T, mean_DI < 100 ~ F)) %>% 
  filter(all_dead == F) %>% 
  ungroup

dead_count <- scores_with_type %>%
  group_by(AccessionName) %>% 
  mutate(mean_DI = mean(DI),
         all_dead = case_when(mean_DI == 100 ~ T, mean_DI < 100 ~ F)) %>% 
  filter(all_dead == T) %>% 
  select(Type, AccessionName, all_dead) %>% # Making sure the number for accessions is correct
  distinct() %>% 
  group_by(Type) %>% 
  count(all_dead)

# Make sure only the appropriate number of genotypes is shown!
dead_accessions_summary <- survivors[1:(3*nrow(dead_count)),] # Simulating three pots
dead_accessions_summary[] <- NA
dead_accessions_summary[,"DI"] <- 100
dead_accessions_summary[,"Type"] <- rep(dead_count$Type, 3)
dead_accessions_summary[,"AccessionName"] <- rep(str_c(dead_count$n, "further dead", sep = " "),3)
dead_accessions_summary[,"ID_with_controls"] <- rep(str_c(dead_count$n, "further dead", sep = " "),3)

NVT_all <- scores_with_type %>% # Using all NVT genotypes as only 3 are dead
  filter(Type == "NVT")

plot_dat <- survivors %>% 
  filter(Type != "NVT") %>% 
  bind_rows(dead_accessions_summary %>% filter(Type != "NVT")) %>% 
  bind_rows(NVT_all)



# Order by mean DI within type facet ----------------------------


p_disease_indices_woABL_wo_dead <- plot_dat %>% 
  filter(!is.na(Type), Type != "ABL") %>% 
  mutate(AccessionName = as.factor(AccessionName),
         Type = as.factor(Type),
         AccessionName = tidytext::reorder_within(AccessionName, -DI, Type, .fun = mean)) %>% 
  ggplot(aes(x = DI, y = AccessionName)) + 
  geom_point(shape = 19, alpha = 0.4) +
  geom_point(shape = 1) +
  stat_summary(geom= "point", fun = "mean", color = "red", shape = 3)  +
  facet_wrap(~Type, scales = "free_y", nrow = 1) +
  tidytext::scale_y_reordered() +
  labs(y = "Accession", caption ="Red cross = mean disease index", x = "Disease Index")


p_disease_indices_woABL_wo_dead

# ggsave(p_disease_indices_woABL_wo_dead, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/All disease indices per genotype without dead without ABL.png",
#        device = "png", limitsize = F, width = 24, height = 14, unit = "cm", scale = 1.2)
# ggsave(p_disease_indices_woABL_wo_dead, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/All disease indices per genotype without dead without ABL.pdf",
#        device = "pdf", limitsize = F, width = 24, height = 14, unit = "cm", scale = 1.2)



# Plot with anonymization -------------------------------------------------

p_disease_indices_woABL_wo_dead_anon <- plot_dat %>% 
  filter(!is.na(Type), Type != "ABL") %>% 
  mutate(ID_with_controls = as.factor(ID_with_controls),
         Type = as.factor(Type),
         ID_with_controls = tidytext::reorder_within(ID_with_controls, -DI, Type, .fun = mean)) %>% 
  ggplot(aes(x = DI, y = ID_with_controls)) + 
  geom_point(shape = 19, alpha = 0.4) +
  geom_point(shape = 1) +
  stat_summary(geom= "point", fun = "mean", color = "red", shape = 3)  +
  facet_wrap(~Type, scales = "free_y", nrow = 1) +
  tidytext::scale_y_reordered() +
  labs(y = "Accession", caption ="Red cross = mean disease index", x = "Disease Index")


p_disease_indices_woABL_wo_dead_anon


# ggsave(p_disease_indices_woABL_wo_dead_anon, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/All disease indices per genotype without dead without ABL anonymized.png",
#        device = "png", limitsize = F, width = 24, height = 14, unit = "cm", scale = 1.2)
# ggsave(p_disease_indices_woABL_wo_dead_anon, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/All disease indices per genotype without dead without ABL anonymized.pdf",
#        device = "pdf", limitsize = F, width = 24, height = 14, unit = "cm", scale = 1.2)


# Anonymization everything named "Cultivar" -------------------------------


p_disease_indices_woABL_wo_dead_anon_cult <- plot_dat %>% 
  filter(!is.na(Type), Type != "ABL") %>% 
  mutate(Type = str_replace(Type, "NVT", "Cultivar"),
         ID_with_controls = str_replace(ID_with_controls, "NVT", "CV"),
         Type = str_replace(Type, "FLIP", "Breeding material"),
         Type = str_replace(Type, "Introgression", "Breeding material"),
         ID_with_controls = str_replace(ID_with_controls, "FLP", "BA"),
         ID_with_controls = str_replace(ID_with_controls, "INT", "BB")) %>% 
  mutate(ID_with_controls = as.factor(ID_with_controls),
         Type = as.factor(Type),
         ID_with_controls = tidytext::reorder_within(ID_with_controls, -DI, Type, .fun = mean)) %>% 
  ggplot(aes(x = DI, y = ID_with_controls)) + 
  geom_point(shape = 19, alpha = 0.4) +
  geom_point(shape = 1) +
  stat_summary(geom= "point", fun = "mean", color = "red", shape = 3)  +
  facet_wrap(~Type, scales = "free_y", nrow = 1) +
  tidytext::scale_y_reordered() +
  labs(y = "Accession", caption ="Red cross = mean disease index", x = "Disease Index")


# ggsave(p_disease_indices_woABL_wo_dead_anon_cult, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/All disease indices per genotype without dead without ABL cultivar anonymized.png",
#        device = "png", limitsize = F, width = 24, height = 14, unit = "cm", scale = 1.2)
# ggsave(p_disease_indices_woABL_wo_dead_anon_cult, filename = "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Results/Graphs/All disease indices per genotype without dead without ABL cultivar anonymized.pdf",
#        device = "pdf", limitsize = F, width = 24, height = 14, unit = "cm", scale = 1.2)

# Genotypic effects -------------------------------------------------------


# Wild genotypes ----------------------------------------------------------

wild_aov <- aov(DI ~ AccessionName, data =  plot_dat %>% 
                  filter(Type == "Wild cicer"))
broom::tidy(wild_aov)

broom::tidy(TukeyHSD(wild_aov)) %>% 
  filter(adj.p.value <0.05) %>% 
  arrange(adj.p.value) %>% 
  print(n= 40) 
broom::tidy(TukeyHSD(wild_aov)) %>% 
  filter(adj.p.value <0.05,
         !str_detect(contrast, "Kayat")) 

# Kayat is sign. different to all others, besides there are no sign. differences


# Cultivars genetic effect ------------------------------------------------


cultivar_aov <- aov(DI ~ AccessionName, data =  plot_dat %>% 
                  filter(Type == "Cultivar"))
broom::tidy(cultivar_aov)

broom::tidy(TukeyHSD(cultivar_aov)) %>% 
  filter(adj.p.value <0.05) %>% 
  arrange(adj.p.value) %>% 
  print(n= 40) 


# FLIP genetic effect -----------------------------------------------------


FLIP_aov <- aov(DI ~ AccessionName, data =  plot_dat %>% 
                      filter(Type == "FLIP"))
broom::tidy(FLIP_aov)

broom::tidy(TukeyHSD(FLIP_aov)) %>% 
  filter(adj.p.value <0.05) %>% 
  arrange(adj.p.value) %>% 
  print(n= 50) 


# Introgression genetic effect --------------------------------------------


Introgression_aov <- aov(DI ~ AccessionName, data =  plot_dat %>% 
                  filter(Type == "Introgression"))
broom::tidy(Introgression_aov)

# No significant differences between Introgression lines 


# NVT genetic effect ------------------------------------------------------


NVT_aov <- aov(DI ~ AccessionName, data =  plot_dat %>% 
                           filter(Type == "NVT"))
broom::tidy(NVT_aov)

broom::tidy(TukeyHSD(NVT_aov)) %>% 
  filter(adj.p.value <0.05) %>% 
  arrange(adj.p.value) %>% 
  print(n= 50) 


# ABL genetic effect ------------------------------------------------------

ABL_aov <- aov(DI ~ AccessionName, data =  plot_dat %>% 
                 filter(Type == "ABL"))
broom::tidy(ABL_aov)

broom::tidy(TukeyHSD(ABL_aov)) %>% 
  filter(adj.p.value <0.05) %>% 
  arrange(adj.p.value) %>% 
  print(n= 50) 




