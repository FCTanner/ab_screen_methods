### 2020-09-29 Which pots are all scored 100% dead, do not image 
.libPaths("C:/R-packages")
rm(list=ls())

library(tidyverse)

scores_NVT <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/2020-09-28 Scoring results/Original/Results Assessment NVT AB Curyo.xlsx")
scores_FLIP <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/2020-09-28 Scoring results/Original/Results Assessment Wild Cicer FLIP Curyo 2020.xlsx")
scores_FLIP <- scores_FLIP %>% rename(Entry = ENTRY, Name = NAME)

scores <- rbind(scores_NVT, scores_FLIP)

summary(scores)

pots_to_image <- read_csv("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/2020-09-24 Pots to image with rows.csv")

simons_pots <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/2020_06_16 Group I chickpea asco terrace labels.xlsx")

sumcolumns <- colnames(scores)[6:9]
pots_to_image_new <- pots_to_image %>% 
  left_join(scores) %>% 
  mutate(Overall = rowSums(.[sumcolumns])) %>% 
  group_by(Name) %>% 
  mutate(all_dead = mean(Overall)) %>%
  filter(all_dead <400)

pots_not_to_image <- pots_to_image %>% 
  left_join(scores) %>% 
  mutate(Overall = rowSums(.[sumcolumns])) %>% 
  group_by(Name) %>% 
  mutate(all_dead = mean(Overall)) %>%
  filter(all_dead >= 400)

pots_to_image %>% group_by(Type) %>% count()
pots_to_image_new %>% group_by(Type) %>% count()

pots_to_image_select_1 <- pots_to_image_new %>% filter(Type %in% c("FLIP", "Introgression", "Wild cicer"))
pots_to_image_select_2 <- pots_to_image %>% filter(Type %in% c("Cultivar", "NVT"))

pots_to_image_select <- rbind(pots_to_image_select_1, pots_to_image_select_2)

write_csv(pots_to_image_select, "U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/2020-09-29 my pots to image.csv")
