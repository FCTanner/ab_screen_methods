### 2020-10-27 Sowing plan data cleaning
.libPaths("C:/R-packages2")
rm(list=ls())

library(tidyverse)
library(broom)

## This script contains three sections:
## 1. Clean spatial design and add row/ columns 
## 2. anomyzation for internal purposes, 
## 3. anonymization for the public repo predict_DI



# Clean spatial design  ---------------------------------------------------

pot_locations <- readxl::read_excel("C:/Users/a1789609/Box/Udrive/Experiments/2020-06-17 study_03 SARDI terraces 2020/Labels/2020-09-24 making labels.xlsx",
                                    sheet = "Experimental design")

pot_colnames <- str_c("col", seq(1,ncol(pot_locations),1))
colnames(pot_locations) <- pot_colnames

match_pot_locations <- pot_locations %>% 
  filter(col1 != "Row") %>% 
  mutate(row = seq(1, 24, 1)) %>% 
  pivot_longer(cols = -row, names_to = "column", values_to = "pot") %>% 
  mutate(column = str_remove(column, "col")) %>% 
  rename(Pot = pot)

# Sowing plan for internal anonymization ----------------------------------


# Load sowing plans
# Judith and Leo
sowing_plan_judith <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/Original/AB phenotyping terrace.xlsx",
                                 skip = 1)

sowing_plan_judith_clean <- sowing_plan_judith %>% select(-`Page 1`) %>% filter(Rep != "Rep")

sowing_plan_judith_clean$type <- "Wild cicer"
sowing_plan_judith_clean$type[grepl("UCD", sowing_plan_judith_clean$AccessionName) == T] <- "Introgression"
sowing_plan_judith_clean$type[grepl("FLIP", sowing_plan_judith_clean$AccessionName) == T] <- "FLIP"
sowing_plan_judith_clean$type[grepl("Howzat", sowing_plan_judith_clean$NAME) == T] <- "Cultivar"
sowing_plan_judith_clean$type[grepl("Genesis090", sowing_plan_judith_clean$NAME) == T] <- "Cultivar"

tail(sowing_plan_judith_clean)

# NVT
sowing_plan_NVT <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/Original/2020 NVT AB Sowing plan.xlsx",
                                     sheet = "Sowing plan Curyo",
                                     skip = 2)[,1:5]

sowing_plan_NVT$type <- "NVT"
sowing_plan_NVT_clean <- sowing_plan_NVT %>% filter(Rep != "Rep")
sowing_plan_NVT_clean$AccessionName <- sowing_plan_NVT_clean$NAME



# Simon
sowing_plan_simon <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/Original/2020_06_16 Group I chickpea asco terrace labels.xlsx")

Simon_pot_translate <- seq(679, 710, 1)
Simon_pot_translate <- str_c(Simon_pot_translate, 
                             " A")


sowing_plan_simon_clean <- sowing_plan_simon %>% rename(type = Name, NAME = Line)
sowing_plan_simon_clean$AccessionName <- sowing_plan_simon_clean$NAME
sowing_plan_simon_clean$Pot <- Simon_pot_translate
sowing_plan_simon_clean$type <- "Mutation"
sowing_plan_simon_clean$Isolate <- "Curyo"

# PBA
sowing_plan_PBA <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/Original/PBA lines sowing plan 2020.xlsx",
                                     skip = 2)


PBA_lines_clean <- sowing_plan_PBA %>% mutate(type = "ABL", AccessionName = NAME)

# Sowing plan for my secondary infection controls (starting one week after inoculation)
sowing_plan_secondary <- readxl::read_xlsx("U:/Experiments/2020-06-17 study_03 SARDI terraces 2020/Experimental design/Original/2020-10-22 Sowing plan secondary infection.xlsx")


# Rbinding 
sowing_plans <- rbind(sowing_plan_judith_clean, sowing_plan_NVT_clean, sowing_plan_simon_clean, PBA_lines_clean, sowing_plan_secondary)

sort(unique(sowing_plans$AccessionName))

for(i in 1:nrow(sowing_plans)){
  if(sowing_plans$AccessionName[i] == 0){
  sowing_plans$AccessionName[i] <- sowing_plans$NAME[i]
  }
}

sowing_plans$AccessionName[sowing_plans$AccessionName == "HOWZAT"] <- "Howzat"
sowing_plans$AccessionName[sowing_plans$AccessionName == "GENESIS090"] <- "Genesis090"
sowing_plans$NAME[sowing_plans$NAME == "HOWZAT"] <- "Howzat"
sowing_plans$NAME[sowing_plans$NAME == "GENESIS090"] <- "Genesis090"

# Anonymize
unique(sowing_plans$type)

pba_gens <- sowing_plans %>% filter(type == "ABL") %>% distinct(AccessionName) %>% arrange(AccessionName)
pba_id_start <- rep("ABL", nrow(pba_gens))
pba_number <- sprintf("%03d",seq(1:nrow(pba_gens)))
pba_conversion <- cbind(pba_gens, ID = str_c(pba_id_start, pba_number), type = "ABL")

wild_gens <- sowing_plans %>% filter(type == "Wild cicer") %>% distinct(AccessionName) %>% arrange(AccessionName)
wild_id_start <- rep("WLD", nrow(wild_gens))
wild_number <- sprintf("%03d",seq(1:nrow(wild_gens)))
wild_conversion <- cbind(wild_gens, ID = str_c(wild_id_start, wild_number), type = "Wild cicer")

int_gens <- sowing_plans %>% filter(type == "Introgression") %>% distinct(AccessionName) %>% arrange(AccessionName)
int_id_start <- rep("INT", nrow(int_gens))
int_number <- sprintf("%03d",seq(1:nrow(int_gens)))
int_conversion <- cbind(int_gens, ID = str_c(int_id_start, int_number), type = "Introgression")

flip_gens <- sowing_plans %>% filter(type == "FLIP") %>% distinct(AccessionName) %>% arrange(AccessionName)
flip_id_start <- rep("FLP", nrow(flip_gens))
flip_number <- sprintf("%03d",seq(1:nrow(flip_gens)))
flip_conversion <- cbind(flip_gens, ID = str_c(flip_id_start, flip_number), type = "FLIP")

cvr_gens <- sowing_plans %>% filter(type == "Cultivar") %>% distinct(AccessionName) %>% arrange(AccessionName)
cvr_id_start <- rep("CVR", nrow(cvr_gens))
cvr_number <- sprintf("%03d",seq(1:nrow(cvr_gens)))
cvr_conversion <- cbind(cvr_gens, ID = str_c(cvr_id_start, cvr_number), type = "Cultivar")

nvt_gens <- sowing_plans %>% filter(type == "NVT") %>% distinct(AccessionName) %>% arrange(AccessionName)
nvt_id_start <- rep("NVT", nrow(nvt_gens))
nvt_number <- sprintf("%03d",seq(1:nrow(nvt_gens)))
nvt_conversion <- cbind(nvt_gens, ID = str_c(nvt_id_start, nvt_number), type = "NVT")

simon_gens <- sowing_plans %>% filter(type == "Mutation") %>% distinct(AccessionName) %>% arrange(AccessionName)
simon_id_start <- rep("MTN", nrow(simon_gens))
simon_number <- sprintf("%03d",seq(1:nrow(simon_gens)))
simon_conversion <- cbind(simon_gens, ID = str_c(simon_id_start, simon_number), type = "Mutation")

conversion <- rbind(pba_conversion, wild_conversion, int_conversion, flip_conversion, cvr_conversion, nvt_conversion, simon_conversion)

length(unique(sowing_plans$AccessionName))
length(unique(sowing_plans$NAME))

conversion[duplicated(conversion$AccessionName),'AccessionName']
conversion %>% filter(AccessionName %in% conversion[duplicated(conversion$AccessionName),'AccessionName'] ) %>% arrange(AccessionName)

sowing_plan_out <- sowing_plans %>% 
  left_join(conversion) %>% 
  left_join(match_pot_locations)

sowing_plan_out$ID_with_controls <- sowing_plan_out$ID

sowing_plan_out$ID_with_controls[sowing_plan_out$AccessionName == "Howzat"] <- "Howzat"
sowing_plan_out$ID_with_controls[sowing_plan_out$AccessionName == "Genesis090"] <- "Genesis090"
unique(sowing_plan_out$ID_with_controls)


write_csv(sowing_plan_out, "R out/sowing_plan.csv")


###############################################

# Sowing plan for anonymization for predict_DI ----------------------------

sowing_plan_predict_DI <- sowing_plans # Create copy of sowing plan

# Anonymize
unique(sowing_plan_predict_DI$type)

sowing_plan_predict_DI$type[sowing_plan_predict_DI$type == "ABL"] <- "Cultivar"
sowing_plan_predict_DI$type[sowing_plan_predict_DI$type == "NVT"] <- "Cultivar"
sowing_plan_predict_DI$type[sowing_plan_predict_DI$type == "Mutation"] <- "Cultivar"

pba_gens_predict_DI <- sowing_plan_predict_DI %>% filter(type == "ABL") %>% distinct(AccessionName) %>% arrange(AccessionName)
pba_id_start_predict_DI <- rep("ABL", nrow(pba_gens_predict_DI))
pba_number_predict_DI <- sprintf("%03d",seq(1:nrow(pba_gens_predict_DI)))
pba_conversion_predict_DI <- cbind(pba_gens_predict_DI, ID = str_c(pba_id_start_predict_DI, pba_number_predict_DI), type = "ABL")

wild_gens_predict_DI <- sowing_plan_predict_DI %>% filter(type == "Wild cicer") %>% distinct(AccessionName) %>% arrange(AccessionName)
wild_id_start_predict_DI <- rep("WLD", nrow(wild_gens_predict_DI))
wild_number_predict_DI <- sprintf("%03d",seq(1:nrow(wild_gens_predict_DI)))
wild_conversion_predict_DI <- cbind(wild_gens_predict_DI, ID = str_c(wild_id_start_predict_DI, wild_number_predict_DI), type = "Wild cicer")

int_gens_predict_DI <- sowing_plan_predict_DI %>% filter(type == "Introgression") %>% distinct(AccessionName) %>% arrange(AccessionName)
int_id_start_predict_DI <- rep("INT", nrow(int_gens_predict_DI))
int_number_predict_DI <- sprintf("%03d",seq(1:nrow(int_gens_predict_DI)))
int_conversion_predict_DI <- cbind(int_gens_predict_DI, ID = str_c(int_id_start_predict_DI, int_number_predict_DI), type = "Introgression")

flip_gens_predict_DI <- sowing_plan_predict_DI %>% filter(type == "FLIP") %>% distinct(AccessionName) %>% arrange(AccessionName)
flip_id_start_predict_DI <- rep("FLP", nrow(flip_gens_predict_DI))
flip_number_predict_DI <- sprintf("%03d",seq(1:nrow(flip_gens_predict_DI)))
flip_conversion_predict_DI <- cbind(flip_gens_predict_DI, ID = str_c(flip_id_start_predict_DI, flip_number_predict_DI), type = "FLIP")

cvr_gens_predict_DI <- sowing_plan_predict_DI %>% filter(type == "Cultivar") %>% distinct(AccessionName) %>% arrange(AccessionName)
cvr_id_start_predict_DI <- rep("CVR", nrow(cvr_gens_predict_DI))
cvr_number_predict_DI <- sprintf("%03d",seq(1:nrow(cvr_gens_predict_DI)))
cvr_conversion_predict_DI <- cbind(cvr_gens_predict_DI, ID = str_c(cvr_id_start_predict_DI, cvr_number_predict_DI), type = "Cultivar")

nvt_gens_predict_DI <- sowing_plan_predict_DI %>% filter(type == "NVT") %>% distinct(AccessionName) %>% arrange(AccessionName)
nvt_id_start_predict_DI <- rep("NVT", nrow(nvt_gens_predict_DI))
nvt_number_predict_DI <- sprintf("%03d",seq(1:nrow(nvt_gens_predict_DI)))
nvt_conversion_predict_DI <- cbind(nvt_gens_predict_DI, ID = str_c(nvt_id_start_predict_DI, nvt_number_predict_DI), type = "NVT")

simon_gens_predict_DI <- sowing_plan_predict_DI %>% filter(type == "Mutation") %>% distinct(AccessionName) %>% arrange(AccessionName)
simon_id_start_predict_DI <- rep("MTN", nrow(simon_gens_predict_DI))
simon_number_predict_DI <- sprintf("%03d",seq(1:nrow(simon_gens_predict_DI)))
simon_conversion_predict_DI <- cbind(simon_gens_predict_DI, ID = str_c(simon_id_start_predict_DI, simon_number_predict_DI), type = "Mutation")

conversion_predict_DI <- rbind(wild_conversion_predict_DI,
                               # pba_conversion_predict_DI, 
                               int_conversion_predict_DI,
                               flip_conversion_predict_DI,
                               # simon_conversion_predict_DI,
                               # nvt_conversion_predict_DI,
                               cvr_conversion_predict_DI)


length(unique(sowing_plan_predict_DI$AccessionName))
length(unique(sowing_plan_predict_DI$NAME))

conversion_predict_DI[duplicated(conversion_predict_DI$AccessionName),'AccessionName']
conversion_predict_DI %>% 
  filter(AccessionName %in% 
           conversion_predict_DI[duplicated(conversion_predict_DI$AccessionName),'AccessionName'] ) %>% 
  arrange(AccessionName)

sowing_plan_conversion_predict_DI <- sowing_plan_predict_DI %>% 
  left_join(conversion_predict_DI) %>% 
  left_join(match_pot_locations)

sowing_plan_conversion_predict_DI$ID_with_controls <- sowing_plan_conversion_predict_DI$ID

sowing_plan_conversion_predict_DI$ID_with_controls[sowing_plan_conversion_predict_DI$AccessionName == "Howzat"] <- "Howzat"
sowing_plan_conversion_predict_DI$ID_with_controls[sowing_plan_conversion_predict_DI$AccessionName == "Genesis090"] <- "Genesis090"
unique(sowing_plan_conversion_predict_DI$ID_with_controls)

sowing_plan_out_predict_DI <- sowing_plan_conversion_predict_DI %>% 
  select(Rep, Pot, Isolate, type, ID_with_controls, row, column) %>% 
  rename(ID = ID_with_controls) %>% 
  janitor::clean_names()

write_csv(sowing_plan_conversion_predict_DI, "R out/sowing_plan_conversion.csv")

write_csv(sowing_plan_out_predict_DI, "../../predict_DI/Data/pot_ids.csv")
