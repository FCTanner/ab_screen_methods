import os
import pandas as pd
import time
import exifread

date_list_main = ['2020-07-27', '2020-08-03', '2020-08-07', '2020-08-17',
                  '2020-08-24', '2020-08-31', '2020-09-07', '2020-09-14',
                  '2020-09-27']
# Timing
left_to_do = len(date_list_main)
done = 0
duration_list = []

renamed_out_list = []
original_out_list = []

for date in date_list_main[6:]:
    start = time.time()
    renamed_dir = "F:/Florian/study_03/Terrace images/{date}/Marked/Renamed jpgs/".format(date = date)
    original_dir = "F:/Florian/study_03/Terrace images/{date}/Original/jpg/".format(date = date)

    renamed_list = os.listdir(renamed_dir)
    original_list = os.listdir(original_dir)

    # Loop

    # Match on exif
    for r in renamed_list:

        renamed_path = os.path.join(renamed_dir, r)
        r_open = open(renamed_path, 'rb')
        try:
            renamed_time = exifread.process_file(r_open)['EXIF DateTimeOriginal']

            for o in original_list:
                original_path = os.path.join(original_dir, o)
                o_open = open(original_path, 'rb')
                original_time = exifread.process_file(o_open)['EXIF DateTimeOriginal']

                if str(renamed_time) == str(original_time):
                    renamed_out_list.append(r)
                    original_out_list.append(o)
                # original_list.remove(o)
                    break

                else:
                    pass
        except:
            pass
        partial_out_original_df = pd.DataFrame(data=original_out_list, columns=["original"])
        partial_out_renamed_df = pd.DataFrame(data=renamed_out_list, columns=["renamed"])

        partial_out_df = pd.concat([partial_out_original_df, partial_out_renamed_df], axis=1, ignore_index=False)
        partial_out_df.to_csv("study_03_name_match_{date}.csv".format(date = date))


    left_to_do = left_to_do - 1
    done += 1
    print("#############################################################################")
    print(done, "dates are done, ", left_to_do, "left to do ")
    stop = time.time()
    duration = stop - start
    duration_list.append(duration)
    print("Matching images took", round(duration), "seconds")
    average_duration = sum(duration_list) / len(duration_list)
    print("Approximate time left =", round((left_to_do * average_duration) / 60), "minutes")

# Timing print statements

out_original_df = pd.DataFrame(data=original_out_list, columns=["original"])
out_renamed_df = pd.DataFrame(data=renamed_out_list, columns=["renamed"])

out_df = pd.concat([out_original_df, out_renamed_df], axis=1, ignore_index=False)
out_df.to_csv("study_03_name_match.csv")
