### study_03 Cleaning average reflectance data, match with experimental design

.libPaths("C:/R-packages2")
rm(list=ls())
library(tidyverse)


# 1. Clean VNIR
# 2. Clean SWIR
# 3. Export outfiles


# 1. VNIR
VNIR_dat <- read_csv("Out/Average reflectance/Average VNIR reflectance.csv")
wiwam_match <- read_csv("C:/Users/a1789609/r-projects/adelaide/TPA/WIWAM_match/0539 Florian Chickpeas_merged.csv")
design <-  read_csv("../R out/2020-10-27 Sowing plan clean.csv")


vnir_wavelength_c <- read_csv("C:/Users/a1789609/r-projects/adelaide/study_01/study_01/python/Out/VNIR wavelengths.csv", 
                              col_types = "c", col_names = F)
names(vnir_wavelength_c) <- "Wavelength"
vnir_wavelength_num <- read_csv("C:/Users/a1789609/r-projects/adelaide/study_01/study_01/python/Out/VNIR wavelengths.csv", 
                                col_types = "n", col_names = F)
names(vnir_wavelength_num)
names(vnir_wavelength_num) <- "Wavelength_num"
vnir_wavelength <- cbind(vnir_wavelength_c, vnir_wavelength_num)
summary(vnir_wavelength)

VNIR_dat$Time <- lubridate::as_datetime(substr(VNIR_dat$Entry, 18, 36))

# Fixing timezone problem
VNIR_dat$OZtime <- VNIR_dat$Time +8.5*60*60
VNIR_dat$Date <- as.Date(VNIR_dat$OZtime)
VNIR_dat$WIWAM <- substr(VNIR_dat$Entry, 6, 16)

wiwam_match_unique <- wiwam_match %>% 
  mutate(WIWAM = substr(wiwam_match$file_name, 6, 16))  %>%
  select(-file_name) %>%
  distinct()


VNIR_dat_match <- left_join(VNIR_dat, wiwam_match_unique)
VNIR_dat_match_columns <- colnames(VNIR_dat_match)
VNIR_dat_match_long <- pivot_longer(VNIR_dat_match, cols = starts_with("X"), names_to = "Wavelength", values_to = "Reflectance")

## Extracting wavelength strings
wavelengths_strings <- unique(VNIR_dat_match_long$Wavelength)
vnir_wavelength$Wavelength <- wavelengths_strings

## Matching up numerical wavelength 
VNIR_dat_match_long_wavelengths <- left_join(VNIR_dat_match_long, vnir_wavelength)


## Matching with design 
###Fix pot labels
  
VNIR_dat_match_long_wavelengths$id_tag[VNIR_dat_match_long_wavelengths$id_tag == "Gen 6"] <- "712 A"
VNIR_dat_match_long_wavelengths$id_tag[VNIR_dat_match_long_wavelengths$id_tag == "How 8"] <- "732 A"
VNIR_dat_match_long_wavelengths$id_tag[VNIR_dat_match_long_wavelengths$id_tag == "How 6"] <- "716 A"
VNIR_dat_match_long_wavelengths$id_tag[VNIR_dat_match_long_wavelengths$id_tag == "Gen 4"] <- "720 A"
VNIR_dat_match_long_wavelengths$id_tag[VNIR_dat_match_long_wavelengths$id_tag == "How 3"] <- "724 A"
VNIR_dat_match_long_wavelengths$id_tag[VNIR_dat_match_long_wavelengths$id_tag == "Gen 7"] <- "728 A"

design_dat <- VNIR_dat_match_long_wavelengths %>% 
  rename(Pot = id_tag) %>% 
  left_join(design) %>% 
  select(-Time, -WIWAM, -n, -measurement_label, -date_pippa)

VNIR_dat1 <- design_dat
names(VNIR_dat1)


# 2. SWIR



SWIR_dat <- read_csv("Out/Average reflectance/Average SWIR reflectance.csv")


swir_wavelength_c <- read_csv("C:/Users/a1789609/r-projects/adelaide/study_01/study_01/python/Out/SWIR wavelengths.csv", 
                              col_types = "c", col_names = F)
names(swir_wavelength_c) <- "Wavelength"
swir_wavelength_num <- read_csv("C:/Users/a1789609/r-projects/adelaide/study_01/study_01/python/Out/SWIR wavelengths.csv", 
                                col_types = "n", col_names = F)
names(swir_wavelength_num)
names(swir_wavelength_num) <- "Wavelength_num"
swir_wavelength <- cbind(swir_wavelength_c, swir_wavelength_num)
summary(swir_wavelength)

SWIR_dat$Time <- lubridate::as_datetime(substr(SWIR_dat$Entry, 18, 36))

# Fixing timezone problem
SWIR_dat$OZtime <- SWIR_dat$Time +8.5*60*60
SWIR_dat$Date <- as.Date(SWIR_dat$OZtime)
SWIR_dat$WIWAM <- substr(SWIR_dat$Entry, 6, 16)

wiwam_match_unique <- wiwam_match %>% 
  mutate(WIWAM = substr(wiwam_match$file_name, 6, 16))  %>%
  select(-file_name) %>%
  distinct()


SWIR_dat_match <- left_join(SWIR_dat, wiwam_match_unique)
SWIR_dat_match_columns <- colnames(SWIR_dat_match)
SWIR_dat_match_long <- pivot_longer(SWIR_dat_match, cols = starts_with("X"), names_to = "Wavelength", values_to = "Reflectance")

## Extracting wavelength strings
wavelengths_strings <- unique(SWIR_dat_match_long$Wavelength)
swir_wavelength$Wavelength <- wavelengths_strings

## Matching up numerical wavelength 
SWIR_dat_match_long_wavelengths <- left_join(SWIR_dat_match_long, swir_wavelength)


## Matching with design 

###Fix pot labels

SWIR_dat_match_long_wavelengths$id_tag[SWIR_dat_match_long_wavelengths$id_tag == "Gen 6"] <- "712 A"
SWIR_dat_match_long_wavelengths$id_tag[SWIR_dat_match_long_wavelengths$id_tag == "How 8"] <- "732 A"
SWIR_dat_match_long_wavelengths$id_tag[SWIR_dat_match_long_wavelengths$id_tag == "How 6"] <- "716 A"
SWIR_dat_match_long_wavelengths$id_tag[SWIR_dat_match_long_wavelengths$id_tag == "Gen 4"] <- "720 A"
SWIR_dat_match_long_wavelengths$id_tag[SWIR_dat_match_long_wavelengths$id_tag == "How 3"] <- "724 A"
SWIR_dat_match_long_wavelengths$id_tag[SWIR_dat_match_long_wavelengths$id_tag == "Gen 7"] <- "728 A"

design_dat <- SWIR_dat_match_long_wavelengths %>% 
  rename(Pot = id_tag) %>% 
  left_join(design) %>% 
  select(-Time, -WIWAM, -n, -measurement_label, -date_pippa)

SWIR_dat1 <- design_dat
names(SWIR_dat1)


# 3. Export outfiles
# write_csv(VNIR_dat1, "Out/Average reflectance/Average VNIR reflectance cleaned.csv")
# write_csv(SWIR_dat1, "Out/Average reflectance/Average SWIR reflectance cleaned.csv")



# Export outfiles for clean repo for publishing ---------------------------
pub_ref_dat <- SWIR_dat1 %>% 
  select(Date, Pot, Reflectance, Rep, ID, ID_with_controls, type, Wavelength_num) %>% 
  rename(Wavelength = Wavelength_num) %>% 
  mutate(Camera = "SWIR") %>% 
  bind_rows(VNIR_dat1 %>% 
              select(Date, Pot, Reflectance, Rep, ID, ID_with_controls, type, Wavelength_num) %>% 
              rename(Wavelength = Wavelength_num)%>% 
              mutate(Camera = "VNIR")) %>% 
  filter(Pot != "CP-0539") %>% 
  select(-Rep, -ID, -ID_with_controls, -type)


# write_csv(pub_ref_dat, "../../../predict_DI/Data/hyperspec.csv")


