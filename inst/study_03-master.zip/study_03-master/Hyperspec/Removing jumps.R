## study_03 Removing jumps

.libPaths("C:/R-packages2")
rm(list=ls())
library(tidyverse)
library(ggplot2); theme_set(theme_bw())

VNIR_smoothed <- read_csv("Out/Smoothed reflectance/VNIR reflectance smoothed (p=3, wl =19) padded with wl=5.csv")
SWIR_smoothed <- read_csv("Out/Smoothed reflectance/SWIR reflectance smoothed (p=3, wl =9) padded with wl=5.csv")

VNIR_smoothed %>% filter(!is.na(Smoothed_reflectance)) %>% summary()
SWIR_smoothed %>% filter(!is.na(Smoothed_reflectance)) %>% summary()

unique(VNIR_smoothed$Pot)

VNIR_cut <- VNIR_smoothed %>% filter(Wavelength_num > 400, Wavelength_num < 1001, Pot != "CP-0539")
SWIR_cut <- SWIR_smoothed %>% filter(Wavelength_num >1000, Wavelength_num < 2500, Pot != "CP-0539")

ref_dat <- rbind(VNIR_cut, SWIR_cut)

wavelengths <- ref_dat %>% filter(Wavelength_num > 990, 
                                  Wavelength_num < 1015) %>% distinct(Wavelength_num)
first_SWIR <- 1002.18

ref_dat_wide <- ref_dat %>% 
  filter(Wavelength_num >994, Wavelength_num < 1001) %>%
  select(Wavelength_num, Pot, Smoothed_reflectance) %>% 
  pivot_wider(names_from = Wavelength_num, values_from = Smoothed_reflectance, values_fn = mean) 


predictions <- data.frame(Pot = as.character(), pred_1002.18 = as.numeric())

for(i in 1:nrow(ref_dat_wide)){
  print(i)
  dat <- pivot_longer(data = ref_dat_wide[i,], cols = c(-Pot), names_to = "Wavelength_num", values_to = "Smoothed_reflectance")
  dat$Wavelength_num <- as.numeric(dat$Wavelength_num)
  mod <- lm(Smoothed_reflectance ~ Wavelength_num, data = dat)
  pred <- predict(mod, newdata = data.frame("Wavelength_num" = first_SWIR))
  out <- data.frame(Pot = dat$Pot[1], pred_1002.18 = pred)
  predictions <- rbind(predictions, out)
}


# 3. Apply correction
correction_1002.18 <- ref_dat %>% 
  filter(Wavelength_num > 1001, Wavelength_num < 1003) %>% 
  left_join(predictions) %>%
  mutate(difference = Smoothed_reflectance - pred_1002.18) %>%
  select(difference, Pot)

SWIR_corrected <- SWIR_cut %>% 
  left_join(correction_1002.18) %>% 
  mutate(reflectance_corrected = Smoothed_reflectance - difference) %>%
  filter(!is.na(reflectance_corrected))
VNIR_cut$difference <- NA
VNIR_cut$reflectance_corrected <- VNIR_cut$Smoothed_reflectance
corrected_ref <- rbind(VNIR_cut, SWIR_corrected)

summary(corrected_ref$reflectance_corrected)

# 4. Check corrected reflectance
ggplot(corrected_ref %>% filter(Wavelength_num > 900, 
                                Wavelength_num < 1100, 
                                AccessionName == "Kayat_071"),
       aes(x= Wavelength_num, y= reflectance_corrected)) +
  geom_line(aes(group=Pot)) +
  labs(x = "Wavelength", title = "Corrected reflectance")


# write_csv(corrected_ref, file = "Out/Smoothed reflectance/Smoothed reflectance jumps removed.csv")
