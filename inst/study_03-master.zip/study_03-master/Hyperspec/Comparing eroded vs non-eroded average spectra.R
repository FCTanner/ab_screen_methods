### study_03 Comparing eroded vs non-eroded average spectra 

.libPaths("C:/R-packages2")
rm(list=ls())
library(tidyverse)
library(ggplot2)
library(plotly)
extrafont::loadfonts(device = "win")
theme_set(theme_bw(base_family= "Open Sans"))

eroded <- read_csv("C:/Users/a1789609/r-projects/adelaide/predict_DI/Data/hyperspec_eroded.csv") %>% 
  janitor::clean_names()
non_eroded <- read_csv("C:/Users/a1789609/r-projects/adelaide/predict_DI/Data/hyperspec.csv") %>% 
  janitor::clean_names()


eroded$erosion <- "Three by three"
non_eroded$erosion <- "None"
non_eroded$n_foreground <- NA

data <- rbind(non_eroded, eroded)

p <- data %>%
  filter(n_foreground > 10 | is.na(n_foreground)) %>% 
  ggplot(aes(x= wavelength, y = reflectance, group = pot)) +
  geom_line(alpha = 0.4) +
  facet_wrap(~erosion) 

ggplotly(p)


