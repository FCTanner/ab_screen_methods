### study_03 Averaging reflectance per entry
.libPaths("C:/R-packages2")
rm(list=ls())
library(tidyverse)

# 1. Averaging reflectance per entry
# 2. Write outfiles
# 1.1 VNIR
VNIR_base_dir <- "Out/Segmentation/VNIR/Predicted foreground pixels/"
VNIR_contents <- dir(VNIR_base_dir)

## Initializing out file
VNIR_dat <- read.csv(paste0(VNIR_base_dir, VNIR_contents[1]), colClasses = numeric(), header = T)
VNIR_out <- VNIR_dat[FALSE,]
VNIR_out$Entry <- as.character()
VNIR_out$n <- as.numeric()

## Reading all pixel data and averaging across each wavelength
for(file in VNIR_contents){
  dat <- read.csv(paste0(VNIR_base_dir, file))
  print(file)
  if(nrow(dat) >0 ){
    dat <- dat
    dat$Entry <- as.character(file)
    avg_ref <- dat %>% group_by(Entry) %>% summarise(across(where(is.numeric), mean), n= n())
    print("Means appended")
    VNIR_out <- rbind(VNIR_out, avg_ref)
  }
  else{
    print("Empty file")
  }
  print(nrow(VNIR_out))
}

# 1.2 SWIR
SWIR_base_dir <- "Out/Segmentation/SWIR/Predicted foreground pixels/"

SWIR_contents <- dir(SWIR_base_dir)


## Initializing out file
SWIR_dat <- read.csv(paste0(SWIR_base_dir, SWIR_contents[1]), colClasses = numeric(), header = T)
SWIR_out <- SWIR_dat[FALSE,]
SWIR_out$Entry <- as.character()
SWIR_out$n <- as.numeric()

## Reading all pixel data and averaging across each wavelength
for(file in SWIR_contents){
  dat <- read.csv(paste0(SWIR_base_dir, file))
  print(file)
  if(nrow(dat) >0 ){
    dat <- dat
    dat$Entry <- as.character(file)
    avg_ref <- dat %>% group_by(Entry) %>% summarise(across(where(is.numeric), mean), n= n())
    print("Means appended")
    SWIR_out <- rbind(SWIR_out, avg_ref)
  }
  else{
    print("Empty file")
  }
  print(nrow(SWIR_out))
}


# 2. Write outfiles
write_csv(VNIR_out, "Out/Average reflectance/Average VNIR reflectance.csv")
write_csv(SWIR_out, "Out/Average reflectance/Average SWIR reflectance.csv")



