# study_03 random sampling for hyperspec training data -> annotate these pixels for background and foreground
.libPaths("C:/R-packages2")
rm(list=ls())

hyperspecnames <- read.delim("E:/Florian/study_03/TPA imaging/Hyperspec/list.txt")

hyperspecnames$number <-substr(hyperspecnames$list.txt, start = 13, stop =16)
numbers <- unique(hyperspecnames$number)
set.seed(123)
sample_set <- sample(numbers, 15)

write.csv(sample_set, "Out/Random sample for hyperspec training data.csv", row.names =  F)
