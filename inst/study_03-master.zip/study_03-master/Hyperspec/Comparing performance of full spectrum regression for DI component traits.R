## study_03 Comparing performance of full spectrum regression for DI component traits

## Lib path
.libPaths("C:/R-packages2")
rm(list=ls())

library(tidymodels)
library(tidyverse)
library(tidytext)
library(ggplot2); theme_set(theme_bw())
library(ggsci)
library(patchwork)

predictions <- read_csv("Out/Full spectrum regression/Disease Index and components metrics/Predictions.csv")
metrics <- read_csv("Out/Full spectrum regression/Disease Index and components metrics/Metrics.csv")

# predictions$train[predictions$train == "Test set"] <- "Validation set"
# metrics$train[metrics$train == "Test set"] <- "Validation set"

# Metrics evaluation ------------------------------------------------------

p_test_metrics<- metrics %>% 
  filter(.metric == "rsq", train == "Test set") %>% 
  ggplot(aes(x = .estimate, y = reorder_within(model, .estimate, response),  fill = model )) +
  geom_col(alpha = 0.7, color = "black", width = 0.7) + 
  facet_wrap(~response, scales= "free_y", nrow = 5) + 
  scale_x_continuous(breaks = c(0,0.2,0.4,0.6,0.8,1), limits = c(0,1)) +
  scale_y_reordered() + 
  labs(title = "Test set", y = NULL, x = "R-squared") +
  scale_fill_jco()

p_test_metrics

p_train_metrics<- metrics %>% 
  filter(.metric == "rsq", train == "Training set") %>% 
  ggplot(aes(x = .estimate, y = reorder_within(model, .estimate, response),  fill = model )) +
  geom_col(alpha = 0.7, color = "black", width = 0.7) + 
  facet_wrap(~response, scales= "free_y", nrow = 5) + 
  scale_x_continuous(breaks = c(0,0.2,0.4,0.6,0.8,1), limits = c(0,1)) +
  scale_y_reordered() + 
  labs(title = "Training set", y = NULL, x = "R-squared") +
  scale_fill_jco()


p_train_metrics

p_metrics <- p_train_metrics + p_test_metrics + plot_annotation(title = "Metrics for full spectrum regression (DI < 100)") + plot_layout(guides = "collect")
p_metrics

# ggsave(p_metrics, filename = "Out/Graphs/Full spectrum model performance for DI component traits/Full spectrum regression metrics.png",
#        device = "png", units = "cm", width= 14, height= 12, limitsize = F, scale = 1.35)
# ggsave(p_metrics, filename = "Out/Graphs/Full spectrum model performance for DI component traits/Full spectrum regression metrics.pdf",
#        device = "pdf", units = "cm", width= 14, height= 12, limitsize = F, scale = 1.35)



# Predictions evaluation --------------------------------------------------

p_predictions <- predictions %>% 
  filter(model == "LASSO") %>% 
  ggplot(aes(x = truth, y = .pred, color = response)) +
  geom_abline(lty = 2, color = "gray80", size = 1.3) +
  geom_point(alpha = 0.8) +
  facet_grid(response~train) +
  labs(x = "Ground truth",
       y = "Prediction",
       color = "Response variable",
       title = "LASSO Full spectrum regression (DI < 100)"
  ) +
  scale_x_continuous(limits = c(-2,102), breaks = c(0,25,50,75,100)) +
  scale_y_continuous(limits = c(-2,110), breaks = c(0,25,50,75,100)) +
  scale_color_jco()

# ggsave(p_predictions, filename = "Out/Graphs/Full spectrum model performance for DI component traits/Lasso full spectrum regression predictions.png",
#        device = "png", units = "cm", width= 14, height= 12, limitsize = F, scale = 1.2)
# ggsave(p_predictions, filename = "Out/Graphs/Full spectrum model performance for DI component traits/Lasso full spectrum regression predictions.pdf",
#        device = "pdf", units = "cm", width= 14, height= 12, limitsize = F, scale = 1.2)


