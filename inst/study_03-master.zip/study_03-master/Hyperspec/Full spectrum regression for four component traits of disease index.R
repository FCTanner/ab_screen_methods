## study_03 full spectrum regression four component traits of disease index
## A lot copy and paste from https://juliasilge.com/blog/lasso-the-office/

## Lib path
.libPaths("C:/R-packages2")
rm(list=ls())

library(tidymodels)
library(tidyverse)
library(ggplot2); theme_set(theme_bw())
library(ggsci)
library(vip)

# Data prep ---------------------------------------------------------------

ref <- read_csv("Out/Smoothed reflectance/Smoothed reflectance jumps removed.csv")

scores <- read_csv("../R out/2020-11-19 Scores.csv")
scores$Pot[scores$Pot == "Gen 6"] <- "712 A"
scores$Pot[scores$Pot == "How 8"] <- "732 A"
scores$Pot[scores$Pot == "How 6"] <- "716 A"
scores$Pot[scores$Pot == "Gen 4"] <- "720 A"
scores$Pot[scores$Pot == "How 3"] <- "724 A"
scores$Pot[scores$Pot == "Gen 7"] <- "728 A"

ref_wide <- ref %>% # This process introduces NAs for some reason 
  select(c(Pot, type, AccessionName, Wavelength_num, reflectance_corrected)) %>%
  filter(Pot != "561 A") %>% 
  pivot_wider(id_cols = c(-reflectance_corrected, -Wavelength_num), 
              names_from = Wavelength_num, 
              values_from = reflectance_corrected) %>% 
  left_join(scores) %>% 
  filter(!is.na(DI), DI < 100) %>% # Cap DI!, this balances dataset + removes those pots that have hardly any foreground pixels
  rename(perc_main_stem_broken = `% main stem broken`, 
         perc_main_stem_lesions = `% main stem lesions`,
         perc_side_branches_diseased = `% side branches diseased`,
         perc_leaf_area_disease = `% LAD`)
head(colnames(ref_wide))

ref_wide %>% summarise(count = sum(is.na(across()))) # Total number of missing values
names(ref_wide)


# Pipeline for testing five traits -----------------------------------------
# Using copy and paste because I could not get the for loop to work

traits <- c("perc_main_stem_broken", "perc_main_stem_lesions", "perc_side_branches_diseased", "perc_leaf_area_disease", "DI")

# Initialize dataframe to store metrics
test_set_metrics <- data.frame(model = character(), .metric = character(), .estimator = character(), .estimate = numeric(), response = character())
train_set_metrics <- data.frame(model = character(), .metric = character(), .estimator = character(), .estimate = numeric(), response = character())

predictions_out <- data.frame(.pred = numeric(), truth = numeric(), model = character(), train = character(), response = character())
  

# DI ----------------------------------------------------------------------

set.seed(123)


ref_split <- ref_wide %>%
  initial_split(p= 0.75,
                strata = DI)
ref_train <- training(ref_split)
ref_test <- testing(ref_split)

plot(ref_train$DI)
plot(ref_test$DI)


# Preprocessing

ref_recipe <- recipe((DI ~ .), 
                     data = ref_train %>% select(-Pot, 
                                                 -perc_main_stem_broken,
                                                 -perc_main_stem_lesions,
                                                 -perc_side_branches_diseased,
                                                 -perc_leaf_area_disease,
                                                 -disease_severity_score, 
                                                 -score_JD)) %>%
  update_role(type, new_role = "ID") %>% 
  update_role(AccessionName, new_role = "ID") %>% 
  step_center(all_predictors()) %>%
  step_scale(all_predictors()) %>%
  step_zv(all_predictors()) 


pls_recipe <- ref_recipe %>% 
  step_pls(all_predictors(), outcome = "DI", num_comp = 6)


ref_prep <- ref_recipe %>% prep()
pls_prep <- pls_recipe %>% prep()

ref_prep
pls_prep  


# Specify models

rf_spec <- rand_forest() %>%
  set_engine("ranger") %>%
  set_mode("regression")

svm_spec <- svm_rbf() %>% 
  set_engine("kernlab") %>% 
  set_mode("regression") %>% 
  translate()


linreg_spec <- linear_reg() %>% 
  set_engine("lm")

lasso_spec <- linear_reg(penalty = 0.1, mixture = 1) %>% 
  set_engine("glmnet")

ridge_reg_spec <- linear_reg(penalty = 0.1, mixture = 0) %>% 
  set_engine("glmnet")

# Workflows

rf_workflow <- workflow() %>% 
  add_model(rf_spec) %>% 
  add_recipe(ref_recipe)

rf_workflow


svm_workflow <- workflow() %>% 
  add_model(svm_spec) %>% 
  add_recipe(ref_recipe)

svm_workflow

pls_workflow <- workflow() %>% 
  add_model(linreg_spec) %>% 
  add_recipe(pls_recipe)

lasso_workflow <- workflow() %>% 
  add_model(lasso_spec) %>% 
  add_recipe(ref_recipe)

ridge_reg_workflow <- workflow() %>% 
  add_model(ridge_reg_spec) %>% 
  add_recipe(ref_recipe)

# Fit models

rf_fit <- 
  rf_workflow %>% 
  fit(data = ref_train)

svm_fit <- 
  svm_workflow %>% 
  fit(data = ref_train)

pls_fit <- 
  pls_workflow %>% 
  fit(data = ref_train)

lasso_fit <- 
  lasso_workflow %>% 
  fit(data = ref_train)

ridge_reg_fit <-
  ridge_reg_workflow %>% 
  fit(data = ref_train)

# Predict

# Test set
results_test <- rf_fit %>%
  predict(new_data = ref_test) %>%
  mutate(
    truth = ref_test$DI,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$DI,
                model = "SVM"
              )) %>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$DI,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$DI,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$DI,
                model = "Ridge Regression"
              ))



# Train set
results_train <- rf_fit %>%
  predict(new_data = ref_train) %>%
  mutate(
    truth = ref_train$DI,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$DI,
                model = "SVM"
              ))%>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$DI,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$DI,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$DI,
                model = "Ridge Regression"
              ))


# Store predictions 
predictions <- results_test %>% 
  mutate(train = "Test set",
         response = "DI") %>% 
  bind_rows(results_train %>% 
              mutate(train = "Training set",
                     response = "DI"))

predictions_out <- rbind(predictions_out, predictions)
# Metrics 
# Test set
test_metrics <- results_test %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred) %>% 
  mutate(response = "DI")
test_metrics <- rbind(test_metrics,   results_test %>%
                        group_by(model) %>%
                        rmse(truth = truth, estimate = .pred) %>%
                        mutate(response = "DI"))

test_set_metrics <- rbind(test_set_metrics, test_metrics)

# Train set
train_metrics <- results_train %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred) %>% 
  mutate(response = "DI")
train_metrics <- rbind(train_metrics,   results_train %>%
                         group_by(model) %>%
                         rmse(truth = truth, estimate = .pred) %>%
                         mutate(response = "DI"))
train_set_metrics <- rbind(train_set_metrics, train_metrics)



# perc_main_stem_broken ---------------------------------------------------


set.seed(123)


ref_split <- ref_wide %>%
  initial_split(p= 0.75,
                strata = perc_main_stem_broken)
ref_train <- training(ref_split)
ref_test <- testing(ref_split)

plot(ref_train$perc_main_stem_broken)
plot(ref_test$perc_main_stem_broken)


# Preprocessing

ref_recipe <- recipe((perc_main_stem_broken ~ .), 
                     data = ref_train %>% select(-Pot, 
                                                 -DI,
                                                 -perc_main_stem_lesions,
                                                 -perc_side_branches_diseased,
                                                 -perc_leaf_area_disease,
                                                 -disease_severity_score, 
                                                 -score_JD)) %>%
  update_role(type, new_role = "ID") %>% 
  update_role(AccessionName, new_role = "ID") %>% 
  step_center(all_predictors()) %>%
  step_scale(all_predictors()) %>%
  step_zv(all_predictors()) 


pls_recipe <- ref_recipe %>% 
  step_pls(all_predictors(), outcome = "perc_main_stem_broken", num_comp = 6)


ref_prep <- ref_recipe %>% prep()
pls_prep <- pls_recipe %>% prep()

ref_prep
pls_prep  


# Specify models

rf_spec <- rand_forest() %>%
  set_engine("ranger") %>%
  set_mode("regression")

svm_spec <- svm_rbf() %>% 
  set_engine("kernlab") %>% 
  set_mode("regression") %>% 
  translate()


linreg_spec <- linear_reg() %>% 
  set_engine("lm")

lasso_spec <- linear_reg(penalty = 0.1, mixture = 1) %>% 
  set_engine("glmnet")

ridge_reg_spec <- linear_reg(penalty = 0.1, mixture = 0) %>% 
  set_engine("glmnet")

# Workflows

rf_workflow <- workflow() %>% 
  add_model(rf_spec) %>% 
  add_recipe(ref_recipe)

rf_workflow


svm_workflow <- workflow() %>% 
  add_model(svm_spec) %>% 
  add_recipe(ref_recipe)

svm_workflow

pls_workflow <- workflow() %>% 
  add_model(linreg_spec) %>% 
  add_recipe(pls_recipe)

lasso_workflow <- workflow() %>% 
  add_model(lasso_spec) %>% 
  add_recipe(ref_recipe)

ridge_reg_workflow <- workflow() %>% 
  add_model(ridge_reg_spec) %>% 
  add_recipe(ref_recipe)

# Fit models

rf_fit <- 
  rf_workflow %>% 
  fit(data = ref_train)

svm_fit <- 
  svm_workflow %>% 
  fit(data = ref_train)

pls_fit <- 
  pls_workflow %>% 
  fit(data = ref_train)

lasso_fit <- 
  lasso_workflow %>% 
  fit(data = ref_train)

ridge_reg_fit <-
  ridge_reg_workflow %>% 
  fit(data = ref_train)

# Predict

# Test set
results_test <- rf_fit %>%
  predict(new_data = ref_test) %>%
  mutate(
    truth = ref_test$perc_main_stem_broken,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_main_stem_broken,
                model = "SVM"
              )) %>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_main_stem_broken,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_main_stem_broken,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_main_stem_broken,
                model = "Ridge Regression"
              ))



# Train set
results_train <- rf_fit %>%
  predict(new_data = ref_train) %>%
  mutate(
    truth = ref_train$perc_main_stem_broken,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_main_stem_broken,
                model = "SVM"
              ))%>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_main_stem_broken,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_main_stem_broken,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_main_stem_broken,
                model = "Ridge Regression"
              ))


# Store predictions 
predictions <- results_test %>% 
  mutate(train = "Test set",
         response = "perc_main_stem_broken") %>% 
  bind_rows(results_train %>% 
              mutate(train = "Training set",
                     response = "perc_main_stem_broken"))

predictions_out <- rbind(predictions_out, predictions)

# Metrics 
# Test set
test_metrics <- results_test %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred) %>% 
  mutate(response = "perc_main_stem_broken")
test_metrics <- rbind(test_metrics,   results_test %>%
                        group_by(model) %>%
                        rmse(truth = truth, estimate = .pred) %>%
                        mutate(response = "perc_main_stem_broken"))

test_set_metrics <- rbind(test_set_metrics, test_metrics)

# Train set
train_metrics <- results_train %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred) %>% 
  mutate(response = "perc_main_stem_broken")
train_metrics <- rbind(train_metrics,   results_train %>%
                         group_by(model) %>%
                         rmse(truth = truth, estimate = .pred) %>%
                         mutate(response = "perc_main_stem_broken"))
train_set_metrics <- rbind(train_set_metrics, train_metrics)

test_set_metrics
# perc_main_stem_lesions --------------------------------------------------


set.seed(123)


ref_split <- ref_wide %>%
  initial_split(p= 0.75,
                strata = perc_main_stem_lesions)
ref_train <- training(ref_split)
ref_test <- testing(ref_split)

plot(ref_train$perc_main_stem_lesions)
plot(ref_test$perc_main_stem_lesions)


# Preprocessing

ref_recipe <- recipe((perc_main_stem_lesions ~ .), 
                     data = ref_train %>% select(-Pot, 
                                                 -perc_main_stem_broken,
                                                 -DI,
                                                 -perc_side_branches_diseased,
                                                 -perc_leaf_area_disease,
                                                 -disease_severity_score, 
                                                 -score_JD)) %>%
  update_role(type, new_role = "ID") %>% 
  update_role(AccessionName, new_role = "ID") %>% 
  step_center(all_predictors()) %>%
  step_scale(all_predictors()) %>%
  step_zv(all_predictors()) 


pls_recipe <- ref_recipe %>% 
  step_pls(all_predictors(), outcome = "perc_main_stem_lesions", num_comp = 6)


ref_prep <- ref_recipe %>% prep()
pls_prep <- pls_recipe %>% prep()

ref_prep
pls_prep  


# Specify models

rf_spec <- rand_forest() %>%
  set_engine("ranger") %>%
  set_mode("regression")

svm_spec <- svm_rbf() %>% 
  set_engine("kernlab") %>% 
  set_mode("regression") %>% 
  translate()


linreg_spec <- linear_reg() %>% 
  set_engine("lm")

lasso_spec <- linear_reg(penalty = 0.1, mixture = 1) %>% 
  set_engine("glmnet")

ridge_reg_spec <- linear_reg(penalty = 0.1, mixture = 0) %>% 
  set_engine("glmnet")

# Workflows

rf_workflow <- workflow() %>% 
  add_model(rf_spec) %>% 
  add_recipe(ref_recipe)

rf_workflow


svm_workflow <- workflow() %>% 
  add_model(svm_spec) %>% 
  add_recipe(ref_recipe)

svm_workflow

pls_workflow <- workflow() %>% 
  add_model(linreg_spec) %>% 
  add_recipe(pls_recipe)

lasso_workflow <- workflow() %>% 
  add_model(lasso_spec) %>% 
  add_recipe(ref_recipe)

ridge_reg_workflow <- workflow() %>% 
  add_model(ridge_reg_spec) %>% 
  add_recipe(ref_recipe)

# Fit models

rf_fit <- 
  rf_workflow %>% 
  fit(data = ref_train)

svm_fit <- 
  svm_workflow %>% 
  fit(data = ref_train)

pls_fit <- 
  pls_workflow %>% 
  fit(data = ref_train)

lasso_fit <- 
  lasso_workflow %>% 
  fit(data = ref_train)

ridge_reg_fit <-
  ridge_reg_workflow %>% 
  fit(data = ref_train)

# Predict

# Test set
results_test <- rf_fit %>%
  predict(new_data = ref_test) %>%
  mutate(
    truth = ref_test$perc_main_stem_lesions,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_main_stem_lesions,
                model = "SVM"
              )) %>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_main_stem_lesions,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_main_stem_lesions,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_main_stem_lesions,
                model = "Ridge Regression"
              ))



# Train set
results_train <- rf_fit %>%
  predict(new_data = ref_train) %>%
  mutate(
    truth = ref_train$perc_main_stem_lesions,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_main_stem_lesions,
                model = "SVM"
              ))%>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_main_stem_lesions,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_main_stem_lesions,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_main_stem_lesions,
                model = "Ridge Regression"
              ))


# Store predictions 
predictions <- results_test %>% 
  mutate(train = "Test set",
         response = "perc_main_stem_lesions") %>% 
  bind_rows(results_train %>% 
              mutate(train = "Training set",
                     response = "perc_main_stem_lesions"))

predictions_out <- rbind(predictions_out, predictions)


# Metrics 
# Test set
test_metrics <- results_test %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred) %>% 
  mutate(response = "perc_main_stem_lesions")
test_metrics <- rbind(test_metrics,   results_test %>%
                        group_by(model) %>%
                        rmse(truth = truth, estimate = .pred) %>%
                        mutate(response = "perc_main_stem_lesions"))

test_set_metrics <- rbind(test_set_metrics, test_metrics)

# Train set
train_metrics <- results_train %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred) %>% 
  mutate(response = "perc_main_stem_lesions")
train_metrics <- rbind(train_metrics,   results_train %>%
                         group_by(model) %>%
                         rmse(truth = truth, estimate = .pred) %>%
                         mutate(response = "perc_main_stem_lesions"))
train_set_metrics <- rbind(train_set_metrics, train_metrics)
# perc_side_branches_diseased ---------------------------------------------


set.seed(123)


ref_split <- ref_wide %>%
  initial_split(p= 0.75,
                strata = perc_side_branches_diseased)
ref_train <- training(ref_split)
ref_test <- testing(ref_split)

plot(ref_train$perc_side_branches_diseased)
plot(ref_test$perc_side_branches_diseased)


# Preprocessing

ref_recipe <- recipe((perc_side_branches_diseased ~ .), 
                     data = ref_train %>% select(-Pot, 
                                                 -perc_main_stem_broken,
                                                 -perc_main_stem_lesions,
                                                 -DI,
                                                 -perc_leaf_area_disease,
                                                 -disease_severity_score, 
                                                 -score_JD)) %>%
  update_role(type, new_role = "ID") %>% 
  update_role(AccessionName, new_role = "ID") %>% 
  step_center(all_predictors()) %>%
  step_scale(all_predictors()) %>%
  step_zv(all_predictors()) 


pls_recipe <- ref_recipe %>% 
  step_pls(all_predictors(), outcome = "perc_side_branches_diseased", num_comp = 6)


ref_prep <- ref_recipe %>% prep()
pls_prep <- pls_recipe %>% prep()

ref_prep
pls_prep  


# Specify models

rf_spec <- rand_forest() %>%
  set_engine("ranger") %>%
  set_mode("regression")

svm_spec <- svm_rbf() %>% 
  set_engine("kernlab") %>% 
  set_mode("regression") %>% 
  translate()


linreg_spec <- linear_reg() %>% 
  set_engine("lm")

lasso_spec <- linear_reg(penalty = 0.1, mixture = 1) %>% 
  set_engine("glmnet")

ridge_reg_spec <- linear_reg(penalty = 0.1, mixture = 0) %>% 
  set_engine("glmnet")

# Workflows

rf_workflow <- workflow() %>% 
  add_model(rf_spec) %>% 
  add_recipe(ref_recipe)

rf_workflow


svm_workflow <- workflow() %>% 
  add_model(svm_spec) %>% 
  add_recipe(ref_recipe)

svm_workflow

pls_workflow <- workflow() %>% 
  add_model(linreg_spec) %>% 
  add_recipe(pls_recipe)

lasso_workflow <- workflow() %>% 
  add_model(lasso_spec) %>% 
  add_recipe(ref_recipe)

ridge_reg_workflow <- workflow() %>% 
  add_model(ridge_reg_spec) %>% 
  add_recipe(ref_recipe)

# Fit models

rf_fit <- 
  rf_workflow %>% 
  fit(data = ref_train)

svm_fit <- 
  svm_workflow %>% 
  fit(data = ref_train)

pls_fit <- 
  pls_workflow %>% 
  fit(data = ref_train)

lasso_fit <- 
  lasso_workflow %>% 
  fit(data = ref_train)

ridge_reg_fit <-
  ridge_reg_workflow %>% 
  fit(data = ref_train)

# Predict

# Test set
results_test <- rf_fit %>%
  predict(new_data = ref_test) %>%
  mutate(
    truth = ref_test$perc_side_branches_diseased,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_side_branches_diseased,
                model = "SVM"
              )) %>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_side_branches_diseased,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_side_branches_diseased,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_side_branches_diseased,
                model = "Ridge Regression"
              ))



# Train set
results_train <- rf_fit %>%
  predict(new_data = ref_train) %>%
  mutate(
    truth = ref_train$perc_side_branches_diseased,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_side_branches_diseased,
                model = "SVM"
              ))%>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_side_branches_diseased,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_side_branches_diseased,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_side_branches_diseased,
                model = "Ridge Regression"
              ))


# Store predictions 
predictions <- results_test %>% 
  mutate(train = "Test set",
         response = "perc_side_branches_diseased") %>% 
  bind_rows(results_train %>% 
              mutate(train = "Training set",
                     response = "perc_side_branches_diseased"))

predictions_out <- rbind(predictions_out, predictions)


# Metrics 
# Test set
test_metrics <- results_test %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred) %>% 
  mutate(response = "perc_side_branches_diseased")
test_metrics <- rbind(test_metrics,   results_test %>%
                        group_by(model) %>%
                        rmse(truth = truth, estimate = .pred) %>%
                        mutate(response = "perc_side_branches_diseased"))

test_set_metrics <- rbind(test_set_metrics, test_metrics)

# Train set
train_metrics <- results_train %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred) %>% 
  mutate(response = "perc_side_branches_diseased")
train_metrics <- rbind(train_metrics,   results_train %>%
                         group_by(model) %>%
                         rmse(truth = truth, estimate = .pred) %>%
                         mutate(response = "perc_side_branches_diseased"))
train_set_metrics <- rbind(train_set_metrics, train_metrics)


# perc_leaf_area_disease --------------------------------------------------


set.seed(123)


ref_split <- ref_wide %>%
  initial_split(p= 0.75,
                strata = perc_leaf_area_disease)
ref_train <- training(ref_split)
ref_test <- testing(ref_split)

plot(ref_train$perc_leaf_area_disease)
plot(ref_test$perc_leaf_area_disease)


# Preprocessing

ref_recipe <- recipe((perc_leaf_area_disease ~ .), 
                     data = ref_train %>% select(-Pot, 
                                                 -perc_main_stem_broken,
                                                 -perc_main_stem_lesions,
                                                 -perc_side_branches_diseased,
                                                 -DI,
                                                 -disease_severity_score, 
                                                 -score_JD)) %>%
  update_role(type, new_role = "ID") %>% 
  update_role(AccessionName, new_role = "ID") %>% 
  step_center(all_predictors()) %>%
  step_scale(all_predictors()) %>%
  step_zv(all_predictors()) 


pls_recipe <- ref_recipe %>% 
  step_pls(all_predictors(), outcome = "perc_leaf_area_disease", num_comp = 6)


ref_prep <- ref_recipe %>% prep()
pls_prep <- pls_recipe %>% prep()

ref_prep
pls_prep  


# Specify models

rf_spec <- rand_forest() %>%
  set_engine("ranger") %>%
  set_mode("regression")

svm_spec <- svm_rbf() %>% 
  set_engine("kernlab") %>% 
  set_mode("regression") %>% 
  translate()


linreg_spec <- linear_reg() %>% 
  set_engine("lm")

lasso_spec <- linear_reg(penalty = 0.1, mixture = 1) %>% 
  set_engine("glmnet")

ridge_reg_spec <- linear_reg(penalty = 0.1, mixture = 0) %>% 
  set_engine("glmnet")

# Workflows

rf_workflow <- workflow() %>% 
  add_model(rf_spec) %>% 
  add_recipe(ref_recipe)

rf_workflow


svm_workflow <- workflow() %>% 
  add_model(svm_spec) %>% 
  add_recipe(ref_recipe)

svm_workflow

pls_workflow <- workflow() %>% 
  add_model(linreg_spec) %>% 
  add_recipe(pls_recipe)

lasso_workflow <- workflow() %>% 
  add_model(lasso_spec) %>% 
  add_recipe(ref_recipe)

ridge_reg_workflow <- workflow() %>% 
  add_model(ridge_reg_spec) %>% 
  add_recipe(ref_recipe)

# Fit models

rf_fit <- 
  rf_workflow %>% 
  fit(data = ref_train)

svm_fit <- 
  svm_workflow %>% 
  fit(data = ref_train)

pls_fit <- 
  pls_workflow %>% 
  fit(data = ref_train)

lasso_fit <- 
  lasso_workflow %>% 
  fit(data = ref_train)

ridge_reg_fit <-
  ridge_reg_workflow %>% 
  fit(data = ref_train)

# Predict

# Test set
results_test <- rf_fit %>%
  predict(new_data = ref_test) %>%
  mutate(
    truth = ref_test$perc_leaf_area_disease,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_leaf_area_disease,
                model = "SVM"
              )) %>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_leaf_area_disease,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_leaf_area_disease,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$perc_leaf_area_disease,
                model = "Ridge Regression"
              ))



# Train set
results_train <- rf_fit %>%
  predict(new_data = ref_train) %>%
  mutate(
    truth = ref_train$perc_leaf_area_disease,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_leaf_area_disease,
                model = "SVM"
              ))%>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_leaf_area_disease,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_leaf_area_disease,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$perc_leaf_area_disease,
                model = "Ridge Regression"
              ))


# Store predictions 
predictions <- results_test %>% 
  mutate(train = "Test set",
         response = "perc_leaf_area_disease") %>% 
  bind_rows(results_train %>% 
              mutate(train = "Training set",
                     response = "perc_leaf_area_disease"))

predictions_out <- rbind(predictions_out, predictions)

# Metrics 
# Test set
test_metrics <- results_test %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred) %>% 
  mutate(response = "perc_leaf_area_disease")
test_metrics <- rbind(test_metrics,   results_test %>%
                        group_by(model) %>%
                        rmse(truth = truth, estimate = .pred) %>%
                        mutate(response = "perc_leaf_area_disease"))

test_set_metrics <- rbind(test_set_metrics, test_metrics)

# Train set
train_metrics <- results_train %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred) %>% 
  mutate(response = "perc_leaf_area_disease")
train_metrics <- rbind(train_metrics,   results_train %>%
                         group_by(model) %>%
                         rmse(truth = truth, estimate = .pred) %>%
                         mutate(response = "perc_leaf_area_disease"))
train_set_metrics <- rbind(train_set_metrics, train_metrics)






test_set_metrics$train <- "Test set"
train_set_metrics$train <- "Training set"
metrics_out <- rbind(test_set_metrics, train_set_metrics)

# write_csv(predictions_out, "Out/Full spectrum regression/Disease Index and components metrics/Predictions.csv")
# write_csv(metrics_out, "Out/Full spectrum regression/Disease Index and components metrics/Metrics.csv")
