#!/usr/bin/env python
# coding: utf-8

import cv2
import os
import numpy as np
import pandas as pd
import time
from APPF_toolbox.envi_funs import read_hyper_data, calibrate_hyper_data

# Steps
## On mask
### Open mask
### Make binary
### Apply 3*3 erosion
### Count number of foreground pixels, filter out if under a certain number


## Open hyperspec
### Calibrate
### Extract pixels of mask
### Average
### Append number of pixels
### Export

swir_predicted_masks_base_dir = "../../Out/Segmentation/SWIR/Predicted masks/"
masks_list = os.listdir(swir_predicted_masks_base_dir)

swir_data_base_dir = "E:/Florian/study_03/TPA imaging/Hyperspec/SWIR"
swir_data = os.listdir(swir_data_base_dir)

masks_list.sort()
swir_data.sort()


exit
# Calibration
raw_data, meta_plant = read_hyper_data(swir_data_base_dir, swir_data[10])
ncols = meta_plant.ncols
nrows = meta_plant.nrows
nbands = meta_plant.nbands
wavelengths = np.zeros((meta_plant.metadata['Wavelength'].__len__(), ))
for i in range(wavelengths.size):
    wavelengths[i] = float(meta_plant.metadata['Wavelength'][i])

def count_pixels(mask_in):
    mask_1d = np.reshape(mask_in, (mask_in.shape[0] * mask_in.shape[1]))
    n_pixels = len(mask_1d[mask_1d>0])
    return(n_pixels)

# Some things to print progress
left_to_do = len(swir_data)
done = 0
duration_list = []


for mask, swir_folder in zip(masks_list, swir_data):
    print("#############################################################################")
    print(swir_folder)
    start = time.time()
    # Open mask
    mask_path = os.path.join(swir_predicted_masks_base_dir, mask)
    mask_img = cv2.imread(mask_path)
    # cv2.imshow("Original mask", mask_img)
    # cv2.waitKey(500)

    # Make binary
    lower_red = np.array([0, 0, 254])
    upper_red = np.array([100, 100, 255])
    mask = cv2.inRange(mask_img, lower_red, upper_red)
    # cv2.destroyAllWindows()
    # cv2.imshow("Mask binary",mask)
    # cv2.waitKey(500)

    # 3*3 erosion
    kernel3 = np.ones((3,3), np.uint8)
    mask_eroded =  cv2.erode(mask, kernel3, iterations=1)
    # cv2.imshow("Mask eroded",mask_eroded)
    # cv2.waitKey(500)
    # cv2.destroyAllWindows()

    # Count pixels
    n_foreground = count_pixels(mask_eroded)

    # Open SWIR
    SWIR_dict, meta_plant_dat = read_hyper_data(swir_data_base_dir, swir_folder)
    hyper = calibrate_hyper_data(white=SWIR_dict["white"],
                                 dark=SWIR_dict["dark"],
                                 plant=SWIR_dict["plant"])

    # Mask hyperspec
    the_shape_of_hyperspec_to_come = mask_eroded.shape[0] # Size of hyperspec masks differs, see VNIR as well
    mask_eroded_3d = np.reshape(mask_eroded, (the_shape_of_hyperspec_to_come,384,1))
    hyper_masked = hyper * mask_eroded_3d/255
    hyper_2d = hyper_masked.reshape((-1, 288))

    # Extract foreground pixels
    foreground_out = np.reshape(wavelengths, (1,288))
    for pixel in hyper_2d:
        if sum(pixel) == 0:
            pass
        else:
            pixel = np.reshape(pixel, (1,288))
            foreground_out = np.append(foreground_out, pixel, axis = 0)

    # Average reflectance and export
    foreground_df = pd.DataFrame(foreground_out[1:], columns= wavelengths)
    df_mean = foreground_df.mean(axis = 'index')
    meta_df = pd.DataFrame({'n_foreground': n_foreground, 'file': swir_folder}, index = [0])
    mean_out_path = os.path.join("Out/SWIR/Avg_ref/{}.csv".format(swir_folder))
    df_mean.to_csv(mean_out_path)
    meta_out_path = os.path.join("Out/SWIR/Meta/{}.csv".format(swir_folder))
    meta_df.to_csv(meta_out_path)
    stop = time.time()
    duration = stop - start
    print("This took ", round(duration), "seconds.")
    left_to_do = left_to_do-1
    print(left_to_do, " erosions left to do!")