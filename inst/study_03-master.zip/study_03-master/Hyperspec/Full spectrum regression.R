## study_03 full spectrum regression
## A lot copy and paste from https://juliasilge.com/blog/lasso-the-office/

## Lib path
.libPaths("C:/R-packages2")
rm(list=ls())

library(tidymodels)
library(tidyverse)
library(ggplot2); theme_set(theme_bw())
library(ggsci)
library(vip)

# Data prep ---------------------------------------------------------------


ref <- read_csv("Out/Smoothed reflectance/Smoothed reflectance jumps removed.csv")

scores <- read_csv("../R out/2020-11-19 Scores.csv")
scores$Pot[scores$Pot == "Gen 6"] <- "712 A"
scores$Pot[scores$Pot == "How 8"] <- "732 A"
scores$Pot[scores$Pot == "How 6"] <- "716 A"
scores$Pot[scores$Pot == "Gen 4"] <- "720 A"
scores$Pot[scores$Pot == "How 3"] <- "724 A"
scores$Pot[scores$Pot == "Gen 7"] <- "728 A"

ref_wide <- ref %>% # This process introduces NAs for some reason 
  select(c(Pot, type, AccessionName, Wavelength_num, reflectance_corrected)) %>%
  filter(Pot != "561 A") %>% 
  pivot_wider(id_cols = c(-reflectance_corrected, -Wavelength_num), 
              names_from = Wavelength_num, 
              values_from = reflectance_corrected) %>% 
  left_join(scores) %>% 
  filter(!is.na(DI), DI < 100) # Cap DI!, this balances dataset + removes those pots that have hardly any foreground pixels
head(colnames(ref_wide))

ref_wide %>% summarise(count = sum(is.na(across()))) # Total number of missing values


# Test train split --------------------------------------------------------

set.seed(123)


ref_split <- ref_wide %>%
  initial_split(p= 0.75,
                strata = DI)
ref_train <- training(ref_split)
ref_test <- testing(ref_split)

plot(ref_train$DI)
plot(ref_test$DI)


# Preprocessing -----------------------------------------------------------

ref_recipe <- recipe((DI ~ .), 
                     data = ref_train %>% select(-Pot, 
                                                 -`% main stem broken`,
                                                 -`% main stem lesions`,
                                                 -`% side branches diseased`,
                                                 -`% LAD`,
                                                 -disease_severity_score, 
                                                 -score_JD)) %>%
  update_role(type, new_role = "ID") %>% 
  update_role(AccessionName, new_role = "ID") %>% 
  step_center(all_predictors()) %>%
  step_scale(all_predictors()) %>%
  step_zv(all_predictors()) 


pls_recipe <- ref_recipe %>% 
  step_pls(all_predictors(), outcome = "DI", num_comp = 6)


ref_prep <- ref_recipe %>% prep()
pls_prep <- pls_recipe %>% prep()

ref_prep
pls_prep  


# Specify models ----------------------------------------------------------

rf_spec <- rand_forest() %>%
  set_engine("ranger") %>%
  set_mode("regression")

svm_spec <- svm_rbf() %>% 
  set_engine("kernlab") %>% 
  set_mode("regression") %>% 
  translate()


linreg_spec <- linear_reg() %>% 
  set_engine("lm")

lasso_spec <- linear_reg(penalty = 0.1, mixture = 1) %>% 
  set_engine("glmnet")

ridge_reg_spec <- linear_reg(penalty = 0.1, mixture = 0) %>% 
  set_engine("glmnet")

# Workflows ----------------------------------------------------------------

rf_workflow <- workflow() %>% 
  add_model(rf_spec) %>% 
  add_recipe(ref_recipe)

rf_workflow


svm_workflow <- workflow() %>% 
  add_model(svm_spec) %>% 
  add_recipe(ref_recipe)

svm_workflow

pls_workflow <- workflow() %>% 
  add_model(linreg_spec) %>% 
  add_recipe(pls_recipe)

lasso_workflow <- workflow() %>% 
  add_model(lasso_spec) %>% 
  add_recipe(ref_recipe)

ridge_reg_workflow <- workflow() %>% 
  add_model(ridge_reg_spec) %>% 
  add_recipe(ref_recipe)

# Fit models ---------------------------------------------------------------

rf_fit <- 
  rf_workflow %>% 
  fit(data = ref_train)

svm_fit <- 
  svm_workflow %>% 
  fit(data = ref_train)

pls_fit <- 
  pls_workflow %>% 
  fit(data = ref_train)

lasso_fit <- 
  lasso_workflow %>% 
  fit(data = ref_train)

ridge_reg_fit <-
  ridge_reg_workflow %>% 
  fit(data = ref_train)

# Predict  ----------------------------------------------------------------

# Test set
results_test <- rf_fit %>%
  predict(new_data = ref_test) %>%
  mutate(
    truth = ref_test$DI,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$DI,
                model = "SVM"
              )) %>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$DI,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$DI,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$DI,
                model = "Ridge Regression"
              ))



# Train set
results_train <- rf_fit %>%
  predict(new_data = ref_train) %>%
  mutate(
    truth = ref_train$DI,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$DI,
                model = "SVM"
              ))%>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$DI,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$DI,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$DI,
                model = "Ridge Regression"
              ))

# Evaluate ----------------------------------------------------------------


# Metrics 
# Test set
results_test %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred)
results_test %>%
  group_by(model) %>%
  rmse(truth = truth, estimate = .pred)
# Train set
results_train %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred)

results_train %>%
  group_by(model) %>%
  rmse(truth = truth, estimate = .pred)
  

# Graph
p_model_perf <- results_test %>% 
  mutate(train = "Test set") %>% 
  bind_rows(results_train %>% 
              mutate(train = "Training set")) %>% 
  filter(model != "Ridge Regression") %>% 
  ggplot(aes(x = truth, y = .pred, color = model)) +
  geom_abline(lty = 2, color = "gray80", size = 1.3) +
  geom_point(alpha = 0.8) +
  facet_grid(model~train) +
  labs(x = "True DI",
    y = "Predicted DI",
    color = "Type of model"
  ) +
  scale_x_continuous(limits = c(-2,102), breaks = c(0,25,50,75,100)) +
  scale_y_continuous(limits = c(-2,110), breaks = c(0,25,50,75,100)) +
  scale_color_jco()

# ggsave(p_model_perf,
#        file = "Out/Graphs/Model performance for predicting DI/Model performance DI capped under 100.png",
#        device = "png", width = 14, height =12, units = "cm", limitsize = F, dpi = 600,
#        scale = 1)

# Tune LASSO parameters ---------------------------------------------------
# great for variable selection! watch out for correlated variables though 
set.seed(123)
ref_boot <- bootstraps(ref_train, strata = DI) 

lasso_tune_spec <- linear_reg(penalty = tune(), mixture = 1) %>%
  set_engine("glmnet")

lambda_grid <- grid_regular(penalty(), levels = 50)

lasso_grid <- tune_grid(
  lasso_workflow %>% update_model(lasso_tune_spec),
  resamples = ref_boot,
  grid = lambda_grid
)

lasso_grid %>%
  collect_metrics()

lasso_grid %>%
  collect_metrics() %>%
  ggplot(aes(penalty, mean, color = .metric)) +
  geom_errorbar(aes(
    ymin = mean - std_err,
    ymax = mean + std_err
  ),
  alpha = 0.5
  ) +
  geom_line(size = 1.5) +
  facet_wrap(~.metric, scales = "free", nrow = 2) +
  scale_x_log10() +
  theme(legend.position = "none")

lasso_lowest_rmse <- lasso_grid %>%
  select_best("rmse", maximize = FALSE)

final_lasso_workflow <- finalize_workflow(
  lasso_workflow %>% update_model(lasso_tune_spec),
  lasso_lowest_rmse
)

lasso_vip <- final_lasso_workflow %>%
  fit(ref_train) %>%
  pull_workflow_fit() %>%
  vi(lambda = lasso_lowest_rmse$penalty)

lasso_vip %>%
  mutate(
    Importance = abs(Importance),
    Variable = fct_reorder(Variable, Importance)
  ) %>%
  head(15) %>% 
  ggplot(aes(x = Importance, y = Variable, fill = Sign)) +
  geom_col() +
  scale_x_continuous(expand = c(0, 0)) +
  labs(y = NULL)


final_lasso_fit <- last_fit(final_lasso_workflow, ref_split) 

final_lasso_metrics <- final_lasso_fit %>% 
  collect_metrics()

summary(final_lasso_fit)

# write_csv(lasso_vip, "Out/LASSO variable importance/Lasso variable importance DI under 100.csv")




# Deprecated -----------------------------------------------------
# Penalized regression parameter tuning -----------------------------------

pen_reg_tune_spec <- linear_reg(penalty = tune(), mixture = tune()) %>%
  set_engine("glmnet")

pen_reg_lambda_grid <- crossing(penalty = 10^seq(-3, 0, length = 30),
                                mixture = c(0.01, 0.25, 0.50, 0.75, 1))

pen_reg_grid <- tune_grid(
  ridge_reg_workflow %>% update_model(pen_reg_tune_spec),
  resamples = ref_boot,
  grid = pen_reg_lambda_grid
)

pen_reg_grid %>%
  collect_metrics() %>% 
  filter(.metric == "rsq") %>%
  arrange(desc(mean))

pen_reg_grid %>%
  collect_metrics() %>%
  ggplot(aes(penalty, mean, color = .metric)) +
  geom_errorbar(aes(
    ymin = mean - std_err,
    ymax = mean + std_err
  ),
  alpha = 0.5
  ) +
  geom_line(size = 1.5) +
  facet_grid(mixture~.metric, scales = "free") +
  scale_x_log10() +
  theme(legend.position = "none")

pen_reg_lowest_rmse <- pen_reg_grid %>%
  select_best("rmse", maximize = FALSE)

final_pen_reg_workflow <- finalize_workflow(
  ridge_reg_workflow %>% update_model(pen_reg_tune_spec),
  pen_reg_lowest_rmse
)

final_pen_reg_workflow %>%
  fit(ref_train) %>%
  pull_workflow_fit() %>%
  vi(lambda = pen_reg_lowest_rmse$penalty) %>%
  mutate(
    Importance = abs(Importance),
    Variable = fct_reorder(Variable, Importance)
  ) %>%
  head(50) %>% 
  ggplot(aes(x = Importance, y = Variable, fill = Sign)) +
  geom_col() +
  scale_x_continuous(expand = c(0, 0)) +
  labs(y = NULL)


final_pen_reg_metrics <- last_fit(final_pen_reg_workflow, ref_split) %>% 
  collect_metrics()

final_pen_reg_metrics

last_rf_mod <- 
  rand_forest() %>% 
  set_engine("ranger", importance = "impurity") %>% 
  set_mode("classification")

last_ref_workflow <- 
  ref_workflow %>%
  update_model(last_rf_mod)

set.seed(123)
last_rf_fit <- 
  last_ref_workflow %>% 
  last_fit(ref_split)

last_rf_fit %>%
  collect_metrics()

last_rf_fit %>% 
  pluck(".workflow", 1) %>%   
  pull_workflow_fit() %>% 
  vip(num_features = 50)


