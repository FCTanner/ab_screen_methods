## study_03 LASSO variable importance exploration

## Lib path
.libPaths("C:/R-packages2")
rm(list=ls())


library(tidyverse)
library(ggplot2); theme_set(theme_bw())
library(ggsci)
library(skimr)



# Data prep ---------------------------------------------------------------


ref <- read_csv("Out/Smoothed reflectance/Smoothed reflectance jumps removed.csv")

scores <- read_csv("../R out/2020-11-19 Scores.csv")
scores$Pot[scores$Pot == "Gen 6"] <- "712 A"
scores$Pot[scores$Pot == "How 8"] <- "732 A"
scores$Pot[scores$Pot == "How 6"] <- "716 A"
scores$Pot[scores$Pot == "Gen 4"] <- "720 A"
scores$Pot[scores$Pot == "How 3"] <- "724 A"
scores$Pot[scores$Pot == "Gen 7"] <- "728 A"

lasso_vip <- read_csv("Out/LASSO variable importance/Lasso variable importance DI under 100.csv")

ref_wide <- ref %>% # This process introduces NAs for some reason 
  select(c(Pot, type, AccessionName, Wavelength_num, reflectance_corrected)) %>%
  filter(Pot != "561 A") %>% 
  pivot_wider(id_cols = c(-reflectance_corrected, -Wavelength_num), 
              names_from = Wavelength_num, 
              values_from = reflectance_corrected) %>% 
  left_join(scores) %>% 
  filter(!is.na(DI), DI < 100)
head(colnames(ref_wide))

ref_wide %>% summarise(count = sum(is.na(across()))) # Total number of missing values


# Plotting important variables on spectrum  -------------------------------

names(ref_wide)

ref_wide %>%  
  select(Pot, DI, disease_severity_score, score_JD) %>% 
  distinct() %>% 
  count(DI) %>% 
  ggplot(aes(x = DI, y = n)) +
  geom_col()

ref_plot <- ref %>% 
  left_join(scores)

ref_plot$disease_status <- NA
ref_plot$disease_status[ref_plot$DI < 30] <- "DI < 30"
ref_plot$disease_status[ref_plot$DI > 30 & ref_plot$DI < 60] <- "DI 30 - 70"
ref_plot$disease_status[ref_plot$DI > 70] <- "DI > 70"
ref_plot$disease_status[ref_plot$DI == 100] <- "DI = 100"

factor_levels <- c("DI < 30", "DI 30 - 70", "DI > 70", "DI = 100")

skim(ref_plot)
names(ref_plot)

mean_ref <-ref_plot %>% 
  filter(!is.na(disease_status)) %>% 
  group_by(disease_status, Wavelength_num) %>% 
  summarise(mean_reflectance = mean(reflectance_corrected))

p_spectrum <- lasso_vip %>% 
  head(10) %>% 
  ggplot() +
  geom_col(aes(x = as.numeric(Variable), 
               y = 0.3),
           color = "gray80")  +
  geom_line(data = mean_ref, 
            aes(x= Wavelength_num, 
                y = mean_reflectance, 
                linetype = fct_relevel(disease_status, factor_levels),
                color = fct_relevel(disease_status, factor_levels)),
            size = 1) +
  scale_y_continuous(limits = c(0, 0.3)) +
  scale_color_jco() + 
  theme(panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()) + 
  coord_cartesian(xlim= c(350, 2550), expand = FALSE) +
  labs(x = "Wavelength [nm]", 
       y = "Reflectance", 
       fill = "Variable influence", 
       linetype = "Disease\nIndex",
       color = "Disease\nIndex") 

# ggsave(p_spectrum,
#        file = "Out/Graphs/LASSO important variables/Important variables on spectrum DI under 100.png",
#        device = "png", width = 14, height =10, units = "cm", limitsize = F,
#        scale = 1.2)
# 
# ggsave(p_spectrum,
#        file = "Out/Graphs/LASSO important variables/Important variables on spectrum DI under 100.pdf",
#        device = "pdf", width = 14, height =10, units = "cm", limitsize = F,
#        scale = 1.2)


# Linear model with n important variables ---------------------------------

first_VIs <- as.character(head(lasso_vip$Variable, 4))

vi_lm_mod <- lm(DI ~ `956.69` + `1593.08` + `404.86` + `684.82`, data = ref_wide)
vi_lm_mod
summary(vi_lm_mod)

anova(vi_lm_mod)

# Plotting model including first 4 important variables as predicto --------

predict_df <- ref_wide %>% select(first_VIs, DI)
predict_df$predict_DI <- predict(vi_lm_mod, newdata = predict_df)

predict_df %>% 
  pivot_longer(cols = c(DI, predict_DI), names_to = "disease_index") %>% 
  ggplot(aes(x= `956.69`, y = value, color = disease_index, shape = disease_index)) +
  geom_point() +
  scale_y_continuous(breaks = c(0,25,50,75,100))
