### study_03 Hyperspec Exploratory analysis 
## Lib path
.libPaths("C:/R-packages2")
rm(list=ls())
library(tidyverse)
library(ggsci)
library(ggplot2); theme_set(theme_bw())
library(plotly)
library(skimr)


# Data prep ---------------------------------------------------------------

ref_dat <- read_csv("Out/Smoothed reflectance/Smoothed reflectance jumps removed.csv")
scores <- read_csv("../R out/2020-11-19 Scores.csv")

scores$Pot[scores$Pot == "Gen 6"] <- "712 A"
scores$Pot[scores$Pot == "How 8"] <- "732 A"
scores$Pot[scores$Pot == "How 6"] <- "716 A"
scores$Pot[scores$Pot == "Gen 4"] <- "720 A"
scores$Pot[scores$Pot == "How 3"] <- "724 A"
scores$Pot[scores$Pot == "Gen 7"] <- "728 A"

dat <- left_join(ref_dat, scores)

table(ref_dat$type)

dat %>% select(type, Pot, AccessionName, DI) %>%filter(is.na(type))%>% distinct()

ref_wide <- ref_dat %>% 
  select(c(Pot, type, AccessionName, Wavelength_num, reflectance_corrected)) %>%
  filter(Pot != "561 A") %>% 
  pivot_wider(id_cols = c(-reflectance_corrected, -Wavelength_num), 
              names_from = Wavelength_num, 
              values_from = reflectance_corrected)



# Band pair correlation ---------------------------------------------------

cor_mat <- 
  as.data.frame(cor(ref_wide %>% select(-Pot, -AccessionName, -type), method = "pearson"))

cor_mat$Wavelength <- row.names(cor_mat)

plot_mat <- cor_mat %>% 
  pivot_longer(cols = -Wavelength, names_to = "cor_ref", values_to = "correlation") %>% 
  mutate(Wavelength = as.numeric(Wavelength), 
         cor_ref = as.numeric(cor_ref),
         r_squared = correlation * correlation)

p_cor <- plot_mat %>% 
  ggplot(aes(x= Wavelength, y = cor_ref, fill = r_squared)) +
  geom_tile(data = plot_mat %>% filter(Wavelength < 1001, cor_ref < 1001),
            height = 1.4, width = 1.4) +
  geom_tile(data = plot_mat %>% filter(Wavelength > 1001, cor_ref > 1001),
            height = 5.65, width = 5.65) +
  geom_tile(data = plot_mat %>% filter(Wavelength > 1001, cor_ref < 1001),
            height = 1.4, width = 5.65) +
  geom_tile(data = plot_mat %>% filter(Wavelength < 1001, cor_ref > 1001),
            height = 5.65, width = 1.4) +
  scale_fill_viridis_c() +
  labs(x = "Wavelength [nm]",y = "Wavelength [nm]", fill = "R-squared")

p_cor

# ggsave(p_cor, filename = paste0("Out/Graphs/Band pair correlation/",
#                                 format(Sys.Date()),
#                                 " Band pair correlation.pdf"),
#        device = "pdf", units = "cm", width = 14, height = 12, limitsize = F)
# 
# ggsave(p_cor, filename = paste0("Out/Graphs/Band pair correlation/",
#                                 format(Sys.Date()),
#                                 " Band pair correlation.jpg"),
#        device = "jpg", units = "cm", width = 14, height = 12, limitsize = F)


# Does reflectance predict disease index? - plots -------------------------


p_DI_ref <- ggplot(dat %>% filter(!is.na(type)), aes(Wavelength_num, y = reflectance_corrected, color = DI, group = Pot)) +
  geom_line(alpha = 0.3) +
  scale_color_viridis_c() +
  facet_wrap(~type) +
  labs(x = "Wavelength", y= "Reflectance", title = "Reflectance vs disease index")


p_DI_ref

p_DI_notdead_ref <- ggplot(dat %>% filter(!is.na(type), DI < 100), aes(Wavelength_num, y = reflectance_corrected, color = DI, group = Pot)) +
  geom_line(alpha = 0.6) +
  scale_color_viridis_c() +
  facet_wrap(~type) +
  labs(x = "Wavelength", y= "Reflectance", title = "Reflectance vs disease index")

p_DI_notdead_ref

p_DI <- ggplot(dat %>% filter(!is.na(type)), aes(x= DI, color = type, fill = type)) +
                 geom_density(alpha = 0.2)


p_DI

p_DI_ref_FLIP <-
  ggplot(dat %>% filter(type == "FLIP", Pot != "561 A"), aes(Wavelength_num, y = reflectance_corrected, color = DI, group = Pot)) +
  geom_line(alpha = 0.6) +
  scale_color_viridis_c() +
  labs(x = "Wavelength", y= "Reflectance", title = "Reflectance vs disease index (FLIP lines)")

p_DI_ref_FLIP

# ggplotly(p_DI_ref_FLIP)

# ggsave(p_DI_ref_FLIP, filename = paste0("Out/Graphs/Reflectance vs disease index/",
#                                                   format(Sys.Date()),
#                                                   " Processed reflectance vs disease index (FLIP only).jpg"),
#        device = "jpg", units = "cm", width = 14, height = 12, limitsize = F, dpi = 600)
# 
# ggsave(p_DI_ref_FLIP, filename = paste0("Out/Graphs/Reflectance vs disease index/",
#                                         format(Sys.Date()),
#                                         " Processed reflectance vs disease index (FLIP only).pdf"),
#        device = "pdf", units = "cm", width = 14, height = 12, limitsize = F)



