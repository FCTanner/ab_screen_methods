## study_03 Smoothing

.libPaths("C:/R-packages2")
rm(list=ls())
library(tidyverse)
library(ggplot2); theme_set(theme_bw())
library(prospectr)

# 1. Load data
VNIR_ref <- read_csv("Out/Average reflectance/Average VNIR reflectance cleaned.csv")
SWIR_ref <- read_csv("Out/Average reflectance/Average SWIR reflectance cleaned.csv")

colnames(VNIR_ref)

idcols <- c("Entry", "Pot", "AccessionName", "type", "ID", "ID_with_controls")

VNIR_dat_wide <- VNIR_ref %>% pivot_wider(id_cols = idcols, names_from = Wavelength_num, values_from = Reflectance, values_fn = mean)
VNIR_ref_matrix <- VNIR_dat_wide %>% select(-idcols)
VNIR_id_matrix <- VNIR_dat_wide %>% select(idcols)

SWIR_dat_wide <- SWIR_ref %>% pivot_wider(id_cols = idcols, names_from = Wavelength_num, values_from = Reflectance, values_fn = mean)
SWIR_ref_matrix <- SWIR_dat_wide %>% select(-idcols)
SWIR_id_matrix <- SWIR_dat_wide %>% select(idcols)

# 2. Smooth
test_savgol_param <- function(ref_matrix, 
                              id_matrix, 
                              poly_order = 3, 
                              window_length = c(3,5,7,9,11,13,15,17,19),
                              start_wavelength = 400,
                              stop_wavelength = 1000,
                              original_dat = VNIR_ref,
                              select_pot = "How 6"){
  for(wl in window_length){
    print(paste0("Window length = ", wl, " , Polynomial order = ", poly_order))
    smoothed_df <- cbind(as.data.frame(savitzkyGolay(ref_matrix, p = poly_order, w = wl, m = 0)), id_matrix) %>% 
      pivot_longer(cols = -idcols, names_to = "Wavelength_num",  values_to = "reflectance_smoothed")
    smoothed_df$Wavelength_num <- as.numeric(smoothed_df$Wavelength_num)
    s <- smoothed_df %>% filter(Pot == select_pot, 
                                Wavelength_num > start_wavelength, Wavelength_num<stop_wavelength)
    original_dat$Wavelength_num <- as.numeric(original_dat$Wavelength_num)
    o <- original_dat %>% filter(Pot == select_pot, 
                                 Wavelength_num > start_wavelength, Wavelength_num<stop_wavelength)
    p_smooth <- ggplot(s) +
      geom_line(aes(x = Wavelength_num, y = reflectance_smoothed, group = Pot), color= "red") +
      geom_line(data = o, aes(x = Wavelength_num, y = Reflectance, group = Pot), color= "black", alpha = 0.5) +
      labs(title = paste0("P. order = ", poly_order, " Window = ", wl), x = "Wavelength", y = "Reflectance")
    plot(p_smooth)
    if(length(window_length) == 1){
      return(p_smooth)}
    else{
    }
  }
}

test_savgol_param(ref_matrix = VNIR_ref_matrix, 
                  id_matrix = VNIR_id_matrix, 
                  window_length = c(5,7,9,13, 15, 17, 19, 21), 
                  start_wavelength = 450,
                  stop_wavelength = 550,
                  original_dat = VNIR_ref)

test_savgol_param(ref_matrix = VNIR_ref_matrix, 
                  id_matrix = VNIR_id_matrix, 
                  window_length = c(5,7,9,13, 15, 17, 19, 21), 
                  start_wavelength = 800,
                  stop_wavelength = 1000,
                  original_dat = VNIR_ref)

test_savgol_param(ref_matrix = VNIR_ref_matrix, 
                  id_matrix = VNIR_id_matrix, 
                  window_length = c(5,7,9,13, 15, 17, 19, 21), 
                  start_wavelength = 400,
                  stop_wavelength = 1000,
                  original_dat = VNIR_ref)

test_savgol_param(ref_matrix = VNIR_ref_matrix, 
                  id_matrix = VNIR_id_matrix, 
                  window_length = c(5,7,9,13, 15, 17, 19, 21), 
                  start_wavelength = 400,
                  stop_wavelength = 500,
                  original_dat = VNIR_ref)

test_savgol_param(ref_matrix = VNIR_ref_matrix, 
                  id_matrix = VNIR_id_matrix, 
                  window_length = c(5,7,9,13, 15, 17, 19, 21), 
                  start_wavelength = 670,
                  stop_wavelength = 800,
                  original_dat = VNIR_ref)

test_savgol_param(ref_matrix = VNIR_ref_matrix, 
                  id_matrix = VNIR_id_matrix, 
                  window_length = c(5,7,9,13, 15, 17, 19, 21), 
                  start_wavelength = 950,
                  stop_wavelength = 1200,
                  original_dat = VNIR_ref)

VNIR_wl = 19
VNIR_poly = 3
VNIR_smoothed <- cbind(as.data.frame(savitzkyGolay(VNIR_ref_matrix,p = VNIR_poly, w = VNIR_wl , m = 0)), VNIR_id_matrix) %>% 
  pivot_longer(cols = -idcols, names_to = "Wavelength_num",  values_to = "Smoothed_reflectance_chosen_wl")

VNIR_ref$Wavelength_num <- as.character(VNIR_ref$Wavelength_num)

VNIR_smoothed_out <- VNIR_ref %>% 
  left_join(VNIR_smoothed)

# Pad ends with windowlength 5 smoothing:
VNIR_smoothed_ends <- cbind(as.data.frame(savitzkyGolay(VNIR_ref_matrix,p = 3, w = 5 , m = 0)), VNIR_id_matrix) %>% 
  pivot_longer(cols = -idcols, names_to = "Wavelength_num",  values_to = "Smoothed_reflectance_w5")


VNIR_smoothed_padded_out <- VNIR_smoothed_out %>% 
  left_join(VNIR_smoothed_ends) %>%
  mutate(Smoothed_reflectance = coalesce(Smoothed_reflectance_chosen_wl, Smoothed_reflectance_w5))


# 2.2 SWIR
test_savgol_param(ref_matrix = SWIR_ref_matrix, 
                  id_matrix = SWIR_id_matrix,
                  window_length = c(5,7,9,11,13,15),
                  start_wavelength = 900,
                  stop_wavelength = 2600,
                  original_dat = SWIR_ref)

test_savgol_param(ref_matrix = SWIR_ref_matrix, 
                  id_matrix = SWIR_id_matrix,
                  window_length = c(5,7,9,11,13,15),
                  start_wavelength = 900,
                  stop_wavelength = 1200,
                  original_dat = SWIR_ref)

test_savgol_param(ref_matrix = SWIR_ref_matrix, 
                  id_matrix = SWIR_id_matrix,
                  window_length = c(5,7,9,11,13,15),
                  start_wavelength = 2000,
                  stop_wavelength = 2600,
                  original_dat = SWIR_ref)



SWIR_wl = 9
SWIR_poly =3 
SWIR_smoothed <- cbind(as.data.frame(savitzkyGolay(SWIR_ref_matrix,p = SWIR_poly, w = SWIR_wl , m = 0)), SWIR_id_matrix) %>% 
  pivot_longer(cols = -idcols, names_to = "Wavelength_num",  values_to = "Smoothed_reflectance_chosen_wl")
SWIR_ref$Wavelength_num <- as.character(SWIR_ref$Wavelength_num)

SWIR_smoothed_out <- SWIR_ref %>% left_join(SWIR_smoothed)

# Pad ends with windowlength 5 smoothing:
SWIR_smoothed_ends <- cbind(as.data.frame(savitzkyGolay(SWIR_ref_matrix,p = 3, w = 5 , m = 0)), SWIR_id_matrix) %>% 
  pivot_longer(cols = -idcols, names_to = "Wavelength_num",  values_to = "Smoothed_reflectance_w5")


SWIR_smoothed_padded_out <- SWIR_smoothed_out %>% 
  left_join(SWIR_smoothed_ends) %>%
  mutate(Smoothed_reflectance = coalesce(Smoothed_reflectance_chosen_wl, Smoothed_reflectance_w5))


# 3. Write outfiles
write_csv(VNIR_smoothed_padded_out, "Out/Smoothed reflectance/VNIR reflectance smoothed (p=3, wl =19) padded with wl=5.csv")
write_csv(SWIR_smoothed_padded_out, "Out/Smoothed reflectance/SWIR reflectance smoothed (p=3, wl =9) padded with wl=5.csv")


