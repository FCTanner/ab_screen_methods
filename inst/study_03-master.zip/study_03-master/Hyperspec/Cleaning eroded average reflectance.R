### study_03 Cleaning eroded average reflectance

.libPaths("C:/R-packages2")
rm(list=ls())
library(tidyverse)
extrafont::loadfonts()


# Clean VNIR --------------------------------------------------------------

vnir_avg_base_dir <- "Python/Erosion/Out/VNIR/Avg_ref/"
vnir_avg_ref_ls <- dir(vnir_avg_base_dir)

vnir_meta_base_dir <- "Python/Erosion/Out/VNIR/Meta/"
vnir_meta_ls <- dir(vnir_meta_base_dir)

# Read VNIR avg reflectance

vnir_avg <- data.frame(wavelength = numeric(),
                       reflectance= numeric(),
                       camera = character(), 
                       entry = character())

for(i in 1:length(vnir_avg_ref_ls)){
  # Read avg reflectance 
  vnir <- read_csv(paste0(vnir_avg_base_dir, vnir_avg_ref_ls[i]), 
                   col_names = c("wavelength", "reflectance"),
                   skip = 1)
  vnir$camera <- "VNIR"
  vnir$entry <- vnir_avg_ref_ls[i]
  vnir_avg <- rbind(vnir_avg, vnir)
}

# Read VNIR meta data

vnir_meta <- data.frame(entry = character(),
                        n_foreground = numeric())

for(j in 1:length(vnir_meta_ls)){
  meta <- read_csv(paste0(vnir_meta_base_dir, vnir_meta_ls[j]))
  meta <- meta["n_foreground"]
  meta$entry <- vnir_meta_ls[j]
  vnir_meta <- rbind(vnir_meta, meta)
}

vnir <- vnir_avg %>% 
  left_join(vnir_meta)

# Clean SWIR --------------------------------------------------------------

swir_avg_base_dir <- "Python/Erosion/Out/SWIR/Avg_ref/"
swir_avg_ref_ls <- dir(swir_avg_base_dir)

swir_meta_base_dir <- "Python/Erosion/Out/SWIR/Meta/"
swir_meta_ls <- dir(swir_meta_base_dir)

# Read SWIR avg reflectance

swir_avg <- data.frame(wavelength = numeric(),
                       reflectance= numeric(),
                       camera = character(), 
                       entry = character())

for(i in 1:length(swir_avg_ref_ls)){
  # Read avg reflectance 
  swir <- read_csv(paste0(swir_avg_base_dir, swir_avg_ref_ls[i]), 
                   col_names = c("wavelength", "reflectance"),
                   skip = 1)
  swir$camera <- "SWIR"
  swir$entry <- swir_avg_ref_ls[i]
  swir_avg <- rbind(swir_avg, swir)
}

# Read SWIR meta data

swir_meta <- data.frame(entry = character(),
                        n_foreground = numeric())

for(j in 1:length(swir_meta_ls)){
  meta <- read_csv(paste0(swir_meta_base_dir, swir_meta_ls[j]))
  meta <- meta["n_foreground"]
  meta$entry <- swir_meta_ls[j]
  swir_meta <- rbind(swir_meta, meta)
}


swir <- swir_avg %>% 
  left_join(swir_meta)



# Matching and more cleaning ----------------------------------------------

wiwam_match <- read_csv("C:/Users/a1789609/r-projects/adelaide/TPA/WIWAM_match/0539 Florian Chickpeas_merged.csv")
design <-  read_csv("../R out/2020-10-27 Sowing plan clean.csv")


eroded_reflectance <- vnir %>% 
  bind_rows(swir) %>% 
  mutate(entry = str_remove(entry, ".csv"),
         id = substr(entry, 6,16)) %>% 
  left_join(wiwam_match %>% 
              rename(Pot = id_tag) %>% 
              mutate(id = substr(file_name, 6, 16))) %>% 
  mutate(Pot = str_replace_all(Pot, 
                           c("Gen 6" = "712 A", "How 8" = "732 A", 
                             "How 6" = "716 A", "Gen 4" = "720 A", 
                             "How 3" ="724 A", "Gen 7" = "728 A" ))) %>% 
  left_join(design) %>% 
  filter(Pot != "CP-0539") %>% 
  select(date, Pot, reflectance, wavelength, camera, n_foreground)


write_csv(eroded_reflectance, "C:/Users/a1789609/r-projects/adelaide/predict_DI/Data/hyperspec_eroded.csv")
# EDA ---------------------------------------------------------------------

vnir_eroded_cutoff <- eroded_reflectance %>% 
  mutate(cutoff = 100) %>% 
  filter(camera == "VNIR",
         n_foreground > cutoff) %>% 
  mutate(n = n_distinct(Pot))

swir_eroded_cutoff <- eroded_reflectance %>% 
  mutate(cutoff = 5) %>% 
  filter(camera == "SWIR",
         n_foreground > cutoff)%>% 
  mutate(n = n_distinct(Pot))

p_cutoff <- vnir_eroded_cutoff %>% 
  bind_rows(swir_eroded_cutoff) %>% 
  select(camera, cutoff, Pot, n_foreground, n) %>% 
  distinct() %>% 
  ggplot(aes(x = n_foreground)) +
  geom_histogram() +
  facet_wrap(~camera, scales = "free_x") +
  theme_bw(base_family = "Open Sans") +
  labs(title = "3*3 erosion of hyperspec masks ", x = "n foreground pixels") +
  geom_vline(aes(xintercept = cutoff), color = "red", linetype = 2) +
  geom_text(aes(x = cutoff^2.15, y = 15, 
                label = paste0("Cutoff of ", 
                               cutoff, " pixels:\n ", n, " pots remain")),  
                vjust = "outward", hjust = "inward",
            family = "Open Sans",
            size = 3)
p_cutoff

ggsave(p_cutoff, filename = "Out/Graphs/Erosion/Remaining_pots.pdf", 
       units = "cm", width= 12, height = 8, device = cairo_pdf, scale = 1.2)
  
