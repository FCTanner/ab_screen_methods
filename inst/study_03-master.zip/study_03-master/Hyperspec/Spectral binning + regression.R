## study_03 Spectral binning + regression
## A lot copy and paste from https://juliasilge.com/blog/lasso-the-office/

## Lib path
.libPaths("C:/R-packages2")
rm(list=ls())

library(tidymodels)
library(tidyverse)
library(ggplot2); theme_set(theme_bw())
library(ggsci)
library(patchwork)
library(vip)

# Data prep ---------------------------------------------------------------


ref <- read_csv("Out/Smoothed reflectance/Smoothed reflectance jumps removed.csv")

scores <- read_csv("../R out/2020-11-19 Scores.csv")
scores$Pot[scores$Pot == "Gen 6"] <- "712 A"
scores$Pot[scores$Pot == "How 8"] <- "732 A"
scores$Pot[scores$Pot == "How 6"] <- "716 A"
scores$Pot[scores$Pot == "Gen 4"] <- "720 A"
scores$Pot[scores$Pot == "How 3"] <- "724 A"
scores$Pot[scores$Pot == "Gen 7"] <- "728 A"

other_scores <- c("% main stem broken", "% main stem lesions", "% side branches diseased", "% LAD", "disease_severity_score", "score_JD")

ref_wide <- ref %>% # This process introduces NAs for some reason 
  select(c(Pot, type, AccessionName, Wavelength_num, reflectance_corrected)) %>%
  filter(Pot != "561 A") %>% 
  pivot_wider(id_cols = c(-reflectance_corrected, -Wavelength_num), 
              names_from = Wavelength_num, 
              values_from = reflectance_corrected) %>% 
  left_join(scores) %>% 
  filter(!is.na(DI), DI < 100) %>% 
  select(-other_scores)# Cap DI!, this balances dataset + removes those pots that have hardly any foreground pixels
head(colnames(ref_wide))

ref_wide %>% summarise(count = sum(is.na(across()))) # Total number of missing values

# Spectral binning --------------------------------------------------------

# Cast dataframe into appropriate form, i.e. make all reflectance data of ref_wide into a matrix 

id_cols <- c("Pot","type", "AccessionName", "DI")
ref_only <- ref_wide %>% select(-id_cols)
id_only <- ref_wide %>% select(id_cols)
ref_only <- as.matrix(ref_only)
ref_binned_10 <- as.data.frame(prospectr::binning(ref_only, bin.size= 10)) %>% bind_cols(id_only)
# Potentially bin at FWHM + use different binsize for VNIR and SWIR 
# Does this function average or just pick certain wavelength? - AVERAGE
ref_binned_10$`407.48` == ref_wide$`407.48`
head(ref_binned_10$`407.48`)
head(ref_wide$`407.48`)


FWHM_NIR <- 5.5
FWHM_SWIR <- 12
n_bin_VNIR <- (1000-400)/(FWHM_NIR)
n_bin_SWIR <- (2500-1000)/(FWHM_SWIR)

VNIR_ref_only <- ref_only[,1:441]
SWIR_ref_only <- ref_only[,442:710]

VNIR_ref_binned_FWHM <- as.data.frame(prospectr::binning(VNIR_ref_only, bins = 125)) %>% bind_cols(id_only)
FWHM_ref_binned <- as.data.frame(prospectr::binning(SWIR_ref_only, bins = 110)) %>% bind_cols(VNIR_ref_binned_FWHM)

VNIR_ref_binned_double_FWHM <- as.data.frame(prospectr::binning(VNIR_ref_only, bins = 62)) %>% bind_cols(id_only)
Double_FWHM_ref_binned <- as.data.frame(prospectr::binning(SWIR_ref_only, bins = 55)) %>% bind_cols(VNIR_ref_binned_double_FWHM)



# Plot different binsizes -------------------------------------------------


pot_id_to_plot <- "109 A"

p_binsize_10 <- ggplot(data = ref_wide %>% filter(Pot ==pot_id_to_plot) %>% 
                         pivot_longer(cols = -id_cols, names_to = "Wavelength", values_to = "Reflectance"), 
                       aes(x  = as.numeric(Wavelength), y = Reflectance, group = Pot)) +
  geom_line() + 
  labs(x= "Wavelength", title = "Binsize = 10 spectal bands for VNIR and SWIR (76 predictors)") +
  geom_line(data = ref_binned_10 %>% filter(Pot ==pot_id_to_plot) %>% 
              pivot_longer(cols = -id_cols, names_to = "Wavelength", values_to = "Reflectance"), 
            aes(x  = as.numeric(Wavelength), y = Reflectance, group = Pot), color= "red", alpha = 0.5) +
  geom_point(data = ref_binned_10 %>% filter(Pot ==pot_id_to_plot) %>% 
               pivot_longer(cols = -id_cols, names_to = "Wavelength", values_to = "Reflectance"), 
             aes(x  = as.numeric(Wavelength), y = Reflectance), color= "red", shape = 1) 


p_binsize_FWHM <- ggplot(data = ref_wide %>% filter(Pot ==pot_id_to_plot) %>% 
                           pivot_longer(cols = -id_cols, names_to = "Wavelength", values_to = "Reflectance"), 
                         aes(x  = as.numeric(Wavelength), y = Reflectance, group = Pot)) +
  geom_line() +  
  labs(x= "Wavelength", title = "Binwidth = FWHM (240 predictors)") +
  geom_line(data = FWHM_ref_binned %>% filter(Pot ==pot_id_to_plot) %>% 
              pivot_longer(cols = -id_cols, names_to = "Wavelength", values_to = "Reflectance"), 
            aes(x  = as.numeric(Wavelength), y = Reflectance, group = Pot), color= "orange", alpha = 0.5) +
  geom_point(data = FWHM_ref_binned %>% filter(Pot ==pot_id_to_plot) %>% 
               pivot_longer(cols = -id_cols, names_to = "Wavelength", values_to = "Reflectance"), 
             aes(x  = as.numeric(Wavelength), y = Reflectance), color= "orange", shape = 1)

p_binsize_double_FWHM <- ggplot(data = ref_wide %>% filter(Pot ==pot_id_to_plot) %>% 
                                  pivot_longer(cols = -id_cols, names_to = "Wavelength", values_to = "Reflectance"), 
                                aes(x  = as.numeric(Wavelength), y = Reflectance, group = Pot)) +
  geom_line() +  
  labs(x= "Wavelength", title = "Binwidth = Double FWHM (122 predictors)") +
  geom_line(data = Double_FWHM_ref_binned %>% filter(Pot ==pot_id_to_plot) %>% 
              pivot_longer(cols = -id_cols, names_to = "Wavelength", values_to = "Reflectance"), 
            aes(x  = as.numeric(Wavelength), y = Reflectance, group = Pot), color= "blue", alpha = 0.5) +
  geom_point(data = Double_FWHM_ref_binned %>% filter(Pot ==pot_id_to_plot) %>% 
               pivot_longer(cols = -id_cols, names_to = "Wavelength", values_to = "Reflectance"), 
             aes(x  = as.numeric(Wavelength), y = Reflectance), color= "blue", shape = 1)

p_spectral_binsize_comp <- p_binsize_10 +  p_binsize_double_FWHM + p_binsize_FWHM +
  plot_annotation(title= "Comparison of spectral binsizes") +
  plot_layout(nrow = 3)

p_spectral_binsize_comp


Double_FWHM_ref_binned  %>% summarise(count = sum(is.na(across()))) 
hist(Double_FWHM_ref_binned$DI) # Looks like normal dist!

# Test train split --------------------------------------------------------

set.seed(123)

ref_split <- Double_FWHM_ref_binned %>%
  initial_split(p= 0.75,
                strata = DI)
ref_train <- training(ref_split)
ref_test <- testing(ref_split)

plot(ref_train$DI)
plot(ref_test$DI)

colnames(ref_train)

# Pre-processing ----------------------------------------------------------

ref_recipe <- recipe((DI ~ .), 
                           data = ref_train %>% select(-Pot)) %>%
  update_role(AccessionName, new_role = "ID") %>% 
  update_role(type, new_role = "ID") %>% 
  step_center(all_predictors()) %>%
  step_scale(all_predictors()) %>%
  step_zv(all_predictors()) 

pls_recipe <- ref_recipe %>% 
  step_pls(all_predictors(), outcome = "DI", num_comp = 6)


ref_prep <- ref_recipe %>% prep()
pls_prep <- pls_recipe %>% prep()

ref_prep
pls_prep


# Specify models ----------------------------------------------------------

rf_spec <- rand_forest() %>%
  set_engine("ranger") %>%
  set_mode("regression")

svm_spec <- svm_rbf() %>% 
  set_engine("kernlab") %>% 
  set_mode("regression") %>% 
  translate()


linreg_spec <- linear_reg() %>% 
  set_engine("lm")

lasso_spec <- linear_reg(penalty = 0.1, mixture = 1) %>% 
  set_engine("glmnet")

ridge_reg_spec <- linear_reg(penalty = 0.1, mixture = 0) %>% 
  set_engine("glmnet")


# Workflows ----------------------------------------------------------------

rf_workflow <- workflow() %>% 
  add_model(rf_spec) %>% 
  add_recipe(ref_recipe)

rf_workflow


svm_workflow <- workflow() %>% 
  add_model(svm_spec) %>% 
  add_recipe(ref_recipe)

svm_workflow

pls_workflow <- workflow() %>% 
  add_model(linreg_spec) %>% 
  add_recipe(pls_recipe)

lasso_workflow <- workflow() %>% 
  add_model(lasso_spec) %>% 
  add_recipe(ref_recipe)

ridge_reg_workflow <- workflow() %>% 
  add_model(ridge_reg_spec) %>% 
  add_recipe(ref_recipe)



# Fit models for 21DAI ----------------------------------------------------


rf_fit <- 
  rf_workflow %>% 
  fit(data = ref_train)

svm_fit <- 
  svm_workflow %>% 
  fit(data = ref_train)

pls_fit <- 
  pls_workflow %>% 
  fit(data = ref_train)

lasso_fit <- 
  lasso_workflow %>% 
  fit(data = ref_train)

ridge_reg_fit <-
  ridge_reg_workflow %>% 
  fit(data = ref_train)


# Predict  ----------------------------------------------------------------

# Test set
results_test <- rf_fit %>%
  predict(new_data = ref_test) %>%
  mutate(
    truth = ref_test$DI,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$DI,
                model = "SVM"
              )) %>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$DI,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$DI,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_test) %>%
              mutate(
                truth = ref_test$DI,
                model = "Ridge Regression"
              ))



# Train set
results_train <- rf_fit %>%
  predict(new_data = ref_train) %>%
  mutate(
    truth = ref_train$DI,
    model = "Random forests"
  ) %>%
  bind_rows(svm_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$DI,
                model = "SVM"
              ))%>%
  bind_rows(pls_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$DI,
                model = "PLSR"
              ))%>%
  bind_rows(lasso_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$DI,
                model = "LASSO"
              ))%>%
  bind_rows(ridge_reg_fit %>%
              predict(new_data = ref_train) %>%
              mutate(
                truth = ref_train$DI,
                model = "Ridge Regression"
              ))

# Evaluate ----------------------------------------------------------------


# Metrics 
# Test set
results_test %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred)
results_test %>%
  group_by(model) %>%
  rmse(truth = truth, estimate = .pred)
# Train set
results_train %>%
  group_by(model) %>%
  rsq(truth = truth, estimate = .pred)

results_train %>%
  group_by(model) %>%
  rmse(truth = truth, estimate = .pred)


# Graph
p <- results_test %>% 
  mutate(train = "Test set") %>% 
  bind_rows(results_train %>% 
              mutate(train = "Training set")) %>% 
  filter(model != "Ridge Regression") %>% 
  ggplot(aes(x = truth, y = .pred, color = model)) +
  geom_abline(lty = 2, color = "gray80", size = 1.3) +
  geom_point(alpha = 0.8) +
  facet_grid(model~train) +
  labs(
    x = "True DI",
    y = "Predicted DI",
    color = "Type of model",
    title = "Nursery spectral binning double FWHM") +
  # scale_x_continuous(limits = c(-3,105)) +
  # scale_y_continuous(limits = c(-3,105)) +
  scale_color_jco()

p
# ggsave(p, file = "Out/Graphs/Spectral binning/Nursery spectral binning double FWHM model performance.png",
#        limitsize = F, width = 14, height = 12, device= "png", units = "cm")
# ggsave(p, file = "Out/Graphs/Spectral binning/Nursery spectral binning double FWHM model performance.pdf",
#        limitsize = F, width = 14, height = 12, device= "pdf", units = "cm")



# Tune LASSO parameters ---------------------------------------------------
# great for variable selection! watch out for correlated variables though 
set.seed(123)
ref_boot <- bootstraps(ref_train, strata = DI) # crearting resamples of training set

lasso_tune_spec <- linear_reg(penalty = tune(), mixture = 1) %>% # Set up parameters to tune
  set_engine("glmnet")

lambda_grid <- grid_regular(penalty(), levels = 50) # Grid for penaly tuning

lasso_grid <- tune_grid(
  lasso_workflow %>% update_model(lasso_tune_spec),
  resamples = ref_boot,
  grid = lambda_grid
)

lasso_grid %>% #Just for inspection
  collect_metrics()

lasso_grid %>% # graph to evaluate performance on resampled train set (Mean rmse, rsq)
  collect_metrics() %>%
  ggplot(aes(penalty, mean, color = .metric)) +
  geom_errorbar(aes(
    ymin = mean - std_err,
    ymax = mean + std_err
  ),
  alpha = 0.5
  ) +
  geom_line(size = 1.5) +
  facet_wrap(~.metric, scales = "free", nrow = 2) +
  scale_x_log10() +
  theme(legend.position = "none")

lasso_highest_rsq <- lasso_grid %>% # select best params
  select_best("rsq")

final_lasso_workflow <- finalize_workflow(
  lasso_workflow %>% update_model(lasso_tune_spec),
  lasso_highest_rsq
)

lasso_vip <- final_lasso_workflow %>%
  fit(ref_train) %>%
  pull_workflow_fit() %>%
  vi(lambda = lasso_highest_rsq$penalty)

lasso_vip %>% # Graph for variable importance
  mutate(
    Importance = abs(Importance),
    Variable = fct_reorder(Variable, Importance)
  ) %>%
  head(15) %>% 
  ggplot(aes(x = Importance, y = Variable, fill = Sign)) +
  geom_col() +
  scale_x_continuous(expand = c(0, 0)) +
  labs(y = NULL)


final_lasso_fit <- last_fit(final_lasso_workflow, ref_split) 

final_lasso_metrics <- final_lasso_fit %>% 
  collect_metrics()
final_lasso_metrics # This is the rsq that should be used for benchmark 
# In addition, give mean rsq and stderr of rsq on fit on 25 bootstrap resamples 

summary(final_lasso_fit)


# Last fit prediction -----------------------------------------------------
# Fit to train set again, after tuning on bootstrapped samples
final_lasso_fit_on_train <-
  final_lasso_workflow %>%
  fit(ref_train) 


results_train_final_lasso_fit <- final_lasso_fit_on_train %>%
  predict(new_data = ref_train) %>%
  mutate(truth = ref_train$DI,
         set = "Train") 

results_test_final_lasso_fit <- final_lasso_fit_on_train %>%
  predict(new_data = ref_test) %>%
  mutate(truth = ref_test$DI,
         set = "Test") 

results_final_lasso_fit <- rbind(results_test_final_lasso_fit, results_train_final_lasso_fit)

p_lasso_optimized <- ggplot(data= results_final_lasso_fit, aes(truth, .pred)) +
  geom_point(shape =1) +
  coord_fixed(xlim = c(0, 100), ylim = c(0, 100)) +
  geom_abline(slope =1 , intercept =0, linetype = 2, color = "grey80", size = 1.2) +
  labs(x= "Ground truth", y = "Prediction") +
  facet_wrap(~set)


p_lasso_optimized



# ggsave(p_lasso_optimized, file = "Out/Graphs/Spectral binning/LASSO optimized performeance, capped under DI 100.png",
#        limitsize =  F, units = "cm", device = "png", width = 12, height = 12)
# ggsave(p_lasso_optimized, file = "Out/Graphs/Spectral binning/LASSO optimized performeance, capped under DI 100.pdf",
#        limitsize =  F, units = "cm", device = "pdf", width = 12, height = 12)



# VNIR only LASSO ---------------------------------------------------------------

set.seed(123)

VNIR_ref_split <- VNIR_ref_binned_FWHM %>%
  initial_split(p= 0.75,
                strata = DI)
VNIR_ref_train <- training(VNIR_ref_split)
VNIR_ref_test <- testing(VNIR_ref_split)

VNIR_ref_recipe <- recipe((DI ~ .), 
                     data = VNIR_ref_train %>% select(-Pot)) %>%
  update_role(AccessionName, new_role = "ID") %>% 
  update_role(type, new_role = "ID") %>% 
  step_center(all_predictors()) %>%
  step_scale(all_predictors()) %>%
  step_zv(all_predictors()) 


VNIR_lasso_workflow <- workflow() %>% 
  add_model(lasso_spec) %>% 
  add_recipe(VNIR_ref_recipe)


set.seed(123)
VNIR_ref_boot <- bootstraps(VNIR_ref_train, strata = DI) # crearting resamples of training set

VNIR_lasso_grid <- tune_grid(
  VNIR_lasso_workflow %>% update_model(lasso_tune_spec),
  resamples = VNIR_ref_boot,
  grid = lambda_grid
)

VNIR_lasso_grid %>% #Just for inspection
  collect_metrics()

VNIR_lasso_grid %>% # graph to evaluate performance on resampled train set (Mean rmse, rsq)
  collect_metrics() %>%
  ggplot(aes(penalty, mean, color = .metric)) +
  geom_errorbar(aes(
    ymin = mean - std_err,
    ymax = mean + std_err
  ),
  alpha = 0.5
  ) +
  geom_line(size = 1.5) +
  facet_wrap(~.metric, scales = "free", nrow = 2) +
  scale_x_log10() +
  theme(legend.position = "none")

VNIR_lasso_highest_rsq <- VNIR_lasso_grid %>% # select best params
  select_best("rsq")

VNIR_final_lasso_workflow <- finalize_workflow(
  VNIR_lasso_workflow %>% update_model(lasso_tune_spec),
  VNIR_lasso_highest_rsq
)

VNIR_lasso_vip <- VNIR_final_lasso_workflow %>%
  fit(VNIR_ref_train) %>%
  pull_workflow_fit() %>%
  vi(lambda = VNIR_lasso_highest_rsq$penalty)

VNIR_lasso_vip %>% # Graph for variable importance
  mutate(
    Importance = abs(Importance),
    Variable = fct_reorder(Variable, Importance)
  ) %>%
  head(15) %>% 
  ggplot(aes(x = Importance, y = Variable, fill = Sign)) +
  geom_col() +
  scale_x_continuous(expand = c(0, 0)) +
  labs(y = NULL)


VNIR_final_lasso_fit <- last_fit(VNIR_final_lasso_workflow, VNIR_ref_split) 

VNIR_final_lasso_metrics <- VNIR_final_lasso_fit %>% 
  collect_metrics()
VNIR_final_lasso_metrics # This is the rsq that should be used for benchmark 
# In addition, give mean rsq and stderr of rsq on fit on 25 bootstrap resamples 

summary(VNIR_final_lasso_fit)
