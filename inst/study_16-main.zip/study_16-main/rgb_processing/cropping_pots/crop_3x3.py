#!/usr/bin/env python
# coding: utf-8

import cv2
import os
import numpy as np
import pandas as pd
import re
import time

date_to_crop = input("Enter date to crop:\n")

base_dir = os.path.join("../../data/terrace_images/fun/rgb/{date_to_crop}/processed/renamed_pngs".format(date_to_crop =date_to_crop))
mask_dir = os.path.join("../../data/terrace_images/fun/rgb/{date_to_crop}/processed/masks".format(date_to_crop =date_to_crop))
out_dir = os.path.join("../../data/out/rgb/cropped_pots")
pot_mapping = "../../helper_files/pot_position_matching/matching_3x3.csv"
pictures = sorted(os.listdir(base_dir))
ink_masks = sorted(os.listdir(mask_dir))

mapping = pd.read_csv(pot_mapping)

scale_factor = 8

def detect_circles(input_img):
    # Threshold for red
    hsv = cv2.cvtColor(input_img, cv2.COLOR_BGR2HSV)
    lower_red = np.array([0, 255, 255])
    upper_red = np.array([0, 255, 255])
    red = cv2.inRange(hsv, lower_red, upper_red)
    # Detect manual circles
    gaussian = cv2.GaussianBlur(red, ksize=(15,15), sigmaX=cv2.BORDER_DEFAULT)
    circles = cv2.HoughCircles(gaussian, cv2.HOUGH_GRADIENT, 2, minDist=100, minRadius=300, maxRadius=320)
    circles_rounded = np.uint16(np.around(circles))
    # print(circles_rounded.shape[1], "Circles found")
    return(circles_rounded)

def crop_circular(detected_circles, input_img):
    cropped_pots = []
    for i in detected_circles[0, :]:
        width = i[0]
        height = i[1]
        radius = 310
        crop = input_img[height-radius:height+radius, width-radius:width+radius] # find dimensions for square crop around pot
        mask = np.zeros(crop.shape, dtype=np.uint8) # create empty mask
        middle = round(mask.shape[0]/2)
        cv2.circle(mask, (middle,middle), radius = radius, color = (255,255,255), thickness = -1) # put white circle on mask
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY) # convert to binary
        ROI = cv2.bitwise_and(crop,crop, mask =mask) # Apply mask to crop
        storage = dict(Width = width, Height = height, Pot = ROI) # use dictionary as storage
        cropped_pots.append(storage) # list of dictionaries
    return(cropped_pots)

def sort_by_position(cropped_circles):
    cropped_circles.sort(key=lambda i: (i['Width'])) # Sort by width
    column1 = cropped_circles[0:3] # Splitting into 4 columns by width
    column2 = cropped_circles[3:6]
    column3 = cropped_circles[6:9]
    column4 = cropped_circles[9:]

    # average each 4 width groups
    column1_sum = 0
    for row in column1:
        column1_sum += row['Width']
    column1_avg = int(column1_sum/3)
    for row in column1:
        row['Column width'] = column1_avg

    column2_sum = 0
    for row in column2:
        column2_sum += row['Width']
    column2_avg = int(column2_sum/3)
    for row in column2:
        row['Column width'] = column2_avg

    column3_sum = 0
    for row in column3:
        column3_sum += row['Width']
    column3_avg = int(column3_sum/3)
    for row in column3:
        row['Column width'] = column3_avg

    column4_sum = 0
    for row in column4:
        column4_sum += row['Width']
    column4_avg = int(column4_sum/3)
    for row in column4:
        row['Column width'] = column4_avg

    # Append all lists sorted by column width
    cropped_circles_pos = column1 + column2 + column3 + column4
    cropped_circles_pos.sort(key=lambda i: (i['Column width'], i['Height'])) # sort by *average width*, height

    # Assign number 1:16 for positions
    position = 1
    for pos in cropped_circles_pos:
        pos['Position'] = position
        position += 1
    return(cropped_circles_pos)

def pull_date_and_name(filename):
    filenamelist = re.split(" |\.", filename)  # splits filename into parts
    date = filenamelist[0]
    if len(filenamelist) > 3: # for the FLIP lines that have "A" in filename
        top_left_pot = filenamelist[1] + " " + filenamelist[2]
    else: # Just extracting the pot number
        top_left_pot = filenamelist[1]
    return date, top_left_pot

def match_position(pot):
    # takes single dictionary
    pot['Date'] = date
    pot['Top left pot'] = top_left_pot
    # print(pot_mapper.iloc[0][position_iter])
    pot['Pot name'] = pot_mapper.iloc[0][position_iter]

left_to_do = len(pictures)
done = 0
duration_list = []


for pic, mk in zip(pictures, ink_masks):
    # timing
    start = time.time()
    # Load image
    path_img = os.path.join(base_dir, pic)
    path_mask = os.path.join(mask_dir, mk)
    print("Image",path_img)
    # print("Mask",path_mask)
    img = cv2.imread(path_img)
    ink_mask = cv2.imread(path_mask)
    ink_mask = cv2.resize(ink_mask, (6000, 4000))
    # print("Mask shape:",ink_mask.shape)
    # print("Image shape:", img.shape)
    img_orig = img.copy()
    img_scale = cv2.resize(img, (int(img.shape[1] / scale_factor), int(img.shape[0] / scale_factor)))
    cv2.imshow("Input image", img_scale)
    cv2.waitKey(1000)
    circles_rounded = detect_circles(ink_mask)
    # print(circles_rounded)
    cropped_circles = crop_circular(circles_rounded, img_orig)
    sorted_pots = sort_by_position(cropped_circles)
    date, top_left_pot = pull_date_and_name(pic)
    pot_mapper = (mapping.loc[mapping['Pot number'] == top_left_pot]) # filter mapper file for specific top left pot
    position_iter = 1
    for pot in sorted_pots:
        # print(pot['Position'])
        cv2.imshow("Cropped portion", pot['Pot'])
        cv2.waitKey(200)
        match_position(pot)
        # print(pot['Top left pot'])
        cv2.imwrite(filename=os.path.join(out_dir, "{Date} {Pot_name}.png".format(Date = pot['Date'],
                                                                                        Pot_name = pot['Pot name'])),
                    img=pot['Pot'])
        position_iter += 1
    # Print statements
    left_to_do = left_to_do - 1
    done += 1
    print("#######################################################")
    print(done, "segmentations are done, ", left_to_do, "iterations left to do ")
    stop = time.time()
    duration = stop - start
    duration_list.append(duration)
    average_duration = sum(duration_list) / len(duration_list)
    print("Approximate time left =", round((left_to_do * average_duration) / 60), "minutes")
    cv2.destroyAllWindows()
    # break

