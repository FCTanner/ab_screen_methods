#!/usr/bin/env python
# coding: utf-8
#  Mainly copied from "Production predict masks optimized"

import itertools
import pickle
import cv2
import os
import numpy as np
import time
from joblib import Parallel, delayed
import random

classifier = "../../helper_files/rgb_foreground_classifier/foreground_classifier.pkl"

png_base_dir = "../../data/out/rgb/cropped_pots"
results_dir = "../../data/out/rgb/classified_masks"

RED = 2
GRN = 1
BLU = 0

H = 620
W = 620

def predict_pixel(clf, img, i, j):
    if i == 0 or j == 0 or i == H-1 or j == W-1:
        return 0
    else:
        pred_in = [[
            (img[i, j, RED]),  # "PR"
            (img[i, j, GRN]),  # "PG"
            (img[i, j, BLU]),  # "PB"
            (img[i - 1, j - 1, RED]),  # "UpleftR"
            (img[i - 1, j - 1, GRN]),  # "UpleftG"
            (img[i - 1, j - 1, BLU]),  # "UpleftB"
            (img[i - 1, j, RED]),  # "UpmidR"
            (img[i - 1, j, GRN]),  # "UpmidG"
            (img[i - 1, j, BLU]),  # "UpmidB"
            (img[i - 1, j + 1, RED]),  # "UprightR"
            (img[i - 1, j + 1, GRN]),  # "UprightG"
            (img[i - 1, j + 1, BLU]),  # "UprightB"
            (img[i, j - 1, RED]),  # "MidleftR"
            (img[i, j - 1, GRN]),  # "MidleftG"
            (img[i, j - 1, BLU]),  # "MidleftB"
            (img[i, j + 1, RED]),  # "MidrightR"
            (img[i, j + 1, GRN]),  # "MidrightG"
            (img[i, j + 1, BLU]),  # "MidrightB"
            (img[i + 1, j - 1, RED]),  # "DownleftR"
            (img[i + 1, j - 1, GRN]),  # "DownleftG"
            (img[i + 1, j - 1, BLU]),  # "DownleftB"
            (img[i + 1, j, RED]),  # "DownmidR"
            (img[i + 1, j, GRN]),  # "DownmidG"
            (img[i + 1, j, BLU]),  # "DownmidB"
            (img[i + 1, j + 1, RED]),  # "DownrightR"
            (img[i + 1, j + 1, GRN]),  # "DownrightG"
            (img[i + 1, j + 1, BLU]),  # "DownrightB"
    ]]

    return clf.predict(pred_in)[0]  # 2.3


def main():
    if os.path.exists(results_dir):
        pass
    else:
        raise Warning("Result directory does not exist")
    pngs = os.listdir(png_base_dir)
    finished_masks = os.listdir(results_dir)
    pngs = [png for png in pngs if png not in finished_masks]
    # print(pngs)
    # exit()
    # random.seed(33)
    # pngs = random.sample(pngs, 3)  # Subsetting to random 3 for shorter runtime:
    # pngs = pngs[715:1650]
    # 1. Load model
    with open(classifier, "rb") as f:  # choose classifier here
        clf = pickle.load(f)

    # Just some timing print statement stuff
    left_to_do = len(pngs)
    done = 0
    duration_list = []

    for png in pngs:
        start = time.time()
        print(png)
        img = cv2.imread(os.path.join(png_base_dir, png))

        # pr = cProfile.Profile()
        # pr.enable()

        # 2.2 Get neighbors for every pixel but the border pixels
        # 2.3 For each pixel, Predict background/foreground based on pixel and neighbor RGB values
        # 2.4 Save pixel prediction onto mask
        predicted_mask = Parallel(n_jobs=8)(delayed(predict_pixel)(clf, img, i, j) for i, j in itertools.product(range(0, H), range(0, W)))
        predicted_mask = np.reshape(predicted_mask, (H, W))

        # pr.disable()
        # pr.print_stats(sort="tottime")

        predicted_mask_img = (predicted_mask * 255).astype('uint8')

        # cv2.imshow("Mask", predicted_mask_img)
        # cv2.waitKey(1000)

        # 3. Change binary mask into red
        color_predicted_mask = cv2.cvtColor(predicted_mask_img, cv2.COLOR_GRAY2BGR)
        color_predicted_mask[predicted_mask > 0] = (0, 0, 255)

        # 4. Overlay mask over original image
        # overlay_predicted_mask = cv2.addWeighted(src1=img, alpha=1, src2=color_predicted_mask, beta=1, gamma=0)
        # cv2.imshow("Overlay predicted mask", overlay_predicted_mask)
        # cv2.waitKey(1000)
        # cv2.destroyAllWindows()

        # 5. Export images
        # cv2.imwrite(filename=os.path.join(results_dir, "{to_save}".format(to_save=png)), img=overlay_predicted_mask)
        cv2.imwrite(filename=os.path.join(results_dir, "{to_save}".format(to_save=png)), img=predicted_mask_img)

        # 6. Timing stuff and print statements
        left_to_do = left_to_do - 1
        done += 1
        print(done, "segmentations are done, ", left_to_do, "iterations left to do ")
        stop = time.time()
        duration = stop - start
        duration_list.append(duration)
        print("Pixel classification took", round(duration), "seconds")
        average_duration = sum(duration_list) / len(duration_list)
        print("Approximate time left =", round((left_to_do * average_duration) / 60), "minutes")
        print("Average time for classification [sec]:", round(average_duration))
        print("#############################################################################")


main()