import os
import numpy as np
import pandas as pd
import cv2

mask_segment_base_dir = "../../data/out/rgb/classified_masks"
mask_coco_out_dir = "../../data/out/rgb/morphed_masks"

mask_segment_list = os.listdir(mask_segment_base_dir)

# Morphological params
erosion_kernel = np.ones((3,3), np.uint8)
dilation_kernel = np.ones((3,3), np.uint8)



def coco_analysis(mask, min_area = 5):
    nb_components, output, stats, centroids = cv2.connectedComponentsWithStats(mask, connectivity=4)
    sizes = stats[1:, -1]; nb_components = nb_components - 1
    coco_mask = np.zeros(mask.shape, dtype="uint8")
    for i in range(0, nb_components):
        if sizes[i] >= min_area:
            coco_mask[output == i + 1] = 255
    return coco_mask

def get_foreground_pixels(in_mask):
    array_shape = in_mask.shape[0] * in_mask.shape[1]
    mask_1d_array = np.reshape(in_mask, (array_shape))
    filter_array = mask_1d_array > 0
    foreground = mask_1d_array[filter_array]
    n_foreground_pixels = len(foreground)
    return n_foreground_pixels

out = []

for file in mask_segment_list:
    # Get raw pixels
    path = os.path.join(mask_segment_base_dir, file)
    mask = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    # print(mask_bin.shape)
    n_pix_raw = get_foreground_pixels(mask)

    # Perform coco-analysis
    img = cv2.imread(path)
    eroded = cv2.erode(img, erosion_kernel)
    dilated = cv2.dilate(eroded, dilation_kernel)
    mask_bin = cv2.inRange(dilated, (1, 1, 1), (255, 255, 255))
    coco_mask = coco_analysis(mask_bin, min_area=150)
    n_pix_coco = get_foreground_pixels(coco_mask)

    # Save coco mask
    cv2.imwrite(filename=os.path.join(mask_coco_out_dir, file), img=coco_mask)

    # Create out file
    out_dict = {"file": file, "n_segmented": n_pix_raw, "n_coco": n_pix_coco}
    out.append(out_dict)

out_df = pd.DataFrame(out)
out_df.to_csv(f"out/raw_coco.csv", index=False)