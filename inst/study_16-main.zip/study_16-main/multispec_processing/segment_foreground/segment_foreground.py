import pickle
import cv2
import os
import numpy as np
import time
import pandas as pd
import tifffile

# Base dirs
tif_crop_base_dir = "../../data/out/multispec/cropped_tif"
classifier = "../../helper_files/multispec_foreground_classifier/nn_2021-08-24.pkl"

# Out dirs
png_mask_out_dir_unmorphed = "../../data/out/multispec/segmentation_out/png_masks_unmorphed"
png_mask_out_dir_morphed = "../../data/out/multispec/segmentation_out/png_masks_morphed"
summary_stat_out = "../../data/out/multispec/segmentation_out/summary_stats"

tif_crop_list = os.listdir(tif_crop_base_dir)

width = 180


def unfold_tif(tif_path):
    # load tif and cast into 2D long array (same as train_x)
    tif = tifffile.imread(tif_path)
    tif_long = np.reshape(tif,(width*width, 5))
    return tif_long

def classify_pixel(unfolded, select_clf):
    # apply classifier and predict foreground/background
    pixel_predict = select_clf.predict(unfolded)
    pixel_predict_array = np.reshape(pixel_predict, (width*width, 1))
    return pixel_predict_array

def make_mask_png(classified, width):
    # Take prediction, cast back into array with shape (width, width, 1)
    predict_mask = np.reshape(classified, (width, width))
    predict_mask_img = np.array(predict_mask*255).astype('uint8')
    return(predict_mask_img)
    # Export as png

def do_morph_operations(mask):
    smooth_kernel = np.ones((3, 3), np.uint8)
    eroded_mask = cv2.erode(mask, smooth_kernel, iterations=1)
    opened_mask = cv2.dilate(eroded_mask, smooth_kernel, iterations=1)
    return opened_mask

def turn_morph_mask_to_long(mask):
    mask_binary = mask/255
    long_mask = np.reshape(mask_binary, (width*width, 1))
    return long_mask

def get_stats_from_classified(unfolded, foreground_classified):
    # Calculate: n_pixels, mean ref for each channel
    # Pass binary 1d array to foreground classified
    df_predict = pd.DataFrame(data = foreground_classified, columns = ["foreground"])
    df_ref = pd.DataFrame(data = unfolded, columns=["blue", "green", "red", "nir", "red_edge"])
    df = pd.concat([df_predict, df_ref], axis = 1)
    foreground_df = df[df.foreground == 1]
    # Summarise
    foreground_summary = foreground_df.describe()
    foreground_summary["file"] = tif[:-4]
    return foreground_summary

summary_stats_list_unmorphed = []
summary_stats_list_morphed = []

left_to_do = len(tif_crop_list)
done = 0
duration_list = []

# with open(classifier, "rb") as f:
#     clf_early = pickle.load(f)
for tif in tif_crop_list:
    date_tif = tif[0:10]
    # classifier= "train_classifier/trained_classifier/per_date/nn_{}.pkl".format(date_tif)
    classifier = classifier
    with open(classifier, "rb") as f:
        clf = pickle.load(f)
    start = time.time()
    tif_path = os.path.join(tif_crop_base_dir, tif)
    tif_long = unfold_tif(tif_path)
    pixel_predict = classify_pixel(tif_long, clf)
    predict_mask_img = make_mask_png(pixel_predict, width = width)
    cv2.imwrite(filename=os.path.join(png_mask_out_dir_unmorphed, "{}.png".format(tif[:-4])), img=predict_mask_img)
    # cv2.imshow("predicted mask", predict_mask_img)
    # cv2.waitKey(2000)
    out = get_stats_from_classified(tif_long, pixel_predict)
    summary_stats_list_unmorphed.append(out)

    # Morphological operations
    predict_mask_img_morphed = do_morph_operations(predict_mask_img)
    cv2.imwrite(filename=os.path.join(png_mask_out_dir_morphed, "{}.png".format(tif[:-4])), img=predict_mask_img_morphed)
    # cv2.imshow("morphological operations", predict_mask_img_morphed)
    # cv2.waitKey(2000)
    pixel_predict_morphed = turn_morph_mask_to_long(predict_mask_img_morphed)
    out_morphed = get_stats_from_classified(tif_long, pixel_predict_morphed)
    summary_stats_list_morphed.append(out_morphed)
    # Timing print statements
    left_to_do = left_to_do -1
    done += 1
    print("#############################################################################")
    print(tif, "classified using", classifier)
    print(done, "segmentations are done, ", left_to_do, "iterations left to do ")
    stop = time.time()
    duration = stop - start
    duration_list.append(duration)
    print("Pixel classification took", round(duration), "seconds")
    average_duration = sum(duration_list) / len(duration_list)
    print("Approximate time left =", round((left_to_do * average_duration)/60), "minutes")



summary_stats_unmorphed = pd.concat(summary_stats_list_unmorphed).drop('foreground', axis = 1)
summary_stats_unmorphed.to_csv("{summary_stat_out}/summary_stats_unmorphed.csv".format(summary_stat_out = summary_stat_out))

summary_stats_morphed = pd.concat(summary_stats_list_morphed).drop('foreground', axis = 1)
summary_stats_morphed.to_csv("{summary_stat_out}/summary_stats_morphed.csv".format(summary_stat_out = summary_stat_out))
