import cv2
import os
import pandas as pd
import matplotlib.pyplot as plt
import micasense.plotutils as plotutils
import micasense.utils as msutils
import micasense.metadata as metadata


# Define panel area and panel image
# Extract values for calibration
# Iterate calibration and alignment over all images
# Save calibrated png files per channel, align and save in next script

### Set up base dir
base_dir = os.path.join("../../data/terrace_images/fun/rededge/")
temp_out_dir = "../../data/out/multispec/calibrated"

### Set up panel calibration(from MicaSense for our specific panel)
panel_calibration = {
    "Blue": 0.98,
    "Green": 0.98,
    "Red": 0.98,
    "Red edge": 0.98,
    "NIR": 0.98
}

def select_date(base_dir):
    base_dir = base_dir
    date_df = pd.DataFrame(os.listdir(base_dir))
    print(date_df)
    print("#################")
    date = input("Enter date: ")
    red_edge_dir = os.path.join(base_dir, date)
    return red_edge_dir, date

def select_panel():
    image_panel_name = input("Enter panel image (channel 2): ")
    image_panel_path = os.path.join(red_edge_dir, image_panel_name)
    return image_panel_path


def get_meta_data(image_panel_name):
    exiftoolPath = None
    if os.name == 'nt':
        # exiftoolPath = os.environ.get('exiftoolpath')
        exiftoolPath = "D:/exiftool/exiftool.exe"

    meta = metadata.Metadata(image_panel_name, exiftoolPath=exiftoolPath)
    band_name = meta.get_item('XMP:BandName')
    return meta, band_name


def get_mean_radiance_from_panel(radiance_image):
    ulx = int(input("Enter upper left column (x coordinate) of panel area: "))
    uly = int(input("Enter upper left row (y coordinate) of panel area: "))
    lrx = int(input("Enter lower right column (x coordinate) of panel area: "))
    lry = int(input("Enter lower right row (y coordinate) of panel area: "))
    # ulx = 500
    # uly = 380
    # lrx = 620
    # lry = 500
    coord_list = [ulx, uly, lrx, lry]
    marked_panel = radiance_image.copy()
    cv2.rectangle(marked_panel, (ulx, uly), (lrx, lry), (0, 255, 0), 3)
    panel_region = radiance_image[uly:lry, ulx:lrx]
    plotutils.plotwithcolorbar(marked_panel, 'Panel region in radiance image')
    mean_radiance = panel_region.mean()
    print('Mean Radiance in panel region: {:1.3f} W/m^2/nm/sr'.format(mean_radiance))
    return mean_radiance, coord_list

def calibrate(image_path, out_dir):
    image_raw = plt.imread(image_path)
    pot_radiance_image, _, _, _ = msutils.raw_image_to_radiance(meta, image_raw)
    reflectance_image = pot_radiance_image * radiance_to_reflectance
    undistorted_reflectance = msutils.correct_lens_distortion(meta, reflectance_image)
    img_out = undistorted_reflectance*255 # Convert to grayscale
    out_name = i.replace('.tif', '')
    cv2.imwrite(filename=os.path.join(out_dir, "{date}_{to_save}.png".format(date = date, to_save=out_name)),
                img = img_out)



### Select data
red_edge_dir, date = select_date(base_dir)
image_panel_path = select_panel()

### Get metadata
meta, band_name = get_meta_data(image_panel_path)

### Read panel image, convert to radiance
img_panel_raw = plt.imread(image_panel_path)
radiance_panel_image, L, V, R = msutils.raw_image_to_radiance(meta, imageRaw = img_panel_raw)

### Choose panel bounding box and get mean reflectance
mean_radiance, panel_coordinates = get_mean_radiance_from_panel(radiance_panel_image)
panel_reflectance = panel_calibration[band_name]
radiance_to_reflectance = panel_reflectance / mean_radiance

### Calibrate
image_list = os.listdir(red_edge_dir)

for i in image_list:
    image_path = os.path.join(red_edge_dir, i)
    calibrate(image_path = image_path, out_dir=temp_out_dir)
    # break

### Export configuration
coord_string = str(panel_coordinates)
radiance_string = str(mean_radiance)
config_txt_name = "calibration_config/{date}_config.txt".format(date = date)
config_string = 'Calibration configuration for: ' + date + ", Panel = " + image_panel_path + ", Panel coordinates = " + coord_string + ", Mean Radiance in panel region = " + radiance_string + " W/m^2/nm/sr"
with open(config_txt_name, 'w') as f:
    f.write(config_string)