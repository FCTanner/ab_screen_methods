import os
import tifffile
import numpy as np
import cv2

# Load reflectance arrays
# Make groups of five

### Set up base dir
base_dir = "../../data/out/multispec/calibrated"
base_dir_list = os.listdir(base_dir)
rgb_out_dir = "../../data/out/multispec/aligned_rgb"
# cir_out_dir = "../../data/out/multispec/cir"
tiff_out_dir = "../../data/out/multispec/aligned_tif"

### Create index for groupings of 5
sequence = list(range(0, len(base_dir_list), 5))

# print(sequence)
# exit()

for i in sequence:

    merged = np.zeros((982, 1342, 5), dtype=np.uint8)  # Create empty np.array with the required dimension
    img_name = base_dir_list[i][0:19] # Subset name to not include channel name

    # Check if file has already been aligned
    aligned_rgb_img_name = "{img_name}_rgb.png".format(img_name = img_name)
    rgb_out_dir_list = os.listdir(rgb_out_dir)

    if aligned_rgb_img_name in rgb_out_dir_list:
        print(img_name, "is already aligned")
    else:
        print("Aligning")
        channel1 = cv2.imread(os.path.join(base_dir, base_dir_list[i]), 0)
        channel2 = cv2.imread(os.path.join(base_dir, base_dir_list[i + 1]), 0)
        channel3 = cv2.imread(os.path.join(base_dir, base_dir_list[i + 2]), 0)
        channel4 = cv2.imread(os.path.join(base_dir, base_dir_list[i + 3]), 0)
        channel5 = cv2.imread(os.path.join(base_dir, base_dir_list[i + 4]), 0)

        merged[0:960, 62:, 0] = channel1 # Overlay each channel on canvas
        merged[2:962, 0:1280, 1] = channel2
        merged[7:967, 4:1284, 2] = channel3
        merged[13:973, 32:1312, 3] = channel4
        merged[21:981, 27:1307, 4] = channel5

        ## Crop
        composite = np.zeros((939, 1218, 5), dtype=np.float32) # Create canvas for crop
        composite = merged[21:960, 62:1280, :] / 255 # Put 5 channels onto crop

        ## Make RGB
        rgb_composite = np.zeros((939, 1218, 3), dtype=np.uint8)
        rgb_composite[:, :, 0] = composite[:, :, 0] * 255
        rgb_composite[:, :, 1] = composite[:, :, 1] * 255
        rgb_composite[:, :, 2] = composite[:, :, 2] * 255
        cv2.imwrite(filename=os.path.join(rgb_out_dir, "{img_name}_rgb.png".format(img_name = img_name)),
            img=rgb_composite)

        ## Make CIR visualization (color - infrared)
        # cir_composite = np.zeros((939, 1218, 3), dtype=np.uint8)
        # cir_composite[:, :, 0] = composite[:, :, 1] * 255
        # cir_composite[:, :, 1] = composite[:, :, 2] * 255
        # cir_composite[:, :, 2] = composite[:, :, 3] * 255
        # cv2.imwrite(filename=os.path.join(cir_out_dir, "{img_name}_cir.png".format(img_name = img_name)),
        #             img=cir_composite)

        ## Save tif
        tif_name = os.path.join(tiff_out_dir, "{img_name}.tif".format(img_name = img_name))
        tifffile.imwrite(tif_name, composite)



