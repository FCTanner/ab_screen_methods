import cv2
import os
import pandas as pd
import numpy as np
import tifffile
import time
import re


# Set base dir
base_png_dir = "../../data/out/multispec/renamed_png"
base_tif_dir = "../../data/out/multispec/renamed_tif"
base_mask_dir = "../../data/out/multispec/masks"

png_out_dir = "../../data/out/multispec/cropped_rgb"
tif_out_dir = "../../data/out/multispec/cropped_tif"

pot_mapping = "../../helper_files/pot_position_matching/matching_3x3.csv"
full_pngs = sorted(os.listdir(base_png_dir))
full_tifs = sorted(os.listdir(base_tif_dir))
ink_masks = sorted(os.listdir(base_mask_dir))

mapping = pd.read_csv(pot_mapping)

radius = 90


def detect_circles(input_img):
    # Threshold for red
    hsv = cv2.cvtColor(input_img, cv2.COLOR_BGR2HSV)
    lower_red = np.array([0, 255, 255])
    upper_red = np.array([0, 255, 255])
    red = cv2.inRange(hsv, lower_red, upper_red)
    # Detect manual circles
    gaussian = cv2.GaussianBlur(red, ksize=(15,15), sigmaX=cv2.BORDER_DEFAULT)
    circles = cv2.HoughCircles(gaussian, cv2.HOUGH_GRADIENT, 2, minDist=20, minRadius=85, maxRadius=93)
    circles_rounded = np.uint16(np.around(circles))
    print(circles_rounded.shape[1], "Circles found")
    return(circles_rounded)

def crop_circular(detected_circles, input_img):
    cropped_pots = []
    for i in detected_circles[0, :]:
        width = i[0]
        height = i[1]
        crop = input_img[height-radius:height+radius, width-radius:width+radius] # find dimensions for square crop around pot
        mask = np.zeros(crop.shape, dtype=np.uint8) # create empty mask
        middle = round(mask.shape[0]/2)
        cv2.circle(mask, (middle,middle), radius = radius, color = (255,255,255), thickness = -1) # put white circle on mask
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY) # convert to binary
        ROI = cv2.bitwise_and(crop,crop, mask =mask) # Apply mask to crop
        storage = dict(Width = width, Height = height, Pot = ROI) # use dictionary as storage
        cropped_pots.append(storage) # list of dictionaries
    return(cropped_pots)

def crop_circular_tif(detected_circles, input_tif):
    cropped_pots = []
    for i in detected_circles[0, :]:
        width = i[0]
        height = i[1]

        channel_1 = input_tif[:, :, 0]
        channel_2 = input_tif[:, :, 1]
        channel_3 = input_tif[:, :, 2]
        channel_4 = input_tif[:, :, 3]
        channel_5 = input_tif[:, :, 4]

        crop_1 = channel_1[height - radius:height + radius,
                 width - radius:width + radius]  # find dimensions for square crop around pot
        crop_2 = channel_2[height - radius:height + radius, width - radius:width + radius]
        crop_3 = channel_3[height - radius:height + radius, width - radius:width + radius]
        crop_4 = channel_4[height - radius:height + radius, width - radius:width + radius]
        crop_5 = channel_5[height - radius:height + radius, width - radius:width + radius]

        mask = np.zeros(crop_1.shape, dtype=np.uint8)  # create empty mask
        middle = round(mask.shape[0] / 2)
        cv2.circle(mask, (middle, middle), radius=radius, color=(255, 255, 255),
                   thickness=-1)  # put white circle on mask

        ROI_1 = cv2.bitwise_and(crop_1, crop_1, mask=mask)  # Apply mask to crop
        ROI_2 = cv2.bitwise_and(crop_2, crop_2, mask=mask)
        ROI_3 = cv2.bitwise_and(crop_3, crop_3, mask=mask)
        ROI_4 = cv2.bitwise_and(crop_4, crop_4, mask=mask)
        ROI_5 = cv2.bitwise_and(crop_5, crop_5, mask=mask)

        storage = dict(Width=width, Height=height, ROI_1 = ROI_1, ROI_2 = ROI_2, ROI_3 = ROI_3, ROI_4 = ROI_4, ROI_5 = ROI_5)  # use dictionary as storage
        cropped_pots.append(storage)  # list of dictionaries


    return(cropped_pots)


def sort_by_position(cropped_circles):
    cropped_circles.sort(key=lambda i: (i['Width'])) # Sort by width
    column1 = cropped_circles[0:3] # Splitting into 4 columns by width
    column2 = cropped_circles[3:6]
    column3 = cropped_circles[6:9]
    column4 = cropped_circles[9:]

    # average each 4 width groups
    column1_sum = 0
    for row in column1:
        column1_sum += row['Width']
    column1_avg = int(column1_sum/3)
    for row in column1:
        row['Column width'] = column1_avg

    column2_sum = 0
    for row in column2:
        column2_sum += row['Width']
    column2_avg = int(column2_sum/3)
    for row in column2:
        row['Column width'] = column2_avg

    column3_sum = 0
    for row in column3:
        column3_sum += row['Width']
    column3_avg = int(column3_sum/3)
    for row in column3:
        row['Column width'] = column3_avg

    column4_sum = 0
    for row in column4:
        column4_sum += row['Width']
    column4_avg = int(column4_sum/3)
    for row in column4:
        row['Column width'] = column4_avg

    # Append all lists sorted by column width
    cropped_circles_pos = column1 + column2 + column3 + column4
    cropped_circles_pos.sort(key=lambda i: (i['Column width'], i['Height'])) # sort by *average width*, height

    # Assign number 1:16 for positions
    position = 1
    for pos in cropped_circles_pos:
        pos['Position'] = position
        position += 1
    return(cropped_circles_pos)

def pull_date_and_name(filename):
    filenamelist = re.split(" |\.", filename)  # splits filename into parts
    print(filenamelist)
    date = filenamelist[0]
    if len(filenamelist) > 3: # for the FLIP lines that have "A" in filename
        top_left_pot = filenamelist[1] + " " + filenamelist[2]
    else: # Just extracting the pot number
        top_left_pot = filenamelist[1]
    return date, top_left_pot

def match_position(pot):
    # takes single dictionary
    pot['Date'] = date
    pot['Top left pot'] = top_left_pot
    pot['Pot name'] = pot_mapper.iloc[0][position_iter]
    return pot

left_to_do = len(full_pngs)
done = 0
duration_list = []

for pic, tf, mk in zip(full_pngs[-18:], full_tifs[-18:], ink_masks[-18:]): # Only crop last 18 images
    try:
        # timing
        start = time.time()
        # Load images
        path_png = os.path.join(base_png_dir, pic)
        path_tif = os.path.join(base_tif_dir, tf)
        path_mask = os.path.join(base_mask_dir, mk)
        print("Image", path_png)
        png = cv2.imread(path_png)
        tif = tifffile.imread(path_tif)
        ink_mask = cv2.imread(path_mask)
        ink_mask = cv2.resize(ink_mask, (1218, 939))
        png_orig = png.copy()
        # cv2.imshow("Input image", png_orig)
        # cv2.waitKey(1000)
        # Detect circles on mask
        circles_rounded = detect_circles(ink_mask)

        # Crop circles on png
        cropped_circles = crop_circular(circles_rounded, png_orig)
        sorted_pots = sort_by_position(cropped_circles)

        # Crop circles on tifs
        cropped_circles_tif = crop_circular_tif(circles_rounded, tif)
        sorted_pots_tif = sort_by_position(cropped_circles_tif)

        date, top_left_pot = pull_date_and_name(pic)
        pot_mapper = (
        mapping.loc[mapping['Pot number'] == top_left_pot])  # filter mapper file for specific top left pot

        position_iter = 1
        for pot in sorted_pots:
            # cv2.imshow("Cropped portion", pot['Pot'])
            # cv2.waitKey(200)
            match_position(pot)
            if pot['Pot'].shape[0] == radius * 2 & pot['Pot'].shape[1] == radius * 2:
                img_name = "{Date} {Pot_name} .png".format(Date=pot['Date'], Pot_name=pot['Pot name'])
                cv2.imwrite(filename=os.path.join(png_out_dir, img_name), img=pot['Pot'])
            else:
                pass
            position_iter += 1

        position_iter = 1
        for pot_tif in sorted_pots_tif:
            pot_tif = match_position(pot_tif)

            if pot_tif["ROI_1"].shape[0] == radius * 2 & pot_tif["ROI_1"].shape[1] == radius * 2:
                # nir = np.zeros((radius * 2, radius * 2), dtype=np.uint8)
                #
                # nir_name = os.path.join(nir_out_dir, "{Date} {Pot_name}.png".format(Date=pot_tif['Date'],
                #                                                                     Pot_name=pot_tif['Pot name']))
                # nir[:,:] = pot_tif["ROI_4"] *255
                # cv2.imwrite(filename = nir_name, img=nir)


                merged = np.zeros((radius * 2, radius * 2, 5), dtype=np.float32)
                merged[:, :, 0] = pot_tif["ROI_1"]  # Overlay each channel on canvas
                merged[:, :, 1] = pot_tif["ROI_2"]
                merged[:, :, 2] = pot_tif["ROI_3"]
                merged[:, :, 3] = pot_tif["ROI_4"]
                merged[:, :, 4] = pot_tif["ROI_5"]

                tif_name = os.path.join(tif_out_dir, "{Date} {Pot_name}.tif".format(Date=pot_tif['Date'],
                                                                                    Pot_name=pot_tif['Pot name']))
                tifffile.imwrite(tif_name, merged, shape=(180, 180, 5))
            else:
                pass

            position_iter += 1

        # Print statements
        left_to_do = left_to_do - 1
        done += 1
        print("#######################################################")
        print(done, "segmentations are done, ", left_to_do, "iterations left to do ")
        stop = time.time()
        duration = stop - start
        duration_list.append(duration)
        average_duration = sum(duration_list) / len(duration_list)
        print("Approximate time left =", round((left_to_do * average_duration) / 60), "minutes")
        cv2.destroyAllWindows()
    except:
        pass


