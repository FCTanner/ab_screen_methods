import cv2
import os
import pandas as pd
import numpy as np
import tifffile as tf


# Read file dictionary as df
# Read list of aligned_tif files
# Filter list of aligned_tif files
# Rename and save aligned_tif files as aligned_tif and png

### Set up base dir

base_dir = "../../data/out/multispec/aligned_tif"
png_out_dir = "../../data/out/multispec/renamed_png"
tiff_out_dir = "../../data/out/multispec/renamed_tif"

png_out_dir_list = os.listdir(png_out_dir)
print(png_out_dir_list)

### Load file dictionary

file_dict = pd.read_excel("../../helper_files/file_dictionary_rededge/file_dictionary.xlsx", dtype = "string").dropna()
file_dict['Date'] = file_dict['File'].str.slice(0, 10)

### Load tiff_files in loop with condition that matches with file dict
tiff_list = os.listdir(base_dir)
# print(tiff_list)

for tiff in tiff_list:

    name = tiff[0:19]

    if file_dict["File"].str.contains(name).any():
        # Read aligned_tif
        path = os.path.join(base_dir, tiff)        

        # Build new name with date and pot number
        new_date = file_dict.loc[file_dict["File"] == name, "Date"].iloc[0]
        new_pot = file_dict.loc[file_dict["File"] == name, "Position"].iloc[0]
        new_name = "{} {}".format(new_date, new_pot)
        png_name = "{img_name}.png".format(img_name = new_name)

        if png_name in png_out_dir_list:
            print(png_name, "is already renamed and filtered.")
            pass
        else:
            print("Renaming", png_name)
            tiff_file = tf.imread(path)

            # Make png
            rgb_composite = np.zeros((939, 1218, 3), dtype=np.uint8)
            rgb_composite[:, :, 0] = tiff_file[:, :, 0] * 255
            rgb_composite[:, :, 1] = tiff_file[:, :, 1] * 255
            rgb_composite[:, :, 2] = tiff_file[:, :, 2] * 255

            # Save png
            cv2.imwrite(filename=os.path.join(png_out_dir, png_name),
                    img=rgb_composite)

            # Save renamed aligned_tif
            tif_name = os.path.join(tiff_out_dir, "{img_name}.tif".format(img_name=new_name))
            tf.imwrite(tif_name, tiff_file)
    else:
        pass
